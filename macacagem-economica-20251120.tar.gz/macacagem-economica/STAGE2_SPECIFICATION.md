# Stage 2 - Especificação Técnica

**Baseado em**: rstar.stage2.R e unpack.parameters.stage2.R (HLW oficial)

---

## Diferenças Stage 1 → Stage 2

| Aspecto | Stage 1 | Stage 2 |
|---------|---------|---------|
| **Estados** | 3: [y*_t, y*_{t-1}, y*_{t-2}] | 4: [y*_t, y*_{t-1}, y*_{t-2}, g_t] |
| **Taxa de juros** | ❌ Não usa | ✅ Adiciona r_t na IS curve |
| **Crescimento** | g fixo (constante) | g_t como estado (varia no tempo) |
| **Parâmetros fixos** | Nenhum | **FIXA Stage 1**: a_y1, a_y2, b_π, b_y |
| **Parâmetros novos** | - | a_r (coef. taxa juros), λ_g (razão var. g) |
| **Input externo** | - | λ_g (do Stage 1 ou median-unbiased) |

---

## State-Space Model (Stage 2)

### Estados (4):


### Observações (2):


### Equações de Estado:


**Matriz F** (4x4):


**Matriz Q** (4x4):


### Equações de Observação:


**Matriz H** (4x2):


**Matriz A** (10x2):


---

## Parâmetros

### Fixos do Stage 1:
- a_y1, a_y2: Lags da IS curve
- b_π, b_π_lag: Persistência inflação
- b_y: Output gap → inflação

### Estimados no Stage 2:
1. **a_r**: Efeito taxa real na IS curve (constraint: a_r ≤ -0.0025)
2. **a_0**: Constante na IS curve
3. **a_g**: Efeito crescimento no GDP observado
4. **σ_ỹ**: Desvio-padrão output gap
5. **σ_π**: Desvio-padrão inflação
6. **σ_y***: Desvio-padrão y* (potencial)
7. **κ_COVID**: Efeitos COVID (fixos ou re-estimados)

### Input externo:
- **λ_g**: Razão de variância σ_g / σ_y* (vem do Stage 1 ou median-unbiased)

**Total**: 7 parâmetros livres + λ_g fixo

---

## Processo de Estimação (Stage 2)

### 1. Output gap inicial


### 2. IS curve OLS (AGORA COM TAXA DE JUROS!)


**DIFERENÇA CRUCIAL**: Stage 2 adiciona taxa de juros na IS curve!

### 3. Phillips curve OLS


### 4. Preparar dados para Kalman


### 5. Valores iniciais para MLE


### 6. MLE com λ_g FIXO


**CHAVE**: λ_g é FIXO no Stage 2 (vem do Stage 1)

---

## Outputs do Stage 2

### Estados filtrados:


### Quantidades derivadas:


### Para Stage 3:


---

## Constraints (Torres 2023)



---

## Checklist de Implementação

- [ ] Criar 
- [ ] Implementar 
- [ ] Implementar  (matrizes 4 estados)
- [ ] Implementar 
- [ ] Criar 
- [ ] Testar Stage 2 standalone (mock λ_g)
- [ ] Integrar Stage 1 → Stage 2 pipeline
- [ ] Validar r* preliminar = g_t * 4

---

## Arquivos de Referência

- 
- 
-  (constraints)

---

## Próximos Passos

1. ✅ Documentar especificação Stage 2
2. ⏳ Implementar 
3. ⏳ Testar Stage 2
4. ⏳ Implementar Stage 3
5. ⏳ Pipeline completo Stage 1 → 2 → 3

