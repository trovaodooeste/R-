"""
Three-Stage HLW Estimation Pipeline for Brazil

Orchestrates the complete three-stage estimation procedure following
Stock & Watson (1998) and Holston, Laubach & Williams (2017).

Stages:
1. Preliminary estimation without interest rate (IS/Phillips curves)
2. Add interest rate and estimate growth component
3. Full r* decomposition with g_t and z_t components

This approach is more stable than simultaneous MLE of all 14 parameters
and follows the canonical HLW methodology.

Usage:
    python run_three_stage_estimation.py

Output:
    - outputs/stage1/: Stage 1 results and diagnostics
    - outputs/stage2/: Stage 2 results and diagnostics
    - outputs/stage3/: Stage 3 results and final r* estimates
    - outputs/results/three_stage_results.csv: Combined final results
"""

import logging
import sys
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from data.loader import DataLoader
from data.preprocessing import DataPreprocessor
from estimation.stage1_preliminary import Stage1Estimator
from estimation.stage2_with_interest_rate import Stage2Estimator
from estimation.stage3_full_rstar import Stage3Estimator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('outputs/three_stage_estimation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Seaborn style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (14, 7)


def create_output_directories():
    """Create output directories for each stage"""
    for stage in ['stage1', 'stage2', 'stage3']:
        Path(f'outputs/{stage}').mkdir(parents=True, exist_ok=True)
    Path('outputs/results').mkdir(parents=True, exist_ok=True)
    Path('outputs/figures/three_stage').mkdir(parents=True, exist_ok=True)


def save_stage_results(stage_num: int, results: dict):
    """Save stage results to CSV and plots

    Args:
        stage_num: Stage number (1, 2, or 3)
        results: Dictionary with stage results
    """
    output_dir = Path(f'outputs/stage{stage_num}')

    # Save parameters
    params_df = pd.DataFrame([
        {'parameter': k, 'estimate': v}
        for k, v in results['params'].items()
    ])
    params_df.to_csv(output_dir / f'stage{stage_num}_parameters.csv', index=False)

    # Save filtered states
    states_df = pd.DataFrame({'date': results['dates']})

    if stage_num == 1:
        states_df['y_star'] = results['y_star']
        states_df['y_tilde'] = results['y_tilde']

    elif stage_num == 2:
        states_df['y_star'] = results['y_star']
        states_df['g_t'] = results['g_t']
        states_df['r_star_preliminary'] = results['r_star_preliminary']
        states_df['y_tilde'] = results['y_tilde']

    elif stage_num == 3:
        states_df['y_star'] = results['y_star']
        states_df['g_t'] = results['g_t']
        states_df['z_t'] = results['z_t']
        states_df['r_star'] = results['r_star']
        states_df['y_tilde'] = results['y_tilde']

    states_df.to_csv(output_dir / f'stage{stage_num}_filtered_states.csv', index=False)

    logger.info(f"Stage {stage_num} results saved to {output_dir}")


def plot_stage_comparison(stage1_results: dict, stage2_results: dict,
                          stage3_results: dict):
    """Plot comparison of results across all three stages

    Args:
        stage1_results, stage2_results, stage3_results: Results from each stage
    """
    dates = pd.to_datetime(stage3_results['dates'])
    covid_start = pd.to_datetime('2020-04-01')
    covid_end = pd.to_datetime('2022-12-31')

    fig, axes = plt.subplots(2, 2, figsize=(16, 10))

    # Plot 1: Potential GDP evolution across stages
    ax = axes[0, 0]
    ax.plot(dates, stage1_results['y_star'], 'b--', alpha=0.5,
            linewidth=1.5, label='Stage 1')
    ax.plot(dates, stage2_results['y_star'], 'g--', alpha=0.5,
            linewidth=1.5, label='Stage 2')
    ax.plot(dates, stage3_results['y_star'], 'r-', linewidth=2, label='Stage 3 (final)')
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('Potential GDP (y*) - Evolution Across Stages', fontweight='bold')
    ax.set_xlabel('Quarter')
    ax.set_ylabel('Log GDP')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Plot 2: Output Gap evolution across stages
    ax = axes[0, 1]
    ax.plot(dates, stage1_results['y_tilde'], 'b--', alpha=0.5,
            linewidth=1.5, label='Stage 1')
    ax.plot(dates, stage2_results['y_tilde'], 'g--', alpha=0.5,
            linewidth=1.5, label='Stage 2')
    ax.plot(dates, stage3_results['y_tilde'] * 100, 'r-',
            linewidth=2, label='Stage 3 (final)')
    ax.axhline(y=0, color='black', linestyle='-', linewidth=1)
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('Output Gap - Evolution Across Stages', fontweight='bold')
    ax.set_xlabel('Quarter')
    ax.set_ylabel('Gap (%)')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Plot 3: r* comparison (Stage 2 vs Stage 3)
    ax = axes[1, 0]
    ax.plot(dates, stage2_results['r_star_preliminary'] * 400, 'g--',
            linewidth=2, label='Stage 2 (r* = g only)')
    ax.plot(dates, stage3_results['r_star'] * 400, 'r-',
            linewidth=2, label='Stage 3 (r* = g + z)')
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('Natural Rate of Interest (r*) - Final Decomposition', fontweight='bold')
    ax.set_xlabel('Quarter')
    ax.set_ylabel('r* (% annual)')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Plot 4: r* components (g and z)
    ax = axes[1, 1]
    ax.plot(dates, stage3_results['g_t'] * 400, 'b-',
            linewidth=2, label='g_t (trend growth)')
    ax.plot(dates, stage3_results['z_t'] * 400, 'orange',
            linewidth=2, label='z_t (other component)')
    ax.plot(dates, stage3_results['r_star'] * 400, 'r--',
            linewidth=2, alpha=0.7, label='r* = g + z')
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('r* Decomposition: g_t + z_t', fontweight='bold')
    ax.set_xlabel('Quarter')
    ax.set_ylabel('% annual')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.suptitle('HLW Three-Stage Estimation - Brazil', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig('outputs/figures/three_stage/stage_comparison.png',
                dpi=300, bbox_inches='tight')
    plt.close()
    logger.info("Stage comparison plot saved")


def create_final_dashboard(results: dict, data: pd.DataFrame):
    """Create final dashboard with all key results

    Args:
        results: Stage 3 results
        data: Original data DataFrame
    """
    dates = pd.to_datetime(results['dates'])
    covid_start = pd.to_datetime('2020-04-01')
    covid_end = pd.to_datetime('2022-12-31')

    fig, axes = plt.subplots(3, 2, figsize=(16, 12))

    # r*
    ax = axes[0, 0]
    ax.plot(dates, results['r_star'] * 400, 'b-', linewidth=2)
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
    ax.set_title('r* (Natural Rate)', fontweight='bold')
    ax.set_ylabel('% annual')
    ax.grid(True, alpha=0.3)

    # r* components
    ax = axes[0, 1]
    ax.plot(dates, results['g_t'] * 400, 'b-', linewidth=2, label='g (growth)')
    ax.plot(dates, results['z_t'] * 400, 'orange', linewidth=2, label='z (other)')
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
    ax.set_title('r* Components', fontweight='bold')
    ax.set_ylabel('% annual')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Output gap
    ax = axes[1, 0]
    ax.plot(dates, results['y_tilde'] * 100, 'purple', linewidth=2)
    ax.axhline(y=0, color='black', linestyle='-', linewidth=1.5)
    ax.fill_between(dates, 0, results['y_tilde'] * 100,
                     where=(results['y_tilde'] >= 0), alpha=0.3, color='green')
    ax.fill_between(dates, 0, results['y_tilde'] * 100,
                     where=(results['y_tilde'] < 0), alpha=0.3, color='red')
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('Output Gap', fontweight='bold')
    ax.set_ylabel('%')
    ax.grid(True, alpha=0.3)

    # Real rate gap (r - r*)
    ax = axes[1, 1]
    r_t = data['r_t'].values
    r_gap = (r_t - results['r_star']) * 100
    ax.plot(dates, r_gap, 'g-', linewidth=2)
    ax.axhline(y=0, color='black', linestyle='-', linewidth=1.5)
    ax.fill_between(dates, 0, r_gap,
                     where=(r_gap >= 0), alpha=0.3, color='red')
    ax.fill_between(dates, 0, r_gap,
                     where=(r_gap < 0), alpha=0.3, color='green')
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('Real Rate Gap (r - r*)', fontweight='bold')
    ax.set_ylabel('%')
    ax.grid(True, alpha=0.3)

    # GDP: actual vs potential
    ax = axes[2, 0]
    y_t = data['y_t'].values
    ax.plot(dates, y_t, 'b-', linewidth=2, label='Actual')
    ax.plot(dates, results['y_star'], 'r--', linewidth=2, label='Potential')
    ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
    ax.set_title('GDP: Actual vs Potential', fontweight='bold')
    ax.set_ylabel('Log GDP')
    ax.set_xlabel('Quarter')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Statistics box
    ax = axes[2, 1]
    ax.axis('off')
    ultimo = len(results['r_star']) - 1
    last_date = dates.iloc[-1]

    texto = f"""
THREE-STAGE HLW ESTIMATION
FINAL STATISTICS
({last_date.strftime('%Y-Q')}{last_date.quarter})

r*:              {results['r_star'][ultimo]*400:.2f}% annual
  g component:   {results['g_t'][ultimo]*400:.2f}%
  z component:   {results['z_t'][ultimo]*400:.2f}%

r* Range:
  Mean:          {np.mean(results['r_star'])*400:.2f}%
  Std:           {np.std(results['r_star'])*400:.2f}%
  Min:           {np.min(results['r_star'])*400:.2f}%
  Max:           {np.max(results['r_star'])*400:.2f}%

Output Gap:      {results['y_tilde'][ultimo]*100:.2f}%
Real Rate Gap:   {r_gap[ultimo]:.2f}%

Observations:    {len(results['r_star'])}
Log-likelihood:  {results['log_likelihood']:.2f}

Variance Ratios (median-unbiased):
  λ_g:           {results.get('lambda_g_mub', results['params']['lambda_g']):.4f}
  λ_z:           {results.get('lambda_z_mub', results['params']['lambda_z']):.4f}
"""
    ax.text(0.1, 0.5, texto, fontsize=9, family='monospace',
            verticalalignment='center',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.suptitle('HLW-COVID Three-Stage - Brazil (Final)', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig('outputs/figures/three_stage/final_dashboard.png',
                dpi=300, bbox_inches='tight')
    plt.close()
    logger.info("Final dashboard saved")


def main():
    """Main execution pipeline"""
    logger.info("=" * 80)
    logger.info("HLW THREE-STAGE ESTIMATION FOR BRAZIL")
    logger.info("=" * 80)

    # Create output directories
    create_output_directories()

    # Load configuration
    config_path = Path("config/config.yaml")
    logger.info(f"\nLoading configuration from {config_path}")

    # Load and preprocess data
    logger.info("\nLoading data...")
    loader = DataLoader(config_path)
    raw_data = loader.load_all()

    logger.info("Preprocessing data...")
    preprocessor = DataPreprocessor(config_path)
    model_data = preprocessor.create_model_data(raw_data)

    logger.info(f"Model data shape: {model_data.shape}")
    logger.info(f"Date range: {model_data['date'].min()} to {model_data['date'].max()}")

    # =========================================================================
    # STAGE 1: Preliminary estimation (no interest rate)
    # =========================================================================
    logger.info("\n" + "=" * 80)
    logger.info("STARTING STAGE 1")
    logger.info("=" * 80)

    stage1 = Stage1Estimator(config_path)
    stage1_results = stage1.estimate(model_data)
    save_stage_results(1, stage1_results)

    # =========================================================================
    # STAGE 2: Add interest rate
    # =========================================================================
    logger.info("\n" + "=" * 80)
    logger.info("STARTING STAGE 2")
    logger.info("=" * 80)

    stage2 = Stage2Estimator(config_path, stage1_results)
    stage2_results = stage2.estimate(model_data)
    save_stage_results(2, stage2_results)

    # =========================================================================
    # STAGE 3: Full r* decomposition
    # =========================================================================
    logger.info("\n" + "=" * 80)
    logger.info("STARTING STAGE 3")
    logger.info("=" * 80)

    stage3 = Stage3Estimator(config_path, stage1_results, stage2_results)
    stage3_results = stage3.estimate(model_data)
    save_stage_results(3, stage3_results)

    # =========================================================================
    # Save combined final results
    # =========================================================================
    logger.info("\n" + "=" * 80)
    logger.info("SAVING FINAL RESULTS")
    logger.info("=" * 80)

    final_results = pd.DataFrame({
        'date': stage3_results['dates'],
        'y_t': model_data['y_t'].values,
        'y_star': stage3_results['y_star'],
        'y_tilde': stage3_results['y_tilde'],
        'g_t': stage3_results['g_t'],
        'z_t': stage3_results['z_t'],
        'r_star': stage3_results['r_star'],
        'r_t': model_data['r_t'].values,
        'r_gap': model_data['r_t'].values - stage3_results['r_star'],
        'pi_t': model_data['pi_t'].values,
    })

    final_results.to_csv('outputs/results/three_stage_results.csv', index=False)
    logger.info("Final results saved to outputs/results/three_stage_results.csv")

    # Create visualizations
    logger.info("\nGenerating comparison plots...")
    plot_stage_comparison(stage1_results, stage2_results, stage3_results)
    create_final_dashboard(stage3_results, model_data)

    # =========================================================================
    # Final summary
    # =========================================================================
    logger.info("\n" + "=" * 80)
    logger.info("ESTIMATION COMPLETE")
    logger.info("=" * 80)

    logger.info("\nFinal r* estimate:")
    logger.info(f"  Last quarter: {stage3_results['r_star'][-1]*400:.2f}% annual")
    logger.info(f"  Mean (full sample): {np.mean(stage3_results['r_star'])*400:.2f}%")
    logger.info(f"  Std dev: {np.std(stage3_results['r_star'])*400:.2f}%")

    logger.info("\nComponents:")
    logger.info(f"  g (trend growth): {stage3_results['g_t'][-1]*400:.2f}% annual")
    logger.info(f"  z (other):        {stage3_results['z_t'][-1]*400:.2f}% annual")

    logger.info("\nOutput saved to:")
    logger.info("  - outputs/stage1/, outputs/stage2/, outputs/stage3/")
    logger.info("  - outputs/results/three_stage_results.csv")
    logger.info("  - outputs/figures/three_stage/")

    logger.info("\nAll done!")


if __name__ == "__main__":
    main()
