"""
Script para preparar dados do arquivo dados_completos.xlsx para o modelo HLW.

Este script lê o arquivo Excel consolidado e cria os arquivos esperados
pelo sistema de carregamento de dados.
"""

import logging
from pathlib import Path

import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """
    Prepara dados do Excel consolidado.
    """
    logger.info("=" * 60)
    logger.info("PREPARAÇÃO DE DADOS - HLW-COVID BRASIL")
    logger.info("=" * 60)

    # Paths
    input_file = Path("data/raw/dados_completos.xlsx")

    if not input_file.exists():
        logger.error(f"Arquivo não encontrado: {input_file}")
        logger.info("\nColoque seu arquivo de dados em: data/raw/dados_completos.xlsx")
        return

    logger.info(f"\nLendo arquivo: {input_file}")

    # Read Excel file
    try:
        xl = pd.ExcelFile(input_file)
        logger.info(f"Planilhas encontradas: {xl.sheet_names}")
    except Exception as e:
        logger.error(f"Erro ao ler Excel: {e}")
        return

    # ========================================
    # OPÇÃO 1: Arquivo com múltiplas planilhas
    # ========================================
    # Se o arquivo tem planilhas separadas (PIB, IPCA, Selic, Stringency)

    if len(xl.sheet_names) > 1:
        logger.info("\nDetectadas múltiplas planilhas. Criando arquivos individuais...")

        # Mapear planilhas para arquivos esperados
        sheet_mapping = {
            'PIB': 'data/raw/pib_trimestral.xlsx',
            'IPCA': 'data/raw/ipca.xlsx',
            'Selic': 'data/raw/selic.xlsx',
            'Stringency': 'data/external/oxford_stringency_index.csv',
        }

        for sheet_name, output_file in sheet_mapping.items():
            if sheet_name in xl.sheet_names:
                df = pd.read_excel(xl, sheet_name=sheet_name)

                # Save based on extension
                if output_file.endswith('.csv'):
                    df.to_csv(output_file, index=False)
                else:
                    df.to_excel(output_file, index=False, sheet_name='Dados')

                logger.info(f"✓ {sheet_name} → {output_file}")
            else:
                logger.warning(f"⚠ Planilha '{sheet_name}' não encontrada")

    # ========================================
    # OPÇÃO 2: Arquivo com uma única planilha consolidada
    # ========================================
    else:
        logger.info("\nDetectada planilha única. Separando dados...")

        # Read main sheet
        df = pd.read_excel(xl, sheet_name=xl.sheet_names[0])
        logger.info(f"Colunas encontradas: {df.columns.tolist()}")
        logger.info(f"Shape: {df.shape}")
        logger.info(f"\nPrimeiras linhas:")
        print(df.head())

        # Aqui você precisa adaptar baseado na estrutura real do seu arquivo
        # Exemplo de separação (AJUSTE CONFORME SEU ARQUIVO):

        # Identificar colunas de data
        date_cols = [col for col in df.columns if 'data' in col.lower() or 'date' in col.lower()]

        if date_cols:
            logger.info(f"\nColunas de data encontradas: {date_cols}")
            date_col = date_cols[0]
        else:
            logger.warning("Nenhuma coluna de data encontrada, usando primeira coluna")
            date_col = df.columns[0]

        # Exemplo de criação dos arquivos individuais
        # (VOCÊ PRECISA AJUSTAR OS NOMES DAS COLUNAS)

        # PIB
        if 'pib_real' in df.columns or 'PIB' in df.columns:
            pib_col = 'pib_real' if 'pib_real' in df.columns else 'PIB'
            pib_df = df[[date_col, pib_col]].copy()
            pib_df.columns = ['data', 'pib_real']
            pib_df.to_excel('data/raw/pib_trimestral.xlsx', index=False, sheet_name='Dados')
            logger.info(f"✓ PIB salvo: {len(pib_df)} observações")

        # IPCA
        ipca_cols = [col for col in df.columns if 'ipca' in col.lower() or 'inflacao' in col.lower()]
        if len(ipca_cols) >= 2:
            # Assumindo duas colunas: núcleo e cheio
            ipca_df = df[[date_col] + ipca_cols[:2]].copy()
            ipca_df.columns = ['data', 'ipca_nucleo', 'ipca_cheio']
            ipca_df.to_excel('data/raw/ipca.xlsx', index=False, sheet_name='Dados')
            logger.info(f"✓ IPCA salvo: {len(ipca_df)} observações")
        elif len(ipca_cols) == 1:
            # Apenas uma coluna de inflação - usar como cheio
            ipca_df = df[[date_col, ipca_cols[0]]].copy()
            ipca_df.columns = ['data', 'ipca_cheio']
            ipca_df['ipca_nucleo'] = ipca_df['ipca_cheio']  # Duplicar
            ipca_df = ipca_df[['data', 'ipca_nucleo', 'ipca_cheio']]
            ipca_df.to_excel('data/raw/ipca.xlsx', index=False, sheet_name='Dados')
            logger.info(f"✓ IPCA salvo: {len(ipca_df)} observações (usando mesma série para núcleo e cheio)")

        # Selic
        selic_cols = [col for col in df.columns if 'selic' in col.lower() or 'juros' in col.lower()]
        if selic_cols:
            selic_df = df[[date_col, selic_cols[0]]].copy()
            selic_df.columns = ['data', 'selic_nominal']
            selic_df.to_excel('data/raw/selic.xlsx', index=False, sheet_name='Dados')
            logger.info(f"✓ Selic salvo: {len(selic_df)} observações")

        # Stringency Index
        stringency_cols = [col for col in df.columns if 'stringency' in col.lower() or 'restricao' in col.lower()]
        if stringency_cols:
            stringency_df = df[[date_col, stringency_cols[0]]].copy()
            stringency_df.columns = ['date', 'stringency_index']
            stringency_df['country'] = 'Brazil'  # Adicionar coluna de país
            stringency_df = stringency_df[['country', 'date', 'stringency_index']]
            stringency_df.to_csv('data/external/oxford_stringency_index.csv', index=False)
            logger.info(f"✓ Stringency Index salvo: {len(stringency_df)} observações")

    logger.info("\n" + "=" * 60)
    logger.info("PREPARAÇÃO CONCLUÍDA")
    logger.info("=" * 60)
    logger.info("\nPróximos passos:")
    logger.info("1. Verifique os arquivos gerados em data/raw/ e data/external/")
    logger.info("2. Execute: python example_usage.py")
    logger.info("3. Execute: python run_estimation.py")


if __name__ == "__main__":
    main()
