"""Visualize Brazilian HLW model results."""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from pathlib import Path
import numpy as np

# Load results (MLE-optimized Brazilian specification)
results_file = Path("outputs/results/filtered_states_brazilian.csv")
df = pd.read_csv(results_file, parse_dates=['date'])

# Create figures directory
fig_dir = Path("outputs/figures")
fig_dir.mkdir(parents=True, exist_ok=True)

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
fig_size = (14, 10)

# =================================================================
# Figure 1: r* and Real Rate Evolution
# =================================================================
fig, axes = plt.subplots(3, 1, figsize=fig_size, sharex=True)

# r* (annualized)
axes[0].plot(df['date'], df['r_star'] * 4, 'b-', linewidth=2, label='r* (taxa natural)')
axes[0].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[0].set_ylabel('Taxa Natural (%)', fontsize=11)
axes[0].set_title('Taxa Natural de Juros (r*) - Modelo HLW Brasileiro', fontsize=13, fontweight='bold')
axes[0].legend(loc='best')
axes[0].grid(True, alpha=0.3)

# Real rate vs r*
axes[1].plot(df['date'], df['r_t'] * 4, 'r-', linewidth=1.5, label='Taxa real ex-ante', alpha=0.7)
axes[1].plot(df['date'], df['r_star'] * 4, 'b-', linewidth=2, label='r* (taxa natural)')
axes[1].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[1].set_ylabel('Taxa (%)', fontsize=11)
axes[1].set_title('Taxa Real vs. Taxa Natural', fontsize=13, fontweight='bold')
axes[1].legend(loc='best')
axes[1].grid(True, alpha=0.3)

# Real rate gap
real_gap = (df['r_t'] - df['r_star']) * 4
axes[2].plot(df['date'], real_gap, 'g-', linewidth=1.5)
axes[2].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[2].fill_between(df['date'], 0, real_gap, where=(real_gap > 0), alpha=0.3, color='red', label='Contracionista')
axes[2].fill_between(df['date'], 0, real_gap, where=(real_gap < 0), alpha=0.3, color='blue', label='Expansionista')
axes[2].set_ylabel('Gap (%)', fontsize=11)
axes[2].set_xlabel('Data', fontsize=11)
axes[2].set_title('Hiato da Taxa Real (r_t - r*)', fontsize=13, fontweight='bold')
axes[2].legend(loc='best')
axes[2].grid(True, alpha=0.3)

# Format x-axis
for ax in axes:
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.xaxis.set_major_locator(mdates.YearLocator(2))

plt.tight_layout()
plt.savefig(fig_dir / "r_star_evolution.png", dpi=300, bbox_inches='tight')
print(f"Saved: {fig_dir / 'r_star_evolution.png'}")

# =================================================================
# Figure 2: Growth Components
# =================================================================
fig, axes = plt.subplots(3, 1, figsize=fig_size, sharex=True)

# Trend growth (annualized)
axes[0].plot(df['date'], df['g_t'] * 4, 'b-', linewidth=2, label='Crescimento tendencial (g_t)')
axes[0].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[0].set_ylabel('Crescimento (%)', fontsize=11)
axes[0].set_title('Crescimento Potencial', fontsize=13, fontweight='bold')
axes[0].legend(loc='best')
axes[0].grid(True, alpha=0.3)

# z_t component
axes[1].plot(df['date'], df['z_t'] * 4, 'r-', linewidth=2, label='Componente z_t')
axes[1].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[1].set_ylabel('z_t (%)', fontsize=11)
axes[1].set_title('Componente z_t de r* (r* = g_t + z_t)', fontsize=13, fontweight='bold')
axes[1].legend(loc='best')
axes[1].grid(True, alpha=0.3)

# r* decomposition
axes[2].plot(df['date'], df['g_t'] * 4, 'b--', linewidth=1.5, label='g_t', alpha=0.7)
axes[2].plot(df['date'], df['z_t'] * 4, 'r--', linewidth=1.5, label='z_t', alpha=0.7)
axes[2].plot(df['date'], df['r_star'] * 4, 'k-', linewidth=2, label='r* = g_t + z_t')
axes[2].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[2].set_ylabel('Taxa (%)', fontsize=11)
axes[2].set_xlabel('Data', fontsize=11)
axes[2].set_title('Decomposição de r*', fontsize=13, fontweight='bold')
axes[2].legend(loc='best')
axes[2].grid(True, alpha=0.3)

for ax in axes:
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.xaxis.set_major_locator(mdates.YearLocator(2))

plt.tight_layout()
plt.savefig(fig_dir / "growth_components.png", dpi=300, bbox_inches='tight')
print(f"Saved: {fig_dir / 'growth_components.png'}")

# =================================================================
# Figure 3: Output Gap and Inflation
# =================================================================
fig, axes = plt.subplots(3, 1, figsize=fig_size, sharex=True)

# Output gap
axes[0].plot(df['date'], df['h_t'] * 100, 'purple', linewidth=2, label='Output gap')
axes[0].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[0].fill_between(df['date'], 0, df['h_t'] * 100, where=(df['h_t'] > 0), alpha=0.3, color='red', label='Economia aquecida')
axes[0].fill_between(df['date'], 0, df['h_t'] * 100, where=(df['h_t'] < 0), alpha=0.3, color='blue', label='Economia ociosa')
axes[0].set_ylabel('Output Gap (%)', fontsize=11)
axes[0].set_title('Hiato do Produto (h_t)', fontsize=13, fontweight='bold')
axes[0].legend(loc='best')
axes[0].grid(True, alpha=0.3)

# Actual vs Potential GDP
axes[1].plot(df['date'], df['y_t'], 'k-', linewidth=1.5, label='PIB observado', alpha=0.7)
axes[1].plot(df['date'], df['y_star'], 'b--', linewidth=2, label='PIB potencial (y*)')
axes[1].set_ylabel('Log PIB', fontsize=11)
axes[1].set_title('PIB Observado vs. Potencial', fontsize=13, fontweight='bold')
axes[1].legend(loc='best')
axes[1].grid(True, alpha=0.3)

# Inflation
axes[2].plot(df['date'], df['pi_t'], 'orange', linewidth=2, label='Inflação (IPCA)')
axes[2].axhline(y=4, color='r', linestyle='--', alpha=0.5, label='Meta 4%')
axes[2].axhline(y=0, color='k', linestyle='--', alpha=0.3)
axes[2].set_ylabel('Inflação (% a.a.)', fontsize=11)
axes[2].set_xlabel('Data', fontsize=11)
axes[2].set_title('Inflação (IPCA anualizado)', fontsize=13, fontweight='bold')
axes[2].legend(loc='best')
axes[2].grid(True, alpha=0.3)

for ax in axes:
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.xaxis.set_major_locator(mdates.YearLocator(2))

plt.tight_layout()
plt.savefig(fig_dir / "output_gap_inflation.png", dpi=300, bbox_inches='tight')
print(f"Saved: {fig_dir / 'output_gap_inflation.png'}")

# =================================================================
# Summary Statistics
# =================================================================
print("\n" + "=" * 70)
print("ESTATÍSTICAS RESUMIDAS - MODELO HLW BRASILEIRO")
print("=" * 70)

print(f"\nPeríodo: {df['date'].min().strftime('%Y-%m')} a {df['date'].max().strftime('%Y-%m')}")
print(f"Observações: {len(df)}")

print("\n1. TAXA NATURAL (r*) - Anualizada:")
print(f"   Média: {df['r_star'].mean() * 4:.2%}")
print(f"   Mediana: {df['r_star'].median() * 4:.2%}")
print(f"   Desvio-padrão: {df['r_star'].std() * 4:.2%}")
print(f"   Mínimo: {df['r_star'].min() * 4:.2%}")
print(f"   Máximo: {df['r_star'].max() * 4:.2%}")
print(f"   Último valor: {df['r_star'].iloc[-1] * 4:.2%}")

print("\n2. CRESCIMENTO POTENCIAL (g_t) - Anualizado:")
print(f"   Média: {df['g_t'].mean() * 4:.2%}")
print(f"   Último valor: {df['g_t'].iloc[-1] * 4:.2%}")

print("\n3. COMPONENTE z_t - Anualizado:")
print(f"   Média: {df['z_t'].mean() * 4:.2%}")
print(f"   Último valor: {df['z_t'].iloc[-1] * 4:.2%}")

print("\n4. HIATO DO PRODUTO (h_t):")
print(f"   Média: {df['h_t'].mean() * 100:.2f}%")
print(f"   Último valor: {df['h_t'].iloc[-1] * 100:.2f}%")

real_gap = (df['r_t'] - df['r_star']) * 4
print("\n5. HIATO DA TAXA REAL (r_t - r*):")
print(f"   Média: {real_gap.mean():.2%}")
print(f"   Último valor: {real_gap.iloc[-1]:.2%}")

print("\n6. ÚLTIMOS 5 TRIMESTRES:")
recent = df.tail(5)[['date', 'r_star', 'g_t', 'h_t']]
recent = recent.copy()
recent['r_star_aa'] = recent['r_star'] * 4
recent['g_t_aa'] = recent['g_t'] * 4
recent['h_t_pct'] = recent['h_t'] * 100
print(recent[['date', 'r_star_aa', 'g_t_aa', 'h_t_pct']].to_string(index=False))

print("\n" + "=" * 70)
print("Gráficos salvos em: outputs/figures/")
print("=" * 70)
