# HLW-COVID Brasil

Implementação do modelo Holston-Laubach-Williams (HLW) adaptado ao Brasil com ajustes para o período COVID-19 para estimação da taxa natural de juros (r*).

## Visão Geral

Este projeto implementa o modelo de espaço de estados HLW para estimar a taxa natural de juros no Brasil, incorporando ajustes estruturais para o período da pandemia COVID-19 (2020-2022) através do Oxford Stringency Index.

### Características principais:

- Modelo HLW com ajustes COVID
- Estimação via Filtro de Kalman e Maximum Likelihood Estimation (MLE)
- Dados trimestrais de 2000-2024
- Incorporação do Oxford Stringency Index como medida de restrições COVID

## Estrutura do Projeto

```
hlw-covid-brasil/
├── data/
│   ├── raw/              # Dados brutos (.xlsm, .csv)
│   ├── processed/        # Dados processados
│   └── external/         # Dados externos (Oxford Stringency)
├── src/
│   ├── data/            # Módulos de carregamento e pré-processamento
│   ├── models/          # Implementações de modelos (futuro)
│   ├── estimation/      # Rotinas de estimação (futuro)
│   └── utils/           # Utilitários e validação
├── notebooks/           # Jupyter notebooks para análise
├── config/              # Arquivos de configuração
├── tests/               # Testes unitários
└── outputs/             # Resultados e figuras
```

## Instalação

### Pré-requisitos

- Python 3.9 ou superior
- pip

### Setup

1. Clone o repositório ou baixe os arquivos

2. Crie um ambiente virtual (recomendado):

```bash
python -m venv venv
```

3. Ative o ambiente virtual:

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

4. Instale as dependências:

```bash
pip install -r requirements.txt
```

## Configuração dos Dados

### Dados necessários:

1. **PIB Real Trimestral**
   - Fonte: IBGE (Contas Nacionais Trimestrais)
   - Formato: `.xlsm` ou via API
   - Local: `data/raw/pib_trimestral.xlsm`

2. **IPCA (Inflação)**
   - Fonte: IBGE
   - Núcleo e Cheio
   - Local: `data/raw/ipca.xlsm`

3. **Taxa Selic**
   - Fonte: Banco Central do Brasil
   - Taxa nominal, fim do trimestre
   - Local: `data/raw/selic.xlsm`

4. **Oxford Stringency Index**
   - Fonte: [Oxford COVID-19 Government Response Tracker](https://www.bsg.ox.ac.uk/research/covid-19-government-response-tracker)
   - País: Brasil
   - Local: `data/external/oxford_stringency_index.csv`

### Formato dos arquivos

Consulte `config/config.yaml` para detalhes sobre:
- Nomes das planilhas esperados
- Nomes das colunas
- Formatos de data

## Uso

### 1. Configuração

Edite `config/config.yaml` para ajustar:
- Caminhos dos arquivos de dados
- Período da amostra
- Parâmetros do modelo
- Configurações COVID

### 2. Carregamento de Dados

```python
from pathlib import Path
from src.data.loader import DataLoader

# Inicializar o loader
config_path = Path("config/config.yaml")
loader = DataLoader(config_path)

# Carregar todos os dados
raw_data = loader.load_all()

# Ou carregar individualmente
pib = loader.load_pib()
ipca = loader.load_ipca()
selic = loader.load_selic()
stringency = loader.load_stringency_index()
```

### 3. Pré-processamento

```python
from src.data.preprocessing import DataPreprocessor

# Inicializar o preprocessor
preprocessor = DataPreprocessor(config_path)

# Criar dados prontos para o modelo
model_data = preprocessor.create_model_data(raw_data)
```

### 4. Exploração de Dados

Execute o notebook de exploração:

```bash
jupyter notebook notebooks/01_exploracao_dados.ipynb
```

## Variáveis do Modelo

O modelo trabalha com as seguintes variáveis trimestrais:

- **y_t**: Log do PIB real
- **π_t**: Inflação trimestral anualizada
- **π_t-2,4**: Média das inflações defasadas (t-2, t-3, t-4)
- **r_t**: Taxa de juros real ex-ante
- **d_t**: Stringency Index (0-100)
- **D_2020, D_2021, D_2022**: Dummies para períodos COVID

## Modelo Matemático

### Equação de Medição (Curva de Phillips):
```
π_t = π_t-2,4 + κ_2020·D_2020 + κ_2021·D_2021 + κ_2022·D_2022 + ε_π,t
```

### Equações de Estado:
```
y_t = y*_t + ỹ_t
ỹ_t = φ·ỹ_t-1 - α·(r_t-1 - r*_t-1) + ε_ỹ,t
y*_t = y*_t-1 + g_t-1 + ε_y*,t
g_t = g_t-1 + ε_g,t
r*_t = r*_t-1 + β·d_t + ε_r*,t
```

### Parâmetros a Estimar:
- λ_g, λ_z: Razões de variância
- a_r: Persistência do hiato da taxa real
- b_y: Coeficiente do hiato do produto
- κ_2020, κ_2021, κ_2022: Efeitos COVID
- β: Efeito do stringency index

## Desenvolvimento

### Estrutura dos Módulos

**src/data/loader.py**: Carregamento de dados de múltiplas fontes

**src/data/preprocessing.py**: Transformação de dados brutos em formato modelo-pronto

**src/utils/validation.py**: Validação de qualidade de dados

### Logging

O projeto usa o módulo `logging` do Python. Configure o nível de log em `config/config.yaml`:

```yaml
logging:
  level: "INFO"  # DEBUG, INFO, WARNING, ERROR, CRITICAL
```

## Estimação do Modelo

### Executar estimação completa:

```bash
python run_estimation.py
```

Este script executa todo o pipeline:
1. Carrega e pré-processa os dados
2. Estima os parâmetros via MLE
3. Extrai r* e estados latentes
4. Salva resultados em `outputs/results/`

### Analisar resultados:

```bash
jupyter notebook notebooks/02_analise_resultados.ipynb
```

## Status do Desenvolvimento

- [x] Módulos de carregamento e pré-processamento de dados
- [x] Modelo de espaço de estados HLW com ajustes COVID
- [x] Implementação do Filtro de Kalman
- [x] Função de log-verossimilhança para MLE
- [x] Rotina de otimização (scipy.optimize)
- [x] Extração de r* e estados latentes
- [x] Notebook de visualização de resultados
- [ ] Análise de sensibilidade
- [ ] Comparação com literatura existente

## Referências

- Holston, K., Laubach, T., & Williams, J. C. (2017). "Measuring the natural rate of interest: International trends and determinants." *Journal of International Economics*.

- Oxford COVID-19 Government Response Tracker: https://www.bsg.ox.ac.uk/research/covid-19-government-response-tracker

## Licença

Este projeto é para fins acadêmicos e de pesquisa.

## Contato

Para questões ou sugestões, abra uma issue no repositório.

---

**Nota**: Este é um projeto em desenvolvimento. A implementação do modelo econométrico (Filtro de Kalman, MLE) será adicionada nas próximas etapas.
