# Comparação: Stage 1 Nossa Implementação vs HLW Oficial

**Data**: 2025-11-20

---

## 📐 EQUAÇÕES DO STATE-SPACE MODEL

### **Estados (ambos iguais)**
```
ξ_t = [y*_t, y*_{t-1}, y*_{t-2}]'   (3x1)
```

### **Observações (ambos iguais)**
```
y_t = [100·log(GDP_t), π_t]'   (2x1)
```

---

## 🔢 MATRIZ A (Regressores Exógenos)

### **HLW Oficial** (linhas 12-17 de unpack.parameters.stage1.R):
```r
A <- matrix(0, 7, 2)
A[1:2, 1] <- parameters[1:2]      # a_1, a_2 (IS curve)
A[1, 2]   <- parameters[5]         # b_2 (output gap → inflation)
A[3:4, 2] <- parameters[3:4]       # b_1, b_3 (inflation lags)
A[5, 2]   <- 1 - sum(A[3:4, 2])   # ⚠️ CONSTRAINT: (1-b_1-b_3)
A[6:7, 2] <- parameters[6:7]       # b_4, b_5 (oil, import prices)
```

**Estrutura da matriz A (7 regressores x 2 observações)**:
```
           [GDP_obs]  [Inflation_obs]
x_1:          a_1           0
x_2:          a_2           0
x_3:          0            b_1
x_4:          0            b_3
x_5:          0         (1-b_1-b_3)  ← CONSTRAINT!
x_6:          0            b_4
x_7:          0            b_5
```

**Onde x_data contém**:
```r
x.data <- cbind(
  100*log.output[8:(T+7)],          # x_1: log_y_{t-1}
  100*log.output[7:(T+6)],          # x_2: log_y_{t-2}
  inflation[8:(T+7)],                # x_3: π_{t-1}
  (inflation[7:...]+...)/3,          # x_4: π_{t-2,4} (avg)
  (inflation[4:...]+...)/4,          # x_5: π_{t-5,8} (avg) ← COM CONSTRAINT!
  relative.oil.price.inflation[...], # x_6: oil
  relative.import.price.inflation[...] # x_7: import
)
```

### **Nossa Implementação** (linhas 185-190):
```python
A = np.zeros((7, 2))
A[0:2, 0] = [a_y1, a_y2]              # IS curve ✅
A[0, 1] = b_y                          # output gap → inflation ✅
A[2:4, 1] = [b_pi, b_pi_lag]          # π_{t-1}, π_{t-2,4} ✅
A[4, 1] = 1 - b_pi - b_pi_lag         # ⚠️ CONSTRAINT ✅
A[5:7, 1] = [kappa_2020, kappa_2021]  # COVID dummies
```

**Estrutura da nossa matriz A**:
```
           [GDP_obs]  [Inflation_obs]
x_1:         a_y1           0
x_2:         a_y2           0
x_3:          0           b_pi
x_4:          0        b_pi_lag
x_5:          0     (1-b_pi-b_pi_lag) ← CONSTRAINT ✅
x_6:          0        kappa_2020
x_7:          0        kappa_2021
```

**Onde x_data contém** (linhas 316-321):
```python
x_data = np.column_stack([
    log_gdp[T_start-1:-1] * 100,     # x_1: log_y_{t-1}
    log_gdp[T_start-2:-2] * 100,     # x_2: log_y_{t-2}
    inflation[T_start-1:-1],          # x_3: π_{t-1}
    inflation_lags[T_start:],         # x_4: π_{t-2,4} ✅
    inflation_lags2[T_start:],        # x_5: π_{t-5,8} ✅ COM CONSTRAINT
    covid_dummies[T_start:, 0],       # x_6: D_2020
    covid_dummies[T_start:, 1],       # x_7: D_2021
])
```

**✅ CORRETO!** A estrutura está idêntica ao HLW.

---

## 🔢 MATRIZ H (Observação dos Estados)

### **HLW Oficial** (linhas 19-22):
```r
H <- matrix(0, 3, 2)
H[1, 1] <- 1                # y*_t → GDP
H[2:3, 1] <- -parameters[1:2]  # -a_1·y*_{t-1}, -a_2·y*_{t-2} → GDP
H[2, 2] <- -parameters[5]   # -b_2·y*_{t-1} → Inflation
```

**Estrutura H (3 estados x 2 obs)**:
```
           [GDP_obs]  [Inflation_obs]
y*_t:         1              0
y*_{t-1}:   -a_1           -b_2
y*_{t-2}:   -a_2            0
```

### **Nossa Implementação** (linhas 193-196):
```python
H = np.zeros((3, 2))
H[0, 0] = 1.0                          # y*_t → GDP ✅
H[1:3, 0] = [-a_y1, -a_y2]            # → GDP ✅
H[1, 1] = -b_y                         # → Inflation ✅
```

**Estrutura H**:
```
           [GDP_obs]  [Inflation_obs]
y*_t:         1              0
y*_{t-1}:   -a_y1          -b_y
y*_{t-2}:   -a_y2           0
```

**✅ CORRETO!**

---

## 🔢 MATRIZ F (Transição de Estados)

### **HLW Oficial** (linhas 28-29):
```r
F <- matrix(0, 3, 3)
F[1, 1] <- F[2, 1] <- F[3, 2] <- 1
```

**Estrutura F (3x3)**:
```
         [y*_t] [y*_{t-1}] [y*_{t-2}]
y*_t:      1        0           0
y*_{t-1}:  1        0           0
y*_{t-2}:  0        1           0
```

**Interpretação**:
- `y*_t = 1·y*_{t-1} + g + ε`  (linha 1)
- `y*_{t-1} = 1·y*_{t-1}` (linha 2: copia valor anterior)
- `y*_{t-2} = 1·y*_{t-2}` (linha 3: copia valor anterior)

### **Nossa Implementação** (linhas 199-203):
```python
F = np.array([
    [1, 0, 0],  # y*_t = y*_{t-1} + g
    [1, 0, 0],  # y*_{t-1} = y*_{t-1}
    [0, 1, 0]   # y*_{t-2} = y*_{t-2}
])
```

**✅ CORRETO!**

---

## 🔢 MATRIZ Q (Covariância dos Estados)

### **HLW Oficial** (linhas 25-26):
```r
Q <- matrix(0, 3, 3)
Q[1, 1] <- parameters[11]^2
```

**Estrutura Q (3x3)**:
```
Q = diag([σ_y*^2, 0, 0])
```

### **Nossa Implementação** (linha 206):
```python
Q = np.diag([sigma_y_star**2, 0, 0])
```

**✅ CORRETO!** Apenas o primeiro estado (y*_t) tem inovação.

---

## 🔢 MATRIZ R (Covariância das Observações)

### **HLW Oficial** (linha 24):
```r
R <- diag(c(parameters[9]^2, parameters[10]^2))
```

**Estrutura R (2x2)**:
```
R = diag([σ_IS^2, σ_π^2])
```

### **Nossa Implementação** (linha 209):
```python
R = np.diag([sigma_is**2, sigma_ph**2])
```

**✅ CORRETO!**

---

## 🔢 VETOR CONSTANTE (cons)

### **HLW Oficial** (linhas 31-32):
```r
cons <- matrix(0, 3, 1)
cons[1, 1] <- parameters[8]
```

**Estrutura cons (3x1)**:
```
cons = [g, 0, 0]'
```

### **Nossa Implementação** (linha 212):
```python
cons = np.array([[g], [0], [0]])
```

**✅ CORRETO!**

---

## 📊 EQUAÇÃO DE OBSERVAÇÃO COMPLETA

### **HLW Oficial**:
```
y_t = A'·x_t + H'·ξ_t + ε_t

Onde:
  y_t = [100·log(GDP_t), π_t]'
  x_t = [log_y_{t-1}, log_y_{t-2}, π_{t-1}, π_{t-2,4}, π_{t-5,8}, oil, import]'
  ξ_t = [y*_t, y*_{t-1}, y*_{t-2}]'
  ε_t ~ N(0, R)
```

**Expandido**:
```
100·log(GDP_t) = a_1·log_y_{t-1} + a_2·log_y_{t-2}
                 + 1·y*_t - a_1·y*_{t-1} - a_2·y*_{t-2}
                 + ε_GDP

π_t = b_1·π_{t-1} + b_3·π_{t-2,4} + (1-b_1-b_3)·π_{t-5,8}
      + b_4·oil + b_5·import
      + b_2·output_gap_{t-1}     (onde output_gap = log_y - y*)
      + ε_π
```

**Simplificando a equação de GDP**:
```
100·log(GDP_t) = a_1·[log_y_{t-1} - y*_{t-1}] + a_2·[log_y_{t-2} - y*_{t-2}]
                 + y*_t + ε_GDP

Ou seja:
100·log(GDP_t) = a_1·ỹ_{t-1} + a_2·ỹ_{t-2} + y*_t + ε_GDP
```

**✅ Essa é a IS curve sem taxa de juros!**

### **Nossa Implementação**:
```
100·log(GDP_t) = a_y1·ỹ_{t-1} + a_y2·ỹ_{t-2} + y*_t + ε_GDP

π_t = b_π·π_{t-1} + b_π_lag·π_{t-2,4} + (1-b_π-b_π_lag)·π_{t-5,8}
      + κ_2020·D_2020 + κ_2021·D_2021
      + b_y·output_gap_{t-1}
      + ε_π
```

**✅ ESTRUTURA IDÊNTICA AO HLW!**

**Diferenças**:
- HLW usa: oil prices, import prices
- Nós usamos: COVID dummies (D_2020, D_2021)

---

## 🔍 KALMAN FILTER

### **HLW Oficial** (kalman.log.likelihood.R):
```r
# Predict
xi.ttm1 <- F %*% xi.tt + cons
P.ttm1  <- F %*% P.tt %*% t(F) + Q

# Innovation
y.ttm1  <- t(A) %*% x.data[t,] + t(H) %*% xi.ttm1
v.t     <- y.data[t,] - y.ttm1
S.t     <- t(H) %*% P.ttm1 %*% H + R

# Update
K.t     <- P.ttm1 %*% H %*% solve(S.t)
xi.tt   <- xi.ttm1 + K.t %*% v.t
P.tt    <- P.ttm1 - K.t %*% t(H) %*% P.ttm1
```

### **Nossa Implementação** (linhas 246-271):
```python
# Predict
xi_ttm1 = F @ xi_tt + cons
P_ttm1 = F @ P_tt @ F.T + Q

# Innovation
y_pred = A.T @ x_data[t] + H.T @ xi_ttm1.flatten()
prediction_error = y_data[t] - y_pred
HPHR = H.T @ P_ttm1 @ H + R

# Update
K = P_ttm1 @ H @ np.linalg.solve(HPHR, np.eye(2))
xi_tt = xi_ttm1 + K @ prediction_error.reshape(-1, 1)
P_tt = P_ttm1 - K @ H.T @ P_ttm1
```

**✅ IDÊNTICO!**

---

## ⚠️ ENTÃO POR QUE O MLE VAI PARA OS LIMITES?

### **Causa Raiz: Problema de Identificação**

**Sem a taxa de juros** no Stage 1, o modelo tem dificuldade em separar:
- **y\*** (produto potencial)
- **ỹ** (output gap)

**Por quê?**
- A equação de GDP é: `100·log(GDP_t) = a_y1·ỹ_{t-1} + a_y2·ỹ_{t-2} + y*_t + ε`
- O modelo pode explicar variações em GDP de duas formas:
  1. Aumentar **y\*** (potencial) → requer aumentar σ_y*
  2. Aumentar **ỹ** (gap) → requer aumentar efeito IS (a_y1, a_y2)

**O MLE escolhe aumentar σ_y*** porque:
- Menor constraint estrutural
- Melhor fit aos dados (log-likelihood maior)

**E reduz b_y** porque:
- Output gap perde importância na Phillips curve
- Modelo explica inflação via outras fontes (lags, COVID)

---

## 🎯 CONCLUSÃO

**Nossas equações estão CORRETAS e IDÊNTICAS ao HLW!**

**O problema não é implementação, é teórico**:
- Stage 1 SEM taxa de juros tem identificação fraca
- MLE aproveita isso para overfitar (σ↑, b_y↓)
- Isso é **esperado** e acontece no HLW também!

**Soluções**:
1. **Aceitar** e usar median-unbiased estimator para λ (HLW faz isso)
2. **Apertar bounds** para valores econômicamente plausíveis
3. **Penalizar** desvios grandes do OLS
4. **Bayesian priors** (mais complexo)

**Recomendação**: Testar **Opção 2** (bounds mais apertados) baseados em literatura brasileira.
