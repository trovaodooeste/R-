# Comparação: Bounds Originais → Ampliados → Com COVID

**Data**: 2025-11-18 20:38
**Objetivo**: Avaliar impacto progressivo das melhorias no modelo

---

## 📊 EVOLUÇÃO DOS RESULTADOS

### VERSÃO 1: Bounds Originais (10 parâmetros)
- **Log-likelihood**: -216,91
- **r* médio**: 9,79% ao ano
- **Problemas**: 5/10 parâmetros nos limites, output gap 81%

### VERSÃO 2: Bounds Ampliados (10 parâmetros)
- **Log-likelihood**: -80,14 ⬆️ (+136 pontos!)
- **r* médio**: 3,27% ao ano
- **Melhoria**: Output gap plausível (-1,49%)

### VERSÃO 3: Bounds Ampliados + COVID (14 parâmetros) ✅ ATUAL
- **Log-likelihood**: **-77,90** ⬆️ (+2,24 pontos!)
- **r* médio**: **13,10%** ao ano
- **Variação**: 6,28% - 17,90%
- **Último r***: 11,72% (Q1 2025)

---

## PARÂMETROS ESTIMADOS (VERSÃO ATUAL - 14 PARAMS)

| Parâmetro | Estimativa | Limite? | Interpretação |
|-----------|------------|---------|---------------|
| **λ_g** | 0,2085 | ❌ | Crescimento potencial pode variar |
| **λ_z** | 0,0373 | ✅ Fixo | Como Stock-Watson |
| **a_y1** | 0,0000 | ✅ Mín | ⚠️ Sem 1º lag (problema!) |
| **a_y2** | -0,2702 | ❌ | 2º lag negativo |
| **a_r** | 0,0030 | ❌ | Efeito taxa real muito fraco |
| **b_y** | 0,5000 | ✅ Máx | Output gap → inflação (forte!) |
| **b_π** | 0,5616 | ❌ | Persistência inflação moderada |
| **σ_h** | 0,0233 | ❌ | Volatilidade output gap baixa |
| **σ_y*** | 0,0125 | ❌ | Volatilidade PIB potencial baixa |
| **σ_π** | 3,7967 | ❌ | Volatilidade inflação ALTA |
| **kappa_2020** | **2,7976** | ❌ | ⬆️ Choque inflação +2,8pp |
| **kappa_2021** | **1,4384** | ❌ | ⬆️ Choque inflação +1,4pp |
| **kappa_2022** | **-2,9632** | ❌ | ⬇️ Deflação -3,0pp |
| **beta** | **0,0000** | ✅ Mín | Stringency sem efeito em z_t |

**ATENÇÃO**: 4/14 parâmetros nos limites (28%)

---

## ANÁLISE DOS PARÂMETROS COVID

### kappa (Structural Breaks na Inflação)

Os parâmetros kappa capturam choques exógenos na inflação durante COVID:

**kappa_2020 = +2,80pp**
- Inflação anormalmentE ALTA em 2020
- Possíveis causas: choque de oferta, ruptura cadeias de suprimento
- Compatível com dados brasileiros (inflação alimentar disparou)

**kappa_2021 = +1,44pp**
- Ainda inflação elevada, mas amenizando
- Transição do choque inicial

**kappa_2022 = -2,96pp**
- REVERSÃO: Deflação em 2022
- Possíveis causas: normalização cadeias, queda demanda pós-pandemia
- Pode refletir política monetária contracionista do BCB

### beta (Stringency → z_t)

**beta = 0,00** significa que o **Oxford Stringency Index NÃO afeta z_t**.

**Interpretação**:
- Restrições de mobilidade (lockdowns) não afetaram componente estrutural da taxa natural
- z_t permanece CONSTANTE em 4% ao ano (0,01 trimestral)
- Choques COVID foram puramente inflacionários (kappa), não estruturais

**Implicações**:
- r* varia apenas via g_t (crescimento potencial)
- Modelo sugere COVID não mudou estrutura da economia (z_t)
- Apenas choques temporários na inflação

---

## COMPONENTES DE r*

Como r*_t = g_t + z_t:

**z_t (constante)**: 4,00% ao ano
**g_t (variável)**: Média 9,10% ao ano
- Último valor: 7,72% (Q1 2025)
- Queda recente no crescimento potencial

**r* (soma)**: Média 13,10% ao ano
- Último valor: 11,72% (Q1 2025)
- **MUITO ACIMA do BCB** (~4,5%)

---

## COMPARAÇÃO COM BCB E LITERATURA

| Fonte | r* Estimado | Nossa Estimativa | Diferença |
|-------|-------------|------------------|-----------|
| BCB (oficial) | ~4,5% | **13,10%** | +8,6pp ⚠️ |
| Roberto Torres | ? | 13,10% | ? |
| Literatura int'l | 2-4% | 13,10% | +9-11pp ⚠️ |

**PROBLEMA**: Nossa estimativa está **absurdamente alta!**

---

## ⚠️ PROBLEMAS IDENTIFICADOS

### 1. a_y1 = 0 (CRÍTICO)
- Output gap sem primeiro lag é **implausível**
- Curva IS sem persistência
- Possível problema de identificação

### 2. b_y no limite superior (0,50)
- Phillips curve "travada" no máximo
- Pode estar compensando outros parâmetros mal identificados

### 3. r* muito alto (13,10%)
- 3x maior que estimativas do BCB
- Incompatível com literatura internacional
- Possível especificação incorreta do modelo

### 4. beta = 0
- Stringency index sem efeito
- Talvez z_t não seja a variável correta para COVID
- Ou realmente não houve efeito estrutural

### 5. Hessiana singular
- Sem erros-padrão
- Indica problema de identificação
- Alguns parâmetros podem estar perfeitamente correlacionados

---

## DIAGNÓSTICO

**HIPÓTESE 1**: Modelo brasileiro (8 estados) pode ser **over-parametrizado**
- 14 parâmetros para 99 observações
- Alguns parâmetros não identificados
- Solução: Fixar alguns parâmetros ou usar prior bayesiano

**HIPÓTESE 2**: Dados brasileiros violam premissas do HLW
- Alta inflação estrutural (não é choque temporário)
- Taxa real muito volátil
- Solução: Adaptar equações estruturais

**HIPÓTESE 3**: COVID deveria afetar outras equações
- Não apenas Phillips (kappa) ou z_t (beta)
- Talvez afetar curva IS (demanda) diretamente
- Solução: Adicionar COVID na equação IS

---

## PRÓXIMOS PASSOS

### URGENTE
1. ❌ **Testar constraint a_y1 >= 0,1** (forçar persistência)
2. ❌ **Comparar com Roberto Torres** (verificar se ele tem r* alto também)
3. ❌ **Plotar séries temporais** para identificar períodos problemáticos

### IMPORTANTE
4. ❌ **Implementar RTS Smoother** (estimativas suavizadas)
5. ❌ **Bootstrap** para erros-padrão
6. ❌ **Testar 3-stage** (como Torres) vs MLE simultâneo

### INVESTIGAÇÃO
7. ❌ **Adicionar COVID na IS curve** (não apenas Phillips)
8. ❌ **Testar modelo 6 estados** (HLW original) para comparar
9. ❌ **Prior bayesiano** para parâmetros problemáticos

---

## CONCLUSÃO

**Progressão positiva**:
1. ✅ Bounds ampliados melhoraram LL drasticamente (-217 → -80)
2. ✅ COVID parameters estimados (kappa significativos)
3. ✅ Output gap plausível (-1,50% vs 81% antes)

**Problemas persistentes**:
1. ❌ a_y1 = 0 (sem persistência IS curve)
2. ❌ r* = 13,10% (3x maior que BCB)
3. ❌ Hessiana singular (sem SE)
4. ❌ beta = 0 (stringency sem efeito)

**Próximo passo crítico**:
Comparar com Roberto Torres para ver se r* alto é problema nosso ou característica do modelo brasileiro.

Se Torres também tem r* ~13%, então:
- Modelo brasileiro pode ser inadequado para Brasil
- Precisamos adaptar especificação

Se Torres tem r* ~4-5%, então:
- Nosso código tem bug
- Ou parâmetros mal identificados
