# HLW Model - Brazilian Specification

Este documento descreve como usar a implementação brasileira do modelo HLW (Holston-Laubach-Williams) com ajustes para COVID-19.

## Diferenças da Especificação Brasileira

A implementação brasileira difere do modelo HLW original em aspectos importantes:

### 1. **Curva IS com 2 Lags**
```
h_t = a_y1·h_t-1 + a_y2·h_t-2 + (a_r/2)·[(r-r*)_t-1 + (r-r*)_t-2] + ε_1t
```
- Dois lags do output gap (h_t-1 e h_t-2)
- Dois lags do real rate gap [(r-r*)_t-1 e (r-r*)_t-2]

### 2. **Curva de Phillips com Persistência**
```
π_t = b_π·π_t-1 + (1-b_π)·π_t-2,4 + b_y·h_t-1 + COVID_effects + ε_2t
```
- Inclui persistência inflacionária (π_t-1)
- Inclui output gap (h_t-1)

### 3. **Razões de Variância Stock-Watson (1998)**
```
λ_g = σ_g / σ_y*
λ_z = (a_r·σ_z) / σ_h
```

### 4. **Vetor de Estados Expandido (8 estados)**
```
x_t = [y*_t, g_t, z_t, h_t, h_t-1, h_t-2, (r-r*)_t-1, (r-r*)_t-2]
```

Onde:
- `r*_t = g_t + z_t` (decomposição da taxa natural)

## Guia de Uso Rápido

### Instalação de Dependências

```bash
pip install -r requirements.txt
```

### Executar Estimação Completa (Three-Stage Method)

```bash
# Test individual stages
python test_stage1_fixed.py   # Stage 1: OLS + Kalman MLE (without interest rate)
python test_stage2_fixed.py   # Stage 1→2 pipeline with median-unbiased estimator

# Run full three-stage pipeline
python run_three_stage_estimation.py
```

Este script:
1. **Stage 1**: Estima parâmetros preliminares via OLS + Kalman MLE (sem taxa de juros)
2. **Stage 2**: Adiciona taxa de juros, fixa parâmetros do Stage 1, estima λ_g com median-unbiased
3. **Stage 3**: Decomposição completa r* = g + z, estima λ_z com median-unbiased
4. Salva resultados em `outputs/results/`

### Resultados Gerados

Após a execução, os seguintes arquivos são criados:

1. **`outputs/stage1/`**
   - Resultados do Stage 1 (parâmetros preliminares, estados filtrados)

2. **`outputs/stage2/`**
   - Resultados do Stage 2 (r* preliminar, λ_g median-unbiased)

3. **`outputs/stage3/`**
   - Resultados do Stage 3 (r* final, g_t, z_t, λ_z median-unbiased)

4. **`outputs/results/three_stage_results.csv`**
   - Séries temporais consolidadas:
     - `r_star`: Taxa natural de juros
     - `y_star`: PIB potencial
     - `g_t`: Taxa de crescimento tendencial
     - `output_gap`: Hiato do produto
     - `z_t`: Componente adicional de r*

## Uso Programático

### Exemplo Básico (Three-Stage Method)

```python
from pathlib import Path
from src.data.loader import DataLoader
from src.data.preprocessing import DataPreprocessor
from src.estimation import (
    Stage1EstimatorFixed,
    Stage2EstimatorFixed,
    compute_lambda_g_median_unbiased
)

# 1. Carregar e preprocessar dados
config_path = Path("config/config.yaml")
loader = DataLoader(config_path)
raw_data = loader.load_all()

preprocessor = DataPreprocessor(config_path)
model_data = preprocessor.create_model_data(raw_data)

# 2. Stage 1: Preliminary estimation (without interest rate)
print("Running Stage 1...")
stage1 = Stage1EstimatorFixed(config_path)
stage1_results = stage1.estimate(model_data)

print(f"Stage 1 OLS: b_y = {stage1_results['params']['b_y']:.4f}")

# 3. Stage 2: Add interest rate (fix Stage 1 params)
print("\nRunning Stage 2...")
lambda_g_initial = 0.05  # Initial guess
stage2 = Stage2EstimatorFixed(config_path, stage1_results, lambda_g_initial)
stage2_results = stage2.estimate(model_data)

# 4. Compute median-unbiased λ_g
lambda_g_mub = compute_lambda_g_median_unbiased(stage2_results, model_data)

# 5. Re-run Stage 2 with corrected λ_g if needed
if abs(lambda_g_mub - lambda_g_initial) > 0.01:
    print(f"\nRe-running Stage 2 with λ_g = {lambda_g_mub:.6f}")
    stage2_final = Stage2EstimatorFixed(config_path, stage1_results, lambda_g_mub)
    stage2_results = stage2_final.estimate(model_data)

# 6. Extract r*
r_star = stage2_results['r_star_preliminary']
print(f"\nTaxa natural média: {r_star.mean()*100:.2f}% anual")
print(f"Taxa natural última: {r_star[-1]*100:.2f}% anual")
```

## Parâmetros do Modelo

### Estimação por Estágio (Three-Stage Method)

**Stage 1** (OLS + Kalman MLE, sem taxa de juros):
- `a_y1`, `a_y2`: Lags do output gap
- `b_pi`: Persistência inflacionária (peso em π_t-1)
- `b_y`: Coeficiente do output gap
- `g`: Taxa de crescimento tendencial
- `sigma_h`: Desvio-padrão do choque do output gap
- `sigma_pi`: Desvio-padrão do choque de inflação
- `sigma_y_star`: Desvio-padrão do choque do PIB potencial

**Stage 2** (Fixa Stage 1, adiciona taxa de juros):
- `a_r`: Coeficiente do real rate gap
- `a_0`, `a_g`: Constantes da Curva IS
- `lambda_g`: Razão σ_g / σ_y* (median-unbiased estimator)
- Variâncias: σ_h, σ_π, σ_y*

**Stage 3** (Fixa Stages 1 & 2, decomposição r* = g + z):
- `lambda_z`: Razão (a_r·σ_z) / σ_h (median-unbiased estimator)
- `beta`: Efeito do stringency index em z_t (se COVID incluído)
- Variâncias: apenas refinamento

### Razões de Variância (Stock-Watson 1998)

A median-unbiased estimation corrige o viés de pequenas amostras:
- **λ_g** = σ_g / σ_y* (Stage 2)
- **λ_z** = (a_r · σ_z) / σ_h (Stage 3)

### Configuração

Edite `config/config.yaml` para ajustar:
- Valores iniciais dos parâmetros
- Bounds para a otimização
- Períodos de amostra
- Caminhos de arquivos

## Estrutura de Arquivos

```
.
├── config/
│   └── config.yaml                           # Configuração do modelo
├── src/
│   ├── estimation/
│   │   ├── stage1_preliminary_fixed.py      # Stage 1 HLW
│   │   ├── stage2_with_interest_rate_fixed.py # Stage 2 HLW
│   │   ├── stage3_full_rstar.py             # Stage 3 HLW
│   │   └── median_unbiased_estimator.py     # Stock-Watson (1998)
│   ├── models/
│   │   └── hlw_model_brazilian.py           # Modelo brasileiro (8 estados)
│   ├── data/
│   │   ├── loader.py                        # Carregamento de dados
│   │   └── preprocessing.py                 # Preprocessamento
│   └── utils/
│       └── validation.py                    # Validação de dados
├── test_stage1_fixed.py                      # Test Stage 1
├── test_stage2_fixed.py                      # Test Stage 1→2 pipeline
├── run_three_stage_estimation.py             # Script principal completo
└── CLAUDE.md                                 # Documentação completa
```

## Comparação: Original vs. Brasileiro

| Aspecto | Original HLW | Brasileiro |
|---------|--------------|------------|
| **Estados** | 6 | 8 |
| **Lags IS** | 1 output gap, 1 real rate gap | 2 output gaps, 2 real rate gaps |
| **Phillips** | π_t-2,4 apenas | π_t-1 + π_t-2,4 + h_t-1 |
| **Variâncias** | Razões simples | Stock-Watson (1998) |
| **r***| Estado único | r* = g_t + z_t |

## Próximos Passos

1. **Análise de Resultados**: Use os notebooks em `notebooks/` para visualizar os resultados
2. **Smoothing**: Implemente o Rauch-Tung-Striebel (RTS) smoother para obter estimativas suavizadas
3. **Bootstrap**: Calcule intervalos de confiança via bootstrap
4. **Sensibilidade**: Teste robustez a diferentes especificações

## Referências

- Holston, K., Laubach, T., & Williams, J. C. (2017). "Measuring the natural rate of interest: International trends and determinants." *Journal of International Economics*.
- Stock, J. H., & Watson, M. W. (1998). "Median unbiased estimation of coefficient variance in a time-varying parameter model." *Journal of the American Statistical Association*.

## Suporte

Para questões ou problemas, consulte:
- [CLAUDE.md](CLAUDE.md) - Documentação técnica completa
- [config/config.yaml](config/config.yaml) - Configurações do modelo
- Logs em `outputs/hlw_covid.log`
