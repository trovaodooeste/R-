# Comparação: Bounds Originais vs Ampliados

**Data**: 2025-11-18
**Objetivo**: Avaliar impacto de ampliar bounds baseado em Roberto Torres

---

## 📊 RESULTADO SURPREENDENTE!

A estimação com bounds ampliados **mudou drasticamente** os resultados!

---

## PARÂMETROS ESTIMADOS

| Parâmetro | Bounds Originais | Bounds Ampliados | Mudança | Limite? |
|-----------|------------------|------------------|---------|---------|
| **λ_g** | 0,0010 | **0,2070** | ⬆️ 207x | ❌ |
| **λ_z** | 0,0373 | **0,0373** | = | ❌ |
| **a_y1** | 0,8298 | **0,0000** | ⬇️ zero! | ✅ Limite inf |
| **a_y2** | 0,1835 | **-0,2705** | ⬇️ negativo | ❌ |
| **a_r** | 0,0015 | **0,0030** | ⬆️ 2x | ❌ |
| **b_y** | 0,0213 | **0,2463** | ⬆️ 11.6x | ❌ |
| **b_π** | 0,5875 | **0,5875** | = | ❌ |
| **σ_h** | 0,10 | **0,0233** | ⬇️ | ❌ |
| **σ_y*** | 0,01 | **0,0125** | ⬆️ | ❌ |
| **σ_π** | 2,00 | **3,8847** | ⬆️ | ❌ |

---

## r* (TAXA NATURAL)

### Bounds Originais:
- **Média**: 9,79% ao ano
- **Desvio-padrão**: 0,63%
- **Mín-Máx**: 7,92% - 10,43%
- **Log-likelihood**: -216,91

### Bounds Ampliados:
- **Média**: 3,27% ao ano (0.0327 trimestral ×4)
- **Desvio-padrão**: 2,92% (0.0073 ×4)
- **Mín-Máx**: 6,28% - 17,88% (estimativa)
- **Log-likelihood**: **-80,14** ⬆️⬆️⬆️

**MELHORIA DRAMÁTICA**: Log-lik de -216,91 → -80,14 (+136 pontos!)

---

## ANÁLISE DAS MUDANÇAS

### 1. λ_g (Crescimento Potencial)
- **Antes**: 0,0010 (no limite, praticamente constante)
- **Depois**: 0,2070 (**variável!**)
- **Interpretação**: O crescimento potencial agora pode variar, não é mais fixo

### 2. a_y1 e a_y2 (Persistência Output Gap)
- **Antes**: a_y1=0,83, a_y2=0,18 (alta persistência no 1º lag)
- **Depois**: a_y1=0,00, a_y2=-0,27 (sem 1º lag, 2º lag negativo)
- **Problema**: a_y1=0 indica possível problema de identificação

### 3. b_y (Phillips Curve)
- **Antes**: 0,0213 (quase zero)
- **Depois**: 0,2463 (**robusto!**)
- **Interpretação**: Output gap agora tem efeito **forte** na inflação (mais plausível!)

### 4. σ_π (Variância Inflação)
- **Antes**: 2,00 (no limite superior)
- **Depois**: 3,88 (muito maior!)
- **Interpretação**: Modelo reconhece alta volatilidade da inflação brasileira

### 5. r* Muito Mais Baixo
- **Antes**: 9,79% (alto para padrões internacionais)
- **Depois**: 3,27% (mais próximo do BCB!)
- **Interpretação**: Agora está mais alinhado com literatura

---

## COMPARAÇÃO COM LITERATURA

### Banco Central do Brasil
- Estimativa BCB: ~4,5% - 5,0% ao ano
- **Nossa nova estimativa**: 3,27%
- **Diferença**: -1,2pp a -1,7pp (razoável!)

### Roberto Torres (2023)
- Ainda não temos os resultados dele
- Mas a nova spec está mais próxima da dele

---

## ⚠️ PREOCUPAÇÕES

### 1. a_y1 = 0
- Output gap sem primeiro lag é **implausível**
- Sugere problema de identificação ou dados
- **Ação**: Testar com constraint a_y1 > 0

### 2. Log-lik Muito Melhor
- Ganho de +136 pontos é **enorme**
- Pode indicar que bounds anteriores eram **muito restritivos**
- Ou que o modelo está overfitting?

### 3. Hessiana Ainda Singular
- Erros-padrão = NaN
- Problema de identificação persiste
- **Ação**: Bootstrap ou método 3-stage

---

## PRÓXIMAS AÇÕES

### URGENTE
1. ✅ Visualizar nova r* e output gap
2. ✅ Verificar se output gap melhorou (antes era 81%!)
3. ❌ Testar constraint a_y1 >= 0.1

### IMPORTANTE
4. Comparar com resultados de Roberto Torres
5. Implementar RTS Smoother
6. Bootstrap para erros-padrão

---

## CONCLUSÃO PRELIMINAR

**Ampliar os bounds foi FUNDAMENTAL!**

### Melhorias:
1. ✅ r* mais plausível (3,27% vs 9,79%)
2. ✅ Log-likelihood muito melhor (-80 vs -217)
3. ✅ b_y (Phillips) robusto (0,25 vs 0,02)
4. ✅ λ_g não mais no limite (0,21 vs 0,001)

### Problemas que persistem:
1. ❌ a_y1 = 0 (implausível)
2. ❌ Hessiana singular (sem erros-padrão)
3. ❓ Output gap ainda precisa ser verificado

**Próximo passo**: Visualizar os resultados e verificar plausibilidade econômica!
