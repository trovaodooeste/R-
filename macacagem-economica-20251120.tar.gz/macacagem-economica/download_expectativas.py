"""
Download de expectativas de inflação do BCB (Boletim Focus)
usando a API do Banco Central do Brasil
"""
import pandas as pd
import requests
from datetime import datetime
import json

print("=" * 70)
print("DOWNLOAD DE EXPECTATIVAS DE INFLAÇÃO - BCB FOCUS")
print("=" * 70)

# API do BCB - Sistema de Expectativas de Mercado
# https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/aplicacao#!/recursos

base_url = "https://olinda.bcb.gov.br/olinda/servico/Expectativas/versao/v1/odata"

# Vamos buscar expectativas mensais do IPCA para os próximos 12 meses
# Indicador: IPCA
# Periodicidade: M (mensal)

print("\n1. Buscando expectativas de IPCA (12 meses à frente)...")

# ExpectativasMercadoInflacao12Meses - Expectativas para inflação 12 meses à frente
endpoint = f"{base_url}/ExpectativasMercadoInflacao12Meses"

params = {
    "$format": "json",
    "$top": 150000  # Pegar todos os dados disponíveis
}

try:
    print(f"   URL: {endpoint}")
    response = requests.get(endpoint, params=params, timeout=60)
    response.raise_for_status()

    data = response.json()

    if 'value' in data:
        df_12m = pd.DataFrame(data['value'])
        print(f"   ✓ {len(df_12m)} registros baixados (antes do filtro)")

        # Filtrar apenas IPCA
        df_12m = df_12m[df_12m['Indicador'] == 'IPCA'].copy()
        print(f"   ✓ {len(df_12m)} registros do IPCA")

        # Converter datas
        df_12m['Data'] = pd.to_datetime(df_12m['Data'])
        df_12m['date'] = df_12m['Data']
        df_12m['expectativa_ipca_12m'] = df_12m['Mediana']

        # Manter apenas colunas relevantes
        df_12m = df_12m[['date', 'expectativa_ipca_12m']].copy()

        # Ordenar por data
        df_12m = df_12m.sort_values('date').reset_index(drop=True)

        print(f"\n   Período: {df_12m['date'].min()} até {df_12m['date'].max()}")
        print(f"\n   Primeiras linhas:")
        print(df_12m.head())
        print(f"\n   Últimas linhas:")
        print(df_12m.tail())

        # Salvar
        df_12m.to_csv('data/external/expectativas_inflacao_bcb.csv', index=False)
        print(f"\n✓ Salvo em: data/external/expectativas_inflacao_bcb.csv")

    else:
        print("   ❌ Erro: resposta não contém dados")
        print(f"   Resposta: {data}")

except Exception as e:
    print(f"\n❌ Erro ao baixar expectativas: {e}")
    print("\nTentando método alternativo...")

    # Método alternativo - ExpectativasMercadoTop5Mensais
    try:
        endpoint_alt = f"{base_url}/ExpectativasMercadoTop5Mensais"
        params_alt = {
            "$filter": "Indicador eq 'IPCA'",
            "$format": "json",
            "$top": 5000
        }

        response_alt = requests.get(endpoint_alt, params=params_alt, timeout=30)
        response_alt.raise_for_status()

        data_alt = response_alt.json()

        if 'value' in data_alt:
            df_alt = pd.DataFrame(data_alt['value'])
            print(f"   ✓ {len(df_alt)} registros baixados (método alternativo)")

            # Processar
            df_alt['date'] = pd.to_datetime(df_alt['Data'])
            df_alt['expectativa_ipca_12m'] = df_alt['Mediana']
            df_alt = df_alt[['date', 'expectativa_ipca_12m']].copy()
            df_alt = df_alt.sort_values('date').reset_index(drop=True)

            # Salvar
            df_alt.to_csv('data/external/expectativas_inflacao_bcb.csv', index=False)
            print(f"\n✓ Salvo em: data/external/expectativas_inflacao_bcb.csv")
            print(f"   Período: {df_alt['date'].min()} até {df_alt['date'].max()}")

        else:
            print("   ❌ Método alternativo também falhou")

    except Exception as e2:
        print(f"   ❌ Erro no método alternativo: {e2}")

print("\n" + "=" * 70)
print("DOWNLOAD CONCLUÍDO")
print("=" * 70)
