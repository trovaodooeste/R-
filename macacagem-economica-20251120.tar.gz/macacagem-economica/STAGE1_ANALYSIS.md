# Stage 1 - Análise da Implementação HLW Original

## Estrutura do rstar.stage1.R

### 1. Estimativa Inicial do Output Gap (linhas 19-21)


**Equivalente Python**: Usar HP filter ou regressão OLS com tendência

### 2. IS Curve - OLS sem taxa de juros (linhas 23-28)


**Resultado**: Estimativas de a_y1, a_y2

### 3. Phillips Curve - OLS (linhas 30-40)


**Resultado**: Estimativas de b_π, coef. π_{t-2,4}, b_y, coef. choques

### 4. Prepara Dados para Kalman (linhas 42-50)


### 5. Valores Iniciais para MLE (linha 53)


**Vetor de parâmetros**:
- b.is[1:2]: a_y1, a_y2 (da IS curve OLS)
- b.ph[1:2]: coef. π_{t-1} e π_{t-2,4}
- b.ph[4:6]: b_y, coef. petróleo, coef. importação
- 0.85: valor fixo (provavelmente λ_g ou σ)
- s.is, s.ph: desvios-padrão dos resíduos OLS
- 0.5: outro parâmetro (σ_y*?)

### 6. MLE com Kalman Filter (linhas 69-73)


**Chave**: Usa valores OLS como chute inicial, refina via MLE

## Diferenças da Nossa Implementação

| Aspecto | HLW Original | Nossa Implementação | Status |
|---------|--------------|---------------------|--------|
| Output gap inicial | HP filter implícito (OLS) | Não faz | ❌ Faltando |
| IS curve OLS | Sim (chute inicial) | Não | ❌ Faltando |
| Phillips OLS | Sim (chute inicial) | Não | ❌ Faltando |
| Kalman Filter | Refina OLS | Tentou rodar direto | ⚠️ Incompleto |
| Choques de preço | Petróleo + Importação | Só COVID | ⚠️ Diferente |

## Ações Corretivas Necessárias

### Imediato
1. ✅ Adicionar step de HP filter para output gap inicial
2. ✅ Adicionar OLS para IS curve (a_y1, a_y2)
3. ✅ Adicionar OLS para Phillips curve (b_π, b_y)
4. ✅ Usar resultados OLS como initial_parameters para MLE

### Médio Prazo
1. Implementar log.likelihood.wrapper equivalente
2. Implementar kalman.states.wrapper equivalente
3. Testar com dados brasileiros

### Importante
- **NÃO** precisamos dos choques de petróleo/importação (Brasil não tem esses dados facilmente)
- **SIM** mantemos choques COVID (κ_2020, κ_2021, κ_2022)
- **SIM** precisamos estrutura de 2 observações (GDP + inflação) no Kalman

