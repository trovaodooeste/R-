# CLAUDE.md - HLW Brasil

**Last Updated**: 2025-11-20
**Status**: Stage 1 & 2 implemented ✅ | Stage 3 pending | Median-unbiased integrated ✅

---

## Estimation Methods

### THREE-STAGE METHOD (CANONICAL) ✅ CURRENT
Following Stock & Watson (1998) and HLW (2017) official replication code.

**Why use 3-stage instead of MLE Full?**
- More stable identification (fixes structural params before estimating variances)
- Reduces parameter correlation issues
- Follows canonical HLW methodology
- Expected to produce more plausible r* estimates

**Stage 1**: Preliminary estimation WITHOUT interest rate
- **States**: [y*_t, y*_t-1, y*_t-2]
- **Method**: OLS → Kalman Filter MLE
- **Estimates**: a_y1, a_y2, b_π, b_y, g, σ_ỹ, σ_π, σ_y*, φ
- **Status**: ✅ Implemented (OLS working, MLE has convergence issues)
- **Known Issue**: MLE pushes b_y to bounds (0.025) - theoretical identification problem

**Stage 2**: Add interest rate and growth component
- **States**: [y*_t, y*_t-1, y*_t-2, g_t-1]
- **FIXES**: a_y1, a_y2, b_π, b_y from Stage 1
- **Estimates**: a_r, a_0, a_g, σ_ỹ, σ_π, σ_y*, λ_g
- **Median-Unbiased**: Computes λ_g using Stock-Watson (1998) test for structural breaks
- **Status**: ✅ Implemented with median-unbiased estimator
- **Known Issue**: r* = 1514% (caused by bad Stage 1 MLE params being fixed)

**Stage 3**: Full r* decomposition (r* = g + z)
- **States**: [y*_t, g_t, z_t, ỹ_t, ỹ_t-1, ỹ_t-2, (r-r*)_t-1, (r-r*)_t-2]
- **FIXES**: All structural params from Stages 1 & 2
- **Estimates**: ONLY variances (σ_ỹ, σ_π, σ_y*) and β
- **Median-Unbiased**: Computes λ_z using Stock-Watson (1998)
- **Status**: 🔧 File exists but not yet tested (needs filterpy)

**Test commands**:
```bash
python test_stage1_fixed.py   # Stage 1 OLS vs MLE
python test_stage2_fixed.py   # Stage 1→2 pipeline with median-unbiased
python run_three_stage_estimation.py  # Full pipeline (Stage 3 pending)
```

---

### MLE FULL (REMOVED) ❌
**Obsolete files removed on 2025-11-20**. This method is no longer used.
See [LIMPEZA_ARQUIVOS.md](LIMPEZA_ARQUIVOS.md) for cleanup details.

---

## Model Specification (Brazilian, 8 states)

**State Vector**: [y*_t, g_t, z_t, ỹ_t, ỹ_t-1, ỹ_t-2, (r-r*)_t-1, (r-r*)_t-2]

**Natural Rate**: r*_t = g_t + z_t

**Variance Ratios (Stock-Watson 1998)**:
- λ_g = σ_g / σ_y*
- λ_z = (a_r · σ_z) / σ_ỹ

---

## Key Files (Cleaned 2025-11-20)

### **Core Implementation** ✅
```
src/estimation/
  ├── __init__.py                           # Clean exports (three-stage only)
  ├── stage1_preliminary_fixed.py           # Stage 1 HLW (OLS + Kalman MLE)
  ├── stage2_with_interest_rate_fixed.py    # Stage 2 HLW (fixes Stage 1 params)
  ├── stage3_full_rstar.py                  # Stage 3 HLW (r* = g + z)
  └── median_unbiased_estimator.py          # Stock-Watson (1998) - HLW exact impl.

src/models/
  └── hlw_model_brazilian.py                # 8-state Brazilian model

src/data/
  ├── loader.py                             # Load raw data from Excel
  └── preprocessing.py                      # Create model_data DataFrame

config/
  └── config.yaml                           # Paths, bounds, estimation settings
```

### **Test Scripts** ✅
```
test_stage1_fixed.py                        # Test Stage 1 (OLS vs MLE)
test_stage2_fixed.py                        # Test Stage 1→2 with median-unbiased
run_three_stage_estimation.py               # Full pipeline (Stage 3 pending)
```

### **Documentation** ✅
```
CLAUDE.md                                   # This file
COMPARACAO_STAGE1_HLW.md                    # Line-by-line Stage 1 verification
LIMPEZA_ARQUIVOS.md                         # Cleanup log (11 files removed)
STAGE2_SPECIFICATION.md                     # Stage 2 methodology
```

### **Reference Code** (HLW 2017 Replication)
```
C:\Users\Trovao\Desktop\LW_replication\
  ├── rstar.stage1.R                        # Stage 1 reference
  ├── rstar.stage2.R                        # Stage 2 reference
  ├── rstar.stage3.R                        # Stage 3 reference
  ├── median.unbiased.estimator.stage2.R    # Median-unbiased reference
  └── unpack.parameters.stage*.R            # Matrix equation definitions
```

---

## Current Issues (2025-11-20)

### 🔴 **Priority 1: Stage 1 MLE Convergence**
**Problem**: MLE pushes b_y to lower bound (0.025) instead of OLS value (0.066)
- OLS: a_y1=0.675, b_π=0.534, b_y=0.066 ✅
- MLE: a_y1=0.984, b_π=0.723, b_y=0.025 ❌ (at bound)

**Diagnosis**: Theoretical identification problem (Stage 1 without interest rate)
**Options**:
1. Use OLS params from Stage 1 instead of MLE (quick fix)
2. Tighten bounds to economically plausible values
3. Accept MLE behavior (HLW may have same issue)

### 🔴 **Priority 2: Stage 2 r* = 1514% (Absurd)**
**Problem**: r* preliminary is 1514% annual (should be ~4-5%)
**Root Cause**: Bad Stage 1 MLE params fixed in Stage 2
**Dependency**: Fix Priority 1 first

### 🟡 **Priority 3: Median-Unbiased Not Working**
**Problem**: Warning "Output gap not available, using placeholder λ_g = 0.05"
**Fix**: Add `output_gap_filtered` to Stage 2 return dict
**Impact**: λ_g correction not applied (iterative re-estimation skipped)

---

## Next Steps for Resuming Work

### **Option A: Quick Fix (Use OLS)**
1. Modify [stage2_with_interest_rate_fixed.py:24](stage2_with_interest_rate_fixed.py#L24) to use Stage 1 OLS params instead of MLE
2. Re-run [test_stage2_fixed.py](test_stage2_fixed.py)
3. Check if r* becomes reasonable

### **Option B: Fix MLE (Deeper)**
1. Compare our Kalman Filter with HLW's calc.llh.stage1.R line-by-line
2. Check if HLW also gets b_y → bound
3. Adjust bounds or add penalty term

### **Option C: Skip Stage 1 MLE (Radical)**
1. Use only OLS params from Stage 1
2. Go straight to Stage 2 Kalman Filter
3. Test if results match HLW

---

## For Claude (Instructions)

1. **ALWAYS** use three-stage method ([stage1_preliminary_fixed.py](src/estimation/stage1_preliminary_fixed.py), [stage2_with_interest_rate_fixed.py](src/estimation/stage2_with_interest_rate_fixed.py), stage3_full_rstar.py)
2. **DO NOT** create new MLE files - obsolete implementation removed
3. **Read** [config.yaml](config/config.yaml) before running estimation
4. **Check** outputs/ for previous results before re-running
5. **Compare** with HLW reference code in `C:\Users\Trovao\Desktop\LW_replication\` when debugging
6. **Document** significant changes in this file (CLAUDE.md)

### **Quick Reference: HLW Paper Locations**
- Stock & Watson (1998): Median-unbiased variance ratio estimator
- Holston, Laubach, Williams (2017): Three-stage method, replication code
- Roberto Torres (2023): Brazilian calibration (b_y bounds, expectation data)
