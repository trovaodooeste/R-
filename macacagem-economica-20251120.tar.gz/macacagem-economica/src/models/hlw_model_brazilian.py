"""
HLW State-Space Model with COVID Adjustments - Brazilian Specification.

This module implements the Holston-Laubach-Williams model adapted for Brazil
following the specification used in Brazilian research with:
- Two lags of output gap in IS curve
- Two lags of real rate gap in IS curve
- Phillips curve with inflation persistence and output gap
- Stock-Watson (1998) variance ratios

Uses FilterPy for Kalman filtering operations.
"""

import logging
from typing import Dict, Optional, Tuple

import numpy as np
from scipy import linalg
from filterpy.kalman import KalmanFilter

logger = logging.getLogger(__name__)


class HLWModelBrazilian:
    """
    Holston-Laubach-Williams model with COVID adjustments (Brazilian specification).

    State vector (8x1):
        x_t = [y*_t, g_t, z_t, h_t, h_t-1, h_t-2, (r-r*)_t-1, (r-r*)_t-2]

    Where:
        y*_t: Potential output (trend GDP)
        g_t: Trend growth rate
        z_t: Other factors in r* (corresponds to r*_t - g_t in HLW notation)
        h_t: Output gap (ỹ_t in original notation)
        h_t-1: First lag of output gap
        h_t-2: Second lag of output gap
        (r-r*)_t-1: First lag of real rate gap
        (r-r*)_t-2: Second lag of real rate gap

    Observations (2x1):
        z_t = [y_t, π_t]

    Where:
        y_t: Log real GDP
        π_t: Inflation rate

    COVID adjustments enter through:
        - z_t (r* component) equation via stringency index (d_t)
        - π_t equation via structural break dummies (D_2020, D_2021, D_2022)

    Model equations (Brazilian specification):
        h_t = a_y1·h_t-1 + a_y2·h_t-2 + (a_r/2)·[(r-r*)_t-1 + (r-r*)_t-2] + ε_1t
        π_t = b_π·π_t-1 + (1-b_π)·π_t-2,4 + b_y·h_t-1 + κ_2020·D_2020 + κ_2021·D_2021 + κ_2022·D_2022 + ε_2t
        y*_t = y*_t-1 + g_t-1 + ε_y*t
        g_t = g_t-1 + ε_gt
        z_t = z_t-1 + β·d_t + ε_zt
        r*_t = g_t + z_t
    """

    def __init__(
        self,
        params: Dict[str, float],
        covid_data: Optional[np.ndarray] = None,
    ):
        """
        Initialize the HLW model (Brazilian specification).

        Args:
            params: Dictionary with model parameters:
                - lambda_g: Variance ratio σ_g / σ_y* (Stock-Watson)
                - lambda_z: Variance ratio (a_r·σ_z) / σ_h (Stock-Watson)
                - a_y1: First lag coefficient in IS curve
                - a_y2: Second lag coefficient in IS curve
                - a_r: Real rate gap coefficient in IS curve
                - b_y: Output gap coefficient in Phillips curve
                - b_pi: Inflation persistence in Phillips curve
                - sigma_h: SD of output gap shock
                - sigma_y_star: SD of potential output shock
                - sigma_pi: SD of inflation shock
                - kappa_2020, kappa_2021, kappa_2022: COVID effects on inflation
                - beta: Effect of stringency index on z_t (r* component)
            covid_data: Array of COVID variables (stringency, dummies) [T x 4]
                Columns: [d_t, D_2020, D_2021, D_2022]
        """
        self.params = params
        self.covid_data = covid_data

        # Extract key parameters
        self.lambda_g = params['lambda_g']
        self.lambda_z = params['lambda_z']
        self.a_y1 = params.get('a_y1', 0.5)  # First lag of output gap
        self.a_y2 = params.get('a_y2', 0.3)  # Second lag of output gap
        self.a_r = params['a_r']              # Real rate gap coefficient
        self.b_y = params['b_y']              # Output gap in Phillips curve
        self.b_pi = params.get('b_pi', 0.5)  # Inflation persistence

        # Standard deviations (base parameters)
        self.sigma_h = params.get('sigma_h', 1.0)       # Output gap shock
        self.sigma_y_star = params.get('sigma_y_star', 0.5)  # Potential GDP shock
        self.sigma_pi = params.get('sigma_pi', 0.5)     # Inflation shock

        # Derived variances using Stock-Watson (1998) ratios
        # λ_g = σ_g / σ_y*
        self.sigma_g = self.lambda_g * self.sigma_y_star

        # λ_z = (a_r·σ_z) / σ_h  =>  σ_z = (λ_z·σ_h) / a_r
        if abs(self.a_r) > 1e-10:
            self.sigma_z = (self.lambda_z * self.sigma_h) / abs(self.a_r)
        else:
            self.sigma_z = self.lambda_z * self.sigma_h

        # COVID parameters for inflation (Phillips curve)
        self.kappa_2020 = params.get('kappa_2020', 0.0)
        self.kappa_2021 = params.get('kappa_2021', 0.0)
        self.kappa_2022 = params.get('kappa_2022', 0.0)

        # Stringency index effect on z_t (r* component)
        self.beta = params.get('beta', 0.0)

        # State dimension (expanded to 8 states)
        self.n_states = 8
        self.n_obs = 2

        logger.info("HLW Model (Brazilian spec) initialized with parameters:")
        logger.info(f"  λ_g={self.lambda_g:.4f}, λ_z={self.lambda_z:.4f}")
        logger.info(f"  a_y1={self.a_y1:.4f}, a_y2={self.a_y2:.4f}, a_r={self.a_r:.4f}")
        logger.info(f"  b_y={self.b_y:.4f}, b_π={self.b_pi:.4f}")

    def build_state_matrices(
        self,
        r_t: float,
        pi_t_1: float,
        pi_t_lag_avg: float,
        t: Optional[int] = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Build state-space matrices for time t (Brazilian specification).

        State equation: x_t = F @ x_{t-1} + B @ u_t + v_t
        Observation equation: z_t = H @ x_t + D @ w_t + e_t

        Args:
            r_t: Real interest rate at time t
            pi_t_1: Inflation at time t-1 (for Phillips curve)
            pi_t_lag_avg: Lagged inflation πt-2,4 for Phillips curve
            t: Time index (for COVID variables)

        Returns:
            Tuple of (F, H, Q, R, B) where:
                F: State transition matrix (8x8)
                H: Observation matrix (2x8)
                Q: State noise covariance (8x8)
                R: Observation noise covariance (2x2)
                B: Control input matrix (8x3)
        """
        # Get COVID variables for time t
        if t is not None and self.covid_data is not None:
            d_t = self.covid_data[t, 0]  # Stringency index
            D_2020 = self.covid_data[t, 1]
            D_2021 = self.covid_data[t, 2]
            D_2022 = self.covid_data[t, 3]
        else:
            d_t = 0.0
            D_2020 = D_2021 = D_2022 = 0.0

        # ============================================
        # STATE TRANSITION MATRIX F (8x8)
        # ============================================
        # State vector: [y*_t, g_t, z_t, h_t, h_t-1, h_t-2, (r-r*)_t-1, (r-r*)_t-2]
        #
        # Brazilian specification equations:
        # y*_t = y*_{t-1} + g_{t-1} + ε_{y*,t}
        # g_t = g_{t-1} + ε_{g,t}
        # z_t = z_{t-1} + β·d_t + ε_{z,t}  (r* = g + z)
        # h_t = a_y1·h_{t-1} + a_y2·h_{t-2} + (a_r/2)·[(r-r*)_{t-1} + (r-r*)_{t-2}] + ε_{h,t}
        # h_{t-1} = h_t (lag storage)
        # h_{t-2} = h_{t-1} (lag storage)
        # (r-r*)_{t-1} = updated via control input
        # (r-r*)_{t-2} = (r-r*)_{t-1} (lag shift)

        F = np.array([
            [1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],           # y*_t = y*_{t-1} + g_{t-1}
            [0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],           # g_t = g_{t-1}
            [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0],           # z_t = z_{t-1} (+ control)
            [0.0, 0.0, 0.0, self.a_y1, 0.0, self.a_y2,
             -(self.a_r/2), -(self.a_r/2)],                      # h_t (IS curve)
            [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],           # h_{t-1} = h_t (lag)
            [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],           # h_{t-2} = h_{t-1} (lag)
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],           # (r-r*)_{t-1} (via control)
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0],           # (r-r*)_{t-2} = (r-r*)_{t-1}
        ])

        # ============================================
        # OBSERVATION MATRIX H (2x8)
        # ============================================
        # Observations: [y_t, π_t]
        #
        # y_t = y*_t + h_t
        # π_t = b_π·π_{t-1} + (1-b_π)·π_{t-2,4} + b_y·h_{t-1} + COVID effects + ε_{π,t}

        H = np.array([
            [1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],           # y_t = y*_t + h_t
            [0.0, 0.0, 0.0, 0.0, self.b_y, 0.0, 0.0, 0.0],      # π_t includes b_y·h_{t-1}
        ])

        # ============================================
        # STATE NOISE COVARIANCE Q (8x8)
        # ============================================
        Q = np.diag([
            self.sigma_y_star**2,   # var(ε_{y*})
            self.sigma_g**2,         # var(ε_g)
            self.sigma_z**2,         # var(ε_z)
            self.sigma_h**2,         # var(ε_h) - output gap shock
            0.0,                     # var(h_{t-1}) - deterministic lag
            0.0,                     # var(h_{t-2}) - deterministic lag
            0.0,                     # var((r-r*)_{t-1}) - deterministic
            0.0,                     # var((r-r*)_{t-2}) - deterministic
        ])

        # ============================================
        # OBSERVATION NOISE COVARIANCE R (2x2)
        # ============================================
        R = np.diag([
            0.0,                  # No measurement error for y_t
            self.sigma_pi**2,     # var(ε_π)
        ])

        # ============================================
        # CONTROL INPUT MATRIX B (8x3)
        # ============================================
        # Control inputs: [d_t, r_t, r*_t]
        # - d_t affects z_t via coefficient β (stringency index effect)
        # - r_t and r*_t update the (r-r*)_{t-1} state
        # Note: r*_t = g_t + z_t (we'll compute this during filtering)

        B = np.array([
            [0.0, 0.0, 0.0],         # y*_t: no control inputs
            [0.0, 0.0, 0.0],         # g_t: no control inputs
            [self.beta, 0.0, 0.0],   # z_t: β·d_t (stringency effect)
            [0.0, 0.0, 0.0],         # h_t: no control inputs
            [0.0, 0.0, 0.0],         # h_{t-1}: no control inputs
            [0.0, 0.0, 0.0],         # h_{t-2}: no control inputs
            [0.0, 1.0, -1.0],        # (r-r*)_{t-1}: r_t - r*_t
            [0.0, 0.0, 0.0],         # (r-r*)_{t-2}: no control (updated via F)
        ])

        return F, H, Q, R, B

    def get_initial_state(
        self,
        y_0: float,
        pi_0: float,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get initial state vector and covariance.

        Args:
            y_0: Initial log GDP
            pi_0: Initial inflation

        Returns:
            Tuple of (x_0, P_0) where:
                x_0: Initial state mean (8x1)
                P_0: Initial state covariance (8x8)
        """
        # Initial state: [y*_0, g_0, z_0, h_0, h_{-1}, h_{-2}, (r-r*)_{-1}, (r-r*)_{-2}]

        # Initialize with simple heuristics
        x_0 = np.array([
            y_0,        # y*_0 ≈ initial GDP
            0.01,       # g_0 ≈ 1% quarterly growth
            0.01,       # z_0 ≈ 1% (initial guess for r* component)
            0.0,        # h_0 = 0 (no initial gap)
            0.0,        # h_{-1} = 0
            0.0,        # h_{-2} = 0
            0.0,        # (r-r*)_{-1} = 0
            0.0,        # (r-r*)_{-2} = 0
        ])

        # Initial covariance - higher uncertainty for unobserved components
        P_0 = np.diag([
            0.01**2,    # var(y*_0) - small, GDP is observed
            0.01**2,    # var(g_0)
            0.02**2,    # var(z_0) - higher uncertainty
            0.05**2,    # var(h_0)
            0.05**2,    # var(h_{-1})
            0.05**2,    # var(h_{-2})
            0.02**2,    # var((r-r*)_{-1})
            0.02**2,    # var((r-r*)_{-2})
        ])

        return x_0, P_0

    def compute_steady_state_covariance(self, F: np.ndarray, Q: np.ndarray) -> np.ndarray:
        """
        Solve discrete Lyapunov equation for steady-state covariance.

        P = F @ P @ F.T + Q

        Args:
            F: State transition matrix
            Q: State noise covariance

        Returns:
            P_ss: Steady-state covariance matrix
        """
        try:
            P_ss = linalg.solve_discrete_lyapunov(F, Q)
            return P_ss
        except np.linalg.LinAlgError:
            logger.warning("Could not solve Lyapunov equation, using identity")
            return np.eye(self.n_states)


def run_kalman_filter(
    model: HLWModelBrazilian,
    observations: np.ndarray,
    real_rates: np.ndarray,
    pi_t: np.ndarray,
    pi_lags: np.ndarray,
    covid_data: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """
    Run forward Kalman filter using FilterPy on entire dataset.

    Args:
        model: HLWModelBrazilian instance with state-space specification
        observations: Observation matrix (T x 2) with [y_t, π_t]
        real_rates: Real interest rates (T,)
        pi_t: Current inflation π_t (T,)
        pi_lags: Lagged inflation πt-2,4 (T,)
        covid_data: COVID variables (T x 4) with [d_t, D_2020, D_2021, D_2022]

    Returns:
        Tuple of (x_filt, P_filt, x_pred, log_lik):
            x_filt: Filtered states (T x n)
            P_filt: Filtered covariances (T x n x n)
            x_pred: Predicted states (T x n)
            log_lik: Total log-likelihood
    """
    T = observations.shape[0]
    n_states = model.n_states
    n_obs = model.n_obs

    # Initialize FilterPy Kalman Filter
    kf = KalmanFilter(dim_x=n_states, dim_z=n_obs)

    # Get initial state
    x_0, P_0 = model.get_initial_state(observations[0, 0], observations[0, 1])
    kf.x = x_0
    kf.P = P_0

    # Storage
    x_filt = np.zeros((T, n_states))
    x_pred = np.zeros((T, n_states))
    P_filt = np.zeros((T, n_states, n_states))
    P_pred = np.zeros((T, n_states, n_states))

    total_log_lik = 0.0

    for t in range(T):
        # Get pi_t-1 for Phillips curve
        pi_t_1 = pi_t[t-1] if t > 0 else pi_t[0]

        # Build matrices for time t
        F, H, Q, R, B = model.build_state_matrices(
            r_t=real_rates[t],
            pi_t_1=pi_t_1,
            pi_t_lag_avg=pi_lags[t],
            t=t,
        )

        # Set matrices for this time step
        kf.F = F
        kf.H = H
        kf.Q = Q
        kf.R = R
        kf.B = B

        # Get COVID variables
        if covid_data is not None:
            d_t = covid_data[t, 0]
            D_2020 = covid_data[t, 1]
            D_2021 = covid_data[t, 2]
            D_2022 = covid_data[t, 3]
        else:
            d_t = 0.0
            D_2020 = D_2021 = D_2022 = 0.0

        # Compute r*_t from prior prediction (before update)
        # r*_t = g_t + z_t (states 1 and 2)
        if t == 0:
            r_star_t = kf.x[1] + kf.x[2]
        else:
            r_star_t = kf.x_prior[1] + kf.x_prior[2]

        # Control input: [d_t, r_t, r*_t]
        u = np.array([d_t, real_rates[t], r_star_t])

        # Predict step
        kf.predict(u=u)
        x_pred[t] = kf.x_prior.copy()
        P_pred[t] = kf.P_prior.copy()

        # Deterministic observation component (Phillips curve)
        # π_t = b_π·π_{t-1} + (1-b_π)·π_{t-2,4} + b_y·h_{t-1} + COVID effects + ε_π
        d_obs = np.array([
            0.0,  # No deterministic part for y_t
            model.b_pi * pi_t_1
            + (1 - model.b_pi) * pi_lags[t]
            + model.kappa_2020 * D_2020
            + model.kappa_2021 * D_2021
            + model.kappa_2022 * D_2022
        ])

        # Adjusted observation
        z = observations[t] - d_obs

        # Update step
        kf.update(z)
        x_filt[t] = kf.x.copy()
        P_filt[t] = kf.P.copy()

        # Compute log-likelihood contribution
        # Innovation and innovation covariance
        z_pred = H @ kf.x_prior
        nu = observations[t] - z_pred - d_obs
        S = H @ kf.P_prior @ H.T + R
        S = (S + S.T) / 2  # Ensure symmetry

        try:
            sign, logdet = np.linalg.slogdet(S)
            if sign <= 0:
                logdet = np.inf
        except np.linalg.LinAlgError:
            logdet = np.inf

        if np.isfinite(logdet):
            log_lik_t = -0.5 * (
                n_obs * np.log(2 * np.pi)
                + logdet
                + nu.T @ np.linalg.solve(S, nu)
            )
            total_log_lik += log_lik_t
        else:
            total_log_lik += -np.inf

    logger.info(f"Kalman filter completed: T={T}, log-lik={total_log_lik:.2f}")

    return x_filt, P_filt, x_pred, total_log_lik
