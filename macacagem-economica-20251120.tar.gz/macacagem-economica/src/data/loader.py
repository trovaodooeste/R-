"""
Data loading module for HLW-COVID Brasil project.

This module provides the DataLoader class for loading economic data
from various sources (local files, consolidated file, or APIs).
"""

import logging
from pathlib import Path
from typing import Dict, Optional, Union

import pandas as pd
import yaml


logger = logging.getLogger(__name__)


class DataLoader:
    """
    Data loader for HLW-COVID Brasil project.

    Loads economic time series data from multiple sources including:
    - PIB Real (GDP)
    - IPCA (Inflation)
    - Selic (Interest rate)
    - Oxford Stringency Index

    Attributes:
        config: Configuration dictionary loaded from YAML file.
        data_path: Base path for data files.
    """

    def __init__(self, config_path: Union[str, Path]):
        """
        Initialize the DataLoader.

        Args:
            config_path: Path to the configuration YAML file.

        Raises:
            FileNotFoundError: If config file doesn't exist.
            yaml.YAMLError: If config file is malformed.
        """
        self.config_path = Path(config_path)

        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                self.config = yaml.safe_load(f)
            logger.info(f"Configuration loaded from {config_path}")
        except yaml.YAMLError as e:
            logger.error(f"Error parsing config file: {e}")
            raise

        # Set base path relative to config file location
        self.base_path = self.config_path.parent.parent
        logger.debug(f"Base path set to: {self.base_path}")

    def _resolve_path(self, relative_path: str) -> Path:
        """
        Resolve a relative path from config to absolute path.

        Args:
            relative_path: Relative path from config file.

        Returns:
            Absolute Path object.
        """
        return self.base_path / relative_path

    def _load_from_consolidated(
        self, file_path: Path, config: Dict, target_column: str
    ) -> pd.DataFrame:
        """
        Load data from consolidated Excel file.

        Args:
            file_path: Path to the consolidated .xlsx file.
            config: Configuration dictionary for the data source.
            target_column: Name of the target column in the output DataFrame.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Consolidated file not found: {file_path}")

        try:
            df = pd.read_excel(
                file_path,
                sheet_name=config.get("sheet_name", 0),
                engine="openpyxl",
            )

            # Get column names
            date_col = config["date_column"]
            value_col = config["value_column"]

            if date_col not in df.columns or value_col not in df.columns:
                raise ValueError(
                    f"Required columns not found. Expected: {date_col}, {value_col}. "
                    f"Available: {list(df.columns)}"
                )

            df_clean = df[[date_col, value_col]].copy()
            df_clean.columns = ["date", target_column]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"Data loaded from consolidated file: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading from consolidated file: {e}")
            raise

    def load_pib(self) -> pd.DataFrame:
        """
        Load quarterly real GDP data (PIB Real Trimestral).

        Returns:
            DataFrame with columns ['date', 'pib_real'].

        Raises:
            FileNotFoundError: If PIB data file doesn't exist.
            ValueError: If required columns are missing.
        """
        config = self.config["data_sources"]["pib"]

        if config["source_type"] == "consolidated":
            file_path = self._resolve_path(self.config["paths"]["consolidated_file"])
            logger.info(f"Loading PIB data from consolidated file: {file_path}")
            return self._load_from_consolidated(file_path, config, "pib_real")
        elif config["source_type"] == "file":
            file_path = self._resolve_path(self.config["paths"]["pib_file"])
            logger.info(f"Loading PIB data from {file_path}")
            return self._load_pib_from_file(file_path, config)
        else:
            raise NotImplementedError("API loading not yet implemented")

    def _load_pib_from_file(
        self, file_path: Path, config: Dict
    ) -> pd.DataFrame:
        """
        Load PIB data from Excel file.

        Args:
            file_path: Path to the .xlsm file.
            config: Configuration dictionary for PIB source.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"PIB file not found: {file_path}")

        try:
            df = pd.read_excel(
                file_path,
                sheet_name=config.get("sheet_name", 0),
                engine="openpyxl",
            )

            # Rename columns to standard names
            date_col = config["date_column"]
            value_col = config["value_column"]

            if date_col not in df.columns or value_col not in df.columns:
                raise ValueError(
                    f"Required columns not found. Expected: {date_col}, {value_col}"
                )

            df_clean = df[[date_col, value_col]].copy()
            df_clean.columns = ["date", "pib_real"]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"PIB data loaded: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading PIB data: {e}")
            raise

    def load_ipca(self) -> pd.DataFrame:
        """
        Load IPCA inflation data (both núcleo and cheio).

        Returns:
            DataFrame with columns ['date', 'ipca_nucleo', 'ipca_cheio'].

        Raises:
            FileNotFoundError: If IPCA data file doesn't exist.
            ValueError: If required columns are missing.
        """
        config = self.config["data_sources"]["ipca"]

        if config["source_type"] == "consolidated":
            file_path = self._resolve_path(self.config["paths"]["consolidated_file"])
            logger.info(f"Loading IPCA data from consolidated file: {file_path}")
            return self._load_ipca_from_consolidated(file_path, config)
        elif config["source_type"] == "file":
            file_path = self._resolve_path(self.config["paths"]["ipca_file"])
            logger.info(f"Loading IPCA data from {file_path}")
            return self._load_ipca_from_file(file_path, config)
        else:
            raise NotImplementedError("API loading not yet implemented")

    def _load_ipca_from_consolidated(
        self, file_path: Path, config: Dict
    ) -> pd.DataFrame:
        """
        Load IPCA data from consolidated Excel file.

        Args:
            file_path: Path to the consolidated .xlsx file.
            config: Configuration dictionary for IPCA source.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Consolidated file not found: {file_path}")

        try:
            df = pd.read_excel(
                file_path,
                sheet_name=config.get("sheet_name", 0),
                engine="openpyxl",
            )

            # Get column names
            date_col = config["date_column"]
            nucleo_col = config["nucleo_column"]
            cheio_col = config["cheio_column"]

            if date_col not in df.columns:
                raise ValueError(f"Date column not found: {date_col}")

            # Check if we have separate nucleo and cheio columns
            if nucleo_col == cheio_col:
                # Using same column for both (consolidated file case)
                if nucleo_col not in df.columns:
                    raise ValueError(f"IPCA column not found: {nucleo_col}")

                cols_to_load = [date_col, nucleo_col]
                col_names = ["date", "ipca_nucleo"]

                # Check if we have expectations column
                if "expectativa_ipca" in df.columns:
                    cols_to_load.append("expectativa_ipca")
                    col_names.append("expectativa_ipca")
                    logger.info("Found inflation expectations column")

                df_clean = df[cols_to_load].copy()
                df_clean.columns = col_names
                # Duplicate the column for cheio
                df_clean["ipca_cheio"] = df_clean["ipca_nucleo"]

                logger.info("Using same IPCA column for both nucleo and cheio")
            else:
                # Separate columns
                if nucleo_col not in df.columns or cheio_col not in df.columns:
                    raise ValueError(
                        f"Required columns not found. Expected: {nucleo_col}, {cheio_col}"
                    )

                df_clean = df[[date_col, nucleo_col, cheio_col]].copy()
                df_clean.columns = ["date", "ipca_nucleo", "ipca_cheio"]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"IPCA data loaded from consolidated file: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading IPCA from consolidated file: {e}")
            raise

    def _load_ipca_from_file(
        self, file_path: Path, config: Dict
    ) -> pd.DataFrame:
        """
        Load IPCA data from Excel file.

        Args:
            file_path: Path to the .xlsm file.
            config: Configuration dictionary for IPCA source.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"IPCA file not found: {file_path}")

        try:
            df = pd.read_excel(
                file_path,
                sheet_name=config.get("sheet_name", 0),
                engine="openpyxl",
            )

            # Rename columns
            date_col = config["date_column"]
            nucleo_col = config["nucleo_column"]
            cheio_col = config["cheio_column"]

            required_cols = [date_col, nucleo_col, cheio_col]
            missing_cols = [col for col in required_cols if col not in df.columns]

            if missing_cols:
                raise ValueError(f"Missing columns: {missing_cols}")

            df_clean = df[[date_col, nucleo_col, cheio_col]].copy()
            df_clean.columns = ["date", "ipca_nucleo", "ipca_cheio"]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"IPCA data loaded: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading IPCA data: {e}")
            raise

    def load_selic(self) -> pd.DataFrame:
        """
        Load Selic interest rate data (nominal, end of quarter).

        Returns:
            DataFrame with columns ['date', 'selic_nominal'].

        Raises:
            FileNotFoundError: If Selic data file doesn't exist.
            ValueError: If required columns are missing.
        """
        config = self.config["data_sources"]["selic"]

        if config["source_type"] == "consolidated":
            file_path = self._resolve_path(self.config["paths"]["consolidated_file"])
            logger.info(f"Loading Selic data from consolidated file: {file_path}")
            return self._load_from_consolidated(file_path, config, "selic_nominal")
        elif config["source_type"] == "file":
            file_path = self._resolve_path(self.config["paths"]["selic_file"])
            logger.info(f"Loading Selic data from {file_path}")
            return self._load_selic_from_file(file_path, config)
        else:
            raise NotImplementedError("API loading not yet implemented")

    def _load_selic_from_file(
        self, file_path: Path, config: Dict
    ) -> pd.DataFrame:
        """
        Load Selic data from Excel file.

        Args:
            file_path: Path to the .xlsm file.
            config: Configuration dictionary for Selic source.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Selic file not found: {file_path}")

        try:
            df = pd.read_excel(
                file_path,
                sheet_name=config.get("sheet_name", 0),
                engine="openpyxl",
            )

            # Rename columns
            date_col = config["date_column"]
            value_col = config["value_column"]

            if date_col not in df.columns or value_col not in df.columns:
                raise ValueError(
                    f"Required columns not found. Expected: {date_col}, {value_col}"
                )

            df_clean = df[[date_col, value_col]].copy()
            df_clean.columns = ["date", "selic_nominal"]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"Selic data loaded: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading Selic data: {e}")
            raise

    def load_stringency_index(self) -> pd.DataFrame:
        """
        Load Oxford COVID-19 Government Response Stringency Index for Brazil.

        Returns:
            DataFrame with columns ['date', 'stringency_index'].

        Raises:
            FileNotFoundError: If stringency data file doesn't exist.
            ValueError: If Brazil data is not found or columns are missing.
        """
        config = self.config["data_sources"]["stringency"]
        file_path = self._resolve_path(self.config["paths"]["stringency_file"])

        logger.info(f"Loading Stringency Index from {file_path}")

        if config["source_type"] == "file":
            return self._load_stringency_from_file(file_path, config)
        else:
            raise NotImplementedError("API loading not yet implemented")

    def _load_stringency_from_file(
        self, file_path: Path, config: Dict
    ) -> pd.DataFrame:
        """
        Load Stringency Index from CSV file.

        Args:
            file_path: Path to the CSV file.
            config: Configuration dictionary for Stringency source.

        Returns:
            DataFrame with standardized columns.
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Stringency file not found: {file_path}")

        try:
            df = pd.read_csv(file_path)

            # Filter for Brazil
            country = config["country"]
            if "country" in df.columns or "Country" in df.columns:
                country_col = "country" if "country" in df.columns else "Country"
                df = df[df[country_col] == country].copy()

                if len(df) == 0:
                    raise ValueError(f"No data found for {country}")

            # Get date and value columns
            date_col = config["date_column"]
            value_col = config["value_column"]

            if date_col not in df.columns or value_col not in df.columns:
                raise ValueError(
                    f"Required columns not found. Expected: {date_col}, {value_col}"
                )

            df_clean = df[[date_col, value_col]].copy()
            df_clean.columns = ["date", "stringency_index"]

            # Convert date to datetime
            df_clean["date"] = pd.to_datetime(df_clean["date"])

            # Sort by date
            df_clean = df_clean.sort_values("date").reset_index(drop=True)

            logger.info(
                f"Stringency Index loaded: {len(df_clean)} observations from "
                f"{df_clean['date'].min()} to {df_clean['date'].max()}"
            )

            return df_clean

        except Exception as e:
            logger.error(f"Error loading Stringency Index: {e}")
            raise

    def load_all(self) -> Dict[str, pd.DataFrame]:
        """
        Load all data sources.

        Returns:
            Dictionary with keys: 'pib', 'ipca', 'selic', 'stringency'
            and DataFrame values.

        Note:
            This method attempts to load all data sources. If any source
            fails, it logs a warning but continues with other sources.
        """
        data = {}
        sources = ["pib", "ipca", "selic", "stringency_index"]

        for source in sources:
            try:
                if source == "pib":
                    data["pib"] = self.load_pib()
                elif source == "ipca":
                    data["ipca"] = self.load_ipca()
                elif source == "selic":
                    data["selic"] = self.load_selic()
                elif source == "stringency_index":
                    data["stringency"] = self.load_stringency_index()
            except Exception as e:
                logger.warning(f"Failed to load {source}: {e}")
                data[source] = None

        successful = [k for k, v in data.items() if v is not None]
        logger.info(f"Successfully loaded {len(successful)}/{len(sources)} data sources")

        return data
