"""
Data preprocessing module for HLW-COVID Brasil project.

This module provides the DataPreprocessor class for transforming
raw data into model-ready format.
"""

import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import yaml


logger = logging.getLogger(__name__)


class DataPreprocessor:
    """
    Data preprocessor for HLW-COVID Brasil project.

    Transforms raw economic data into model-ready format:
    - Calculates log GDP (yt)
    - Computes annualized quarterly inflation (πt)
    - Derives ex-ante real interest rate (rt)
    - Processes quarterly stringency index (dt)
    - Creates Phillips curve inflation measure (πt-2,4)

    Attributes:
        config: Configuration dictionary loaded from YAML file.
    """

    def __init__(self, config_path: Path):
        """
        Initialize the DataPreprocessor.

        Args:
            config_path: Path to the configuration YAML file.

        Raises:
            FileNotFoundError: If config file doesn't exist.
        """
        self.config_path = Path(config_path)

        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        with open(self.config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        logger.info("DataPreprocessor initialized")

    def calculate_log_gdp(self, pib_df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate log of real GDP (yt).

        Args:
            pib_df: DataFrame with columns ['date', 'pib_real'].

        Returns:
            DataFrame with columns ['date', 'pib_real', 'y_t'].
        """
        df = pib_df.copy()

        # Calculate log GDP
        df["y_t"] = np.log(df["pib_real"])

        logger.info("Log GDP calculated")
        return df

    def calculate_inflation(self, ipca_df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate quarterly annualized inflation rate (πt).

        Creates splice between IPCA núcleo and IPCA cheio, then converts
        to annualized quarterly rate.

        Args:
            ipca_df: DataFrame with columns ['date', 'ipca_nucleo', 'ipca_cheio'].

        Returns:
            DataFrame with columns ['date', 'ipca_nucleo', 'ipca_cheio', 'pi_t'].
        """
        df = ipca_df.copy()

        # Get splice date from config
        splice_date = self.config["data_sources"]["ipca"].get(
            "splice_date", "2006-Q1"
        )
        splice_date = pd.to_datetime(splice_date)

        # Create splice: use núcleo before splice_date, cheio after
        df["ipca_splice"] = np.where(
            df["date"] < splice_date,
            df["ipca_nucleo"],
            df["ipca_cheio"],
        )

        # Get annualization factor from config
        annualization_factor = self.config["preprocessing"]["inflation"][
            "annualization_factor"
        ]

        # Convert to annualized quarterly rate
        # If data is in monthly %, need to convert
        # Assuming data is already in % per period, convert to quarterly annualized
        df["pi_t"] = df["ipca_splice"] * annualization_factor / 100

        logger.info(f"Inflation calculated with splice at {splice_date}")
        return df

    def calculate_phillips_inflation(
        self, inflation_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Calculate Phillips curve inflation measure (πt-2,4).

        πt-2,4 = average(πt-2, πt-3, πt-4)

        Args:
            inflation_df: DataFrame with 'pi_t' column.

        Returns:
            DataFrame with additional 'pi_t_lag_avg' column.
        """
        df = inflation_df.copy()

        # Get lags from config
        lags = self.config["preprocessing"]["phillips_inflation"]["lags"]

        # Create lagged inflation columns
        lagged_cols = []
        for lag in lags:
            col_name = f"pi_t_lag{lag}"
            df[col_name] = df["pi_t"].shift(lag)
            lagged_cols.append(col_name)

        # Calculate average (πt-2,4)
        df["pi_t_lag_avg"] = df[lagged_cols].mean(axis=1)

        # Add third lag (πt-5,8) for HLW constraint
        third_lag_cols = []
        for lag in range(5, 9):  # lags 5, 6, 7, 8
            col_name = f"pi_t_lag{lag}"
            df[col_name] = df["pi_t"].shift(lag)
            third_lag_cols.append(col_name)
        df["pi_t_lag_avg2"] = df[third_lag_cols].mean(axis=1)

        logger.info(f"Phillips inflation calculated using lags: {lags}")
        logger.info(f"Third lag (πt-5,8) calculated for HLW constraint")
        return df

    def calculate_real_rate(
        self,
        selic_df: pd.DataFrame,
        inflation_df: pd.DataFrame,
        expectations_col: str = None,
    ) -> pd.DataFrame:
        """
        Calculate ex-ante real interest rate (rt).

        rt = Selic_nominal - E[πt+1]
        where E[πt+1] can be either survey expectations (if available)
        or approximated by moving average of past inflation.

        Args:
            selic_df: DataFrame with 'selic_nominal' column.
            inflation_df: DataFrame with 'pi_t' column.
            expectations_col: Column name with inflation expectations (if available).

        Returns:
            DataFrame with columns ['date', 'selic_nominal', 'pi_expected', 'r_t'].
        """
        # Merge selic and inflation on date
        df = pd.merge(selic_df, inflation_df[["date", "pi_t"]], on="date", how="left")

        # If expectations column provided and exists, use it
        if expectations_col and expectations_col in inflation_df.columns:
            df = pd.merge(df, inflation_df[["date", expectations_col]], on="date", how="left")
            # Survey expectations are already forward-looking (12 months ahead), no need to shift
            # But they're in annual % (not quarterly * 400), so keep as is
            df["pi_expected"] = df[expectations_col]
            logger.info(f"Real interest rate calculated using survey expectations from {expectations_col}")
        else:
            # Calculate expected inflation using moving average (fallback)
            ma_window = self.config["preprocessing"]["real_rate"]["ma_window"]
            df["pi_expected"] = df["pi_t"].rolling(window=ma_window, min_periods=1).mean()

            # Shift forward to get E[πt+1]
            df["pi_expected"] = df["pi_expected"].shift(-1)
            logger.info(f"Real interest rate calculated using MA({ma_window}) for expectations")

        # Calculate real rate
        df["r_t"] = df["selic_nominal"] - df["pi_expected"]

        return df

    def process_stringency_index(
        self, stringency_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Process stringency index to quarterly frequency.

        If data is daily, aggregates to quarterly average.

        Args:
            stringency_df: DataFrame with columns ['date', 'stringency_index'].

        Returns:
            DataFrame with quarterly stringency index.
        """
        df = stringency_df.copy()

        # Ensure date is datetime
        df["date"] = pd.to_datetime(df["date"])

        # Check if data is daily (needs aggregation) or already quarterly
        date_diff = df["date"].diff().dt.days.median()

        if date_diff <= 31:  # Data is monthly or more frequent
            logger.info("Aggregating stringency index to quarterly frequency")

            # Create quarter column
            df["quarter"] = df["date"].dt.to_period("Q")

            # Aggregate to quarterly
            df_quarterly = (
                df.groupby("quarter")["stringency_index"]
                .mean()
                .reset_index()
            )

            # Convert quarter back to timestamp (end of quarter)
            df_quarterly["date"] = df_quarterly["quarter"].dt.to_timestamp(
                how="end"
            )
            df_quarterly = df_quarterly[["date", "stringency_index"]]
        else:
            logger.info("Stringency index already in quarterly frequency")
            df_quarterly = df

        # Rename column for consistency
        df_quarterly = df_quarterly.rename(
            columns={"stringency_index": "d_t"}
        )

        return df_quarterly

    def align_series(
        self, data_dict: Dict[str, pd.DataFrame]
    ) -> pd.DataFrame:
        """
        Align all time series on common dates.

        Args:
            data_dict: Dictionary with processed DataFrames.
                Expected keys: 'pib', 'inflation', 'selic', 'stringency'

        Returns:
            Single DataFrame with all variables aligned by date.
        """
        # Start with GDP data
        df_merged = data_dict["pib"][["date", "y_t"]].copy()

        # Add inflation
        if "inflation" in data_dict:
            df_merged = pd.merge(
                df_merged,
                data_dict["inflation"][["date", "pi_t", "pi_t_lag_avg", "pi_t_lag_avg2"]],
                on="date",
                how="outer",
            )

        # Add real rate
        if "selic" in data_dict:
            df_merged = pd.merge(
                df_merged,
                data_dict["selic"][["date", "r_t"]],
                on="date",
                how="outer",
            )

        # Add stringency
        if "stringency" in data_dict:
            df_merged = pd.merge(
                df_merged,
                data_dict["stringency"][["date", "d_t"]],
                on="date",
                how="outer",
            )

        # Sort by date
        df_merged = df_merged.sort_values("date").reset_index(drop=True)

        # Apply sample period filters
        start_date = pd.to_datetime(self.config["sample"]["start_date"])
        end_date = pd.to_datetime(self.config["sample"]["end_date"])

        df_merged = df_merged[
            (df_merged["date"] >= start_date) & (df_merged["date"] <= end_date)
        ]

        logger.info(
            f"Series aligned: {len(df_merged)} observations from "
            f"{df_merged['date'].min()} to {df_merged['date'].max()}"
        )

        return df_merged

    def create_covid_dummies(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create COVID period dummy variables.

        Creates dummies for:
        - D_2020: Q2-Q4 2020
        - D_2021: Q1-Q4 2021
        - D_2022: Q1-Q4 2022

        Args:
            df: DataFrame with 'date' column.

        Returns:
            DataFrame with additional dummy columns.
        """
        df = df.copy()

        # Extract year and quarter
        df["year"] = df["date"].dt.year
        df["quarter"] = df["date"].dt.quarter

        # Create 2020 dummy (Q2-Q4)
        df["D_2020"] = (
            (df["year"] == 2020) & (df["quarter"].isin([2, 3, 4]))
        ).astype(int)

        # Create 2021 dummy (all quarters)
        df["D_2021"] = (df["year"] == 2021).astype(int)

        # Create 2022 dummy (all quarters)
        df["D_2022"] = (df["year"] == 2022).astype(int)

        # Drop temporary columns
        df = df.drop(columns=["year", "quarter"])

        logger.info("COVID period dummies created")
        return df

    def create_model_data(
        self, raw_data: Dict[str, pd.DataFrame]
    ) -> pd.DataFrame:
        """
        Create model-ready dataset from raw data.

        Main entry point that orchestrates all preprocessing steps.

        Args:
            raw_data: Dictionary with raw DataFrames from DataLoader.
                Expected keys: 'pib', 'ipca', 'selic', 'stringency'

        Returns:
            DataFrame ready for model estimation with columns:
                - date: Quarterly dates
                - y_t: Log real GDP
                - pi_t: Annualized quarterly inflation
                - pi_t_lag_avg: Phillips curve inflation
                - r_t: Ex-ante real interest rate
                - d_t: Stringency index
                - D_2020, D_2021, D_2022: COVID dummies
        """
        logger.info("Starting data preprocessing pipeline")

        processed_data = {}

        # Process GDP
        if raw_data.get("pib") is not None:
            logger.info("Processing GDP data")
            processed_data["pib"] = self.calculate_log_gdp(raw_data["pib"])
        else:
            raise ValueError("PIB data is required")

        # Process inflation
        if raw_data.get("ipca") is not None:
            logger.info("Processing inflation data")
            inflation_df = self.calculate_inflation(raw_data["ipca"])
            inflation_df = self.calculate_phillips_inflation(inflation_df)

            # Add inflation expectations if available
            if "expectativa_ipca" in raw_data["ipca"].columns:
                inflation_df = pd.merge(
                    inflation_df,
                    raw_data["ipca"][["date", "expectativa_ipca"]],
                    on="date",
                    how="left"
                )
                logger.info("Inflation expectations added to inflation DataFrame")

            processed_data["inflation"] = inflation_df
        else:
            raise ValueError("IPCA data is required")

        # Process real interest rate
        if raw_data.get("selic") is not None:
            logger.info("Processing real interest rate")
            # Check if we have inflation expectations
            expectations_col = None
            if "expectativa_ipca" in processed_data["inflation"].columns:
                expectations_col = "expectativa_ipca"
                logger.info("Using inflation expectations from survey data")
            processed_data["selic"] = self.calculate_real_rate(
                raw_data["selic"], processed_data["inflation"], expectations_col
            )
        else:
            logger.warning("Selic data not available, skipping real rate calculation")

        # Process stringency index
        if raw_data.get("stringency") is not None:
            logger.info("Processing stringency index")
            processed_data["stringency"] = self.process_stringency_index(
                raw_data["stringency"]
            )
        else:
            logger.warning("Stringency index not available")

        # Align all series
        logger.info("Aligning time series")
        df_model = self.align_series(processed_data)

        # Create COVID dummies
        df_model = self.create_covid_dummies(df_model)

        logger.info(
            f"Model data created: {len(df_model)} observations, "
            f"{df_model.columns.tolist()}"
        )

        # Log summary statistics
        logger.info(f"\nData summary:\n{df_model.describe()}")
        logger.info(f"\nMissing values:\n{df_model.isnull().sum()}")

        return df_model
