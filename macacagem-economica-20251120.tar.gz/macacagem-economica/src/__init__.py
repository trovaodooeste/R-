"""
HLW-COVID Brasil - Holston-Laubach-Williams Model with COVID Adjustments for Brazil
"""

__version__ = "0.1.0"
