"""
Median-Unbiased Estimator for Variance Ratios

Implements the Stock & Watson (1998) median-unbiased estimator for variance ratios
λ_g and λ_z in the HLW model, following the EXACT methodology in HLW (2017) replication code.

Stock, J.H., & Watson, M.W. (1998). "Median Unbiased Estimation of Coefficient
Variance in a Time-Varying Parameter Model." Journal of the American Statistical
Association, 93(441), 349-358.

The HLW model uses:
    λ_g = σ_g / σ_y*
    λ_z = (a_r · σ_z) / σ_ỹ

These ratios determine how much the trend components (g_t, z_t) vary relative to
the shocks in potential output and the output gap.

Reference implementation: HLW (2017) replication code, median.unbiased.estimator.stage2.R
"""

import numpy as np
import logging

logger = logging.getLogger(__name__)


def median_unbiased_estimator_hlw(y: np.ndarray, x: np.ndarray) -> float:
    """
    Median-unbiased estimator EXACTLY as implemented in HLW (2017).

    This tests for structural breaks in a regression and maps the test
    statistic to λ using Stock-Watson (1998) Table 3.

    Args:
        y: Dependent variable (T x 1)
        x: Independent variables (T x k)

    Returns:
        λ: Median-unbiased estimate of variance ratio

    Reference:
        HLW replication code: median.unbiased.estimator.stage2.R (lines 7-88)
    """
    T = x.shape[0]

    # Step 1: Compute test statistics for structural breaks (lines 9-16)
    stat = []
    for i in range(4, T-4):
        # Add break dummy: 0 before time i, 1 after
        break_dummy = np.concatenate([np.zeros(i), np.ones(T-i)])
        xr = np.column_stack([x, break_dummy])

        # OLS regression
        beta = np.linalg.lstsq(xr, y, rcond=None)[0]
        residuals = y - xr @ beta
        s3 = np.sum(residuals**2) / (T - xr.shape[1])

        # Variance of break coefficient
        xi = np.linalg.inv(xr.T @ xr)
        var_break = s3 * xi[-1, -1]

        # t-statistic
        t_stat = beta[-1] / np.sqrt(var_break)
        stat.append(t_stat)

    stat = np.array(stat)

    # Step 2: Compute three test statistics (lines 17-23)
    ew = 0.0
    for s in stat:
        ew += np.exp((s**2) / 2)
    ew = np.log(ew / len(stat))  # Exponential Wald

    mw = np.mean(stat**2)        # Mean Wald
    qlr = np.max(stat**2)         # QLR

    logger.info(f"Test statistics: EW={ew:.4f}, MW={mw:.4f}, QLR={qlr:.4f}")

    # Step 3: Critical values from Stock-Watson Table 3 (lines 26-43)
    valew = np.array([
        0.426, 0.476, 0.516, 0.661, 0.826, 1.111,
        1.419, 1.762, 2.355, 2.91,  3.413, 3.868, 4.925,
        5.684, 6.670, 7.690, 8.477, 9.191, 10.693, 12.024,
        13.089, 14.440, 16.191, 17.332, 18.699, 20.464,
        21.667, 23.851, 25.538, 26.762, 27.874
    ])

    valmw = np.array([
        0.689, 0.757, 0.806, 1.015, 1.234, 1.632,
        2.018, 2.390, 3.081, 3.699, 4.222, 4.776, 5.767,
        6.586, 7.703, 8.683, 9.467, 10.101, 11.639, 13.039,
        13.900, 15.214, 16.806, 18.330, 19.020, 20.562,
        21.837, 24.350, 26.248, 27.089, 27.758
    ])

    valql = np.array([
        3.198, 3.416, 3.594, 4.106, 4.848, 5.689,
        6.682, 7.626, 9.16,  10.66, 11.841, 13.098, 15.451,
        17.094, 19.423, 21.682, 23.342, 24.920, 28.174, 30.736,
        33.313, 36.109, 39.673, 41.955, 45.056, 48.647, 50.983,
        55.514, 59.278, 61.311, 64.016
    ])

    # Step 4: Invert to get λ*T (lines 52-80)
    def invert_stat(test_stat, critical_values):
        """Linear interpolation of Stock-Watson Table 3"""
        if test_stat <= critical_values[0]:
            return 0.0

        for i in range(len(critical_values) - 1):
            if critical_values[i] < test_stat <= critical_values[i+1]:
                # Linear interpolation
                lambda_T = i + (test_stat - critical_values[i]) / (critical_values[i+1] - critical_values[i])
                return lambda_T

        # Extrapolate if beyond table
        return len(critical_values) - 1.0

    lame = invert_stat(ew, valew)    # From Exponential Wald
    lamm = invert_stat(mw, valmw)    # From Mean Wald
    lamq = invert_stat(qlr, valql)   # From QLR

    logger.info(f"λ*T estimates: EW={lame:.4f}, MW={lamm:.4f}, QLR={lamq:.4f}")

    # Step 5: HLW uses Exponential Wald (line 87)
    lambda_g = lame / T

    logger.info(f"✅ Final λ_g = {lambda_g:.6f}")

    return lambda_g


class MedianUnbiasedEstimator:
    """
    Median-unbiased estimator for variance ratios in state-space models

    This implements the Stock-Watson (1998) procedure to correct for small-sample
    bias in maximum likelihood estimates of variance ratios.
    """

    def __init__(self, T: int, n_fast_params: int = 0):
        """Initialize median-unbiased estimator

        Args:
            T: Sample size (number of observations)
            n_fast_params: Number of "fast-moving" parameters estimated
                          (used for degrees of freedom adjustment)
        """
        self.T = T
        self.n_fast_params = n_fast_params
        self.df = T - n_fast_params  # Degrees of freedom

    def compute_lambda_median_unbiased(self, lambda_mle: float,
                                       lambda_grid: np.ndarray = None) -> float:
        """Compute median-unbiased estimate of variance ratio

        The MLE of λ in small samples is biased downward. This function corrects
        for that bias using the Stock-Watson (1998) procedure.

        Args:
            lambda_mle: Maximum likelihood estimate of λ
            lambda_grid: Grid of λ values to search over (default: 0 to 10λ_MLE)

        Returns:
            Median-unbiased estimate of λ
        """
        if lambda_mle <= 0:
            logger.warning(f"λ_MLE = {lambda_mle:.6f} <= 0, returning 0.001")
            return 0.001

        # Default grid: from 0 to 10 times the MLE, with finer resolution near MLE
        if lambda_grid is None:
            # Create adaptive grid
            if lambda_mle < 0.01:
                lambda_grid = np.concatenate([
                    np.linspace(0.0001, lambda_mle * 2, 50),
                    np.linspace(lambda_mle * 2, lambda_mle * 10, 50)
                ])
            else:
                lambda_grid = np.concatenate([
                    np.linspace(0.001, lambda_mle * 2, 100),
                    np.linspace(lambda_mle * 2, lambda_mle * 10, 100)
                ])

        # For each candidate λ_true, compute P(λ_MLE < observed | λ_true)
        # Find λ_true such that P = 0.5 (median)

        best_lambda = None
        min_distance = np.inf

        for lambda_true in lambda_grid:
            # Compute probability that MLE would be less than observed
            # under the hypothesis that true value is lambda_true
            prob = self._compute_prob_mle_less_than(lambda_mle, lambda_true)

            # Find lambda_true where prob = 0.5 (median)
            distance = abs(prob - 0.5)
            if distance < min_distance:
                min_distance = distance
                best_lambda = lambda_true

        if best_lambda is None:
            logger.warning("Median-unbiased estimator failed, returning MLE")
            return lambda_mle

        logger.debug(f"λ_MLE = {lambda_mle:.6f}, λ_median-unbiased = {best_lambda:.6f}")
        return best_lambda

    def _compute_prob_mle_less_than(self, lambda_mle: float,
                                    lambda_true: float) -> float:
        """Compute P(λ̂ < λ_mle | λ_true)

        Under the null hypothesis that the true variance ratio is lambda_true,
        compute the probability that the MLE would be less than lambda_mle.

        This uses the asymptotic chi-squared distribution of the likelihood ratio
        statistic from Stock & Watson (1998).

        Args:
            lambda_mle: Observed MLE value
            lambda_true: Hypothesized true value

        Returns:
            Probability P(λ̂ < λ_mle | λ_true)
        """
        if lambda_true <= 0:
            return 1.0 if lambda_mle >= 0 else 0.0

        # Likelihood ratio statistic (asymptotic approximation)
        # LR = T · [log(1 + λ²) - log(1 + λ̂²)]
        lr_stat = self.df * (np.log(1 + lambda_true**2) -
                             np.log(1 + lambda_mle**2))

        # Under H0, LR ~ χ²(1) asymptotically
        # P(λ̂ < λ_mle | λ_true) ≈ P(χ²(1) > LR)
        if lr_stat < 0:
            # If LR < 0, then λ_mle > λ_true, so P(λ̂ < λ_mle) > 0.5
            prob = 1.0 - chi2.cdf(-lr_stat, df=1)
        else:
            # If LR > 0, then λ_mle < λ_true, so P(λ̂ < λ_mle) < 0.5
            prob = chi2.cdf(lr_stat, df=1)

        return prob

    def compute_lambda_with_constraint(self, lambda_mle: float,
                                       lower_bound: float = 0.0,
                                       upper_bound: float = 1.0) -> float:
        """Compute median-unbiased estimate with constraints

        Useful when λ is known to lie in a specific range (e.g., λ_g in [0, 1]).

        Args:
            lambda_mle: Maximum likelihood estimate
            lower_bound: Lower bound on λ
            upper_bound: Upper bound on λ

        Returns:
            Constrained median-unbiased estimate
        """
        # Create grid over constrained range
        lambda_grid = np.linspace(lower_bound, upper_bound, 200)

        lambda_mub = self.compute_lambda_median_unbiased(lambda_mle, lambda_grid)

        # Apply hard constraints
        return np.clip(lambda_mub, lower_bound, upper_bound)


def estimate_lambda_g(mle_result: dict, T: int, n_fast_params: int = 7) -> dict:
    """Estimate λ_g = σ_g / σ_y* using median-unbiased estimator

    Args:
        mle_result: Dictionary with MLE results including 'lambda_g' estimate
        T: Sample size
        n_fast_params: Number of fast-moving parameters estimated before λ_g

    Returns:
        Dictionary with both MLE and median-unbiased estimates
    """
    lambda_g_mle = mle_result.get('lambda_g', 0.05)

    estimator = MedianUnbiasedEstimator(T, n_fast_params)
    lambda_g_mub = estimator.compute_lambda_with_constraint(
        lambda_g_mle,
        lower_bound=0.001,
        upper_bound=1.0
    )

    logger.info(f"λ_g: MLE = {lambda_g_mle:.6f}, median-unbiased = {lambda_g_mub:.6f}")

    return {
        'lambda_g_mle': lambda_g_mle,
        'lambda_g_median_unbiased': lambda_g_mub,
        'sigma_g': lambda_g_mub * mle_result.get('sigma_y_star', 0.02)
    }


def estimate_lambda_z(mle_result: dict, T: int, n_fast_params: int = 10) -> dict:
    """Estimate λ_z = (a_r · σ_z) / σ_ỹ using median-unbiased estimator

    Args:
        mle_result: Dictionary with MLE results including 'lambda_z' estimate
        T: Sample size
        n_fast_params: Number of fast-moving parameters estimated before λ_z

    Returns:
        Dictionary with both MLE and median-unbiased estimates
    """
    lambda_z_mle = mle_result.get('lambda_z', 0.05)

    estimator = MedianUnbiasedEstimator(T, n_fast_params)
    lambda_z_mub = estimator.compute_lambda_with_constraint(
        lambda_z_mle,
        lower_bound=0.001,
        upper_bound=1.0
    )

    logger.info(f"λ_z: MLE = {lambda_z_mle:.6f}, median-unbiased = {lambda_z_mub:.6f}")

    # Extract σ_z from λ_z and a_r
    # λ_z = (a_r · σ_z) / σ_ỹ
    # σ_z = (λ_z · σ_ỹ) / a_r
    a_r = mle_result.get('a_r', -0.1)
    sigma_y_tilde = mle_result.get('sigma_y_tilde', 0.5)
    sigma_z = (lambda_z_mub * sigma_y_tilde) / abs(a_r)

    return {
        'lambda_z_mle': lambda_z_mle,
        'lambda_z_median_unbiased': lambda_z_mub,
        'sigma_z': sigma_z
    }


# Example usage and testing
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    # Test with synthetic data
    T = 100
    lambda_true = 0.2

    # Simulate MLE (with downward bias)
    np.random.seed(42)
    lambda_mle = lambda_true * (1 - 0.1 * np.random.rand())  # Biased downward

    print(f"True λ: {lambda_true:.4f}")
    print(f"MLE λ:  {lambda_mle:.4f} (biased)")

    estimator = MedianUnbiasedEstimator(T, n_fast_params=5)
    lambda_mub = estimator.compute_lambda_median_unbiased(lambda_mle)

    print(f"Median-unbiased λ: {lambda_mub:.4f}")
    print(f"Bias correction: {lambda_mub - lambda_mle:.4f}")
