"""
Stage 2 of HLW Three-Stage Estimation - CORRECTED VERSION

Following the exact structure from HLW official replication code (rstar.stage2.R).

Key features:
1. Adds real interest rate to IS curve
2. Adds g_t (time-varying trend growth) as state variable
3. FIXES parameters from Stage 1: a_y1, a_y2, b_π, b_y
4. Estimates: a_r, a_0, a_g, variances
5. Takes λ_g as FIXED input (from Stage 1 or median-unbiased)

State-Space Model (Stage 2):
    States (4): xi_t = [y*_t, y*_{t-1}, y*_{t-2}, g_t]
    Observations (2): y_t = [GDP, inflation]

    State equation:
        y*_t = y*_{t-1} + g_{t-1} + ε_y*,t
        g_t = g_{t-1} + ε_g,t

    Observation equation:
        y_t = A'*x_t + H'*xi_t + R_shock

Output:
    - Filtered states including g_t (time-varying growth)
    - r* preliminary = g_t * 4 (annualized, without z component yet)
    - Parameters for Stage 3
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from pathlib import Path
import yaml
import logging

logger = logging.getLogger(__name__)


class Stage2EstimatorFixed:
    """Stage 2: Estimation with interest rate, fixing Stage 1 parameters"""

    def __init__(self, config_path: Path, stage1_results: dict, lambda_g: float):
        """Initialize Stage 2 estimator

        Args:
            config_path: Path to config.yaml file
            stage1_results: Dictionary with Stage 1 results
            lambda_g: Fixed variance ratio σ_g / σ_y* (from Stage 1 or median-unbiased)
        """
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)

        # Fixed parameters from Stage 1
        self.fixed_params = {
            'a_y1': stage1_results['params']['a_y1'],
            'a_y2': stage1_results['params']['a_y2'],
            'b_pi': stage1_results['params']['b_pi'],
            'b_pi_lag': stage1_results['params']['b_pi_lag'],
            'b_y': stage1_results['params']['b_y'],
        }

        # Fixed lambda_g (variance ratio)
        self.lambda_g = lambda_g

        logger.info("=" * 60)
        logger.info("STAGE 2 INITIALIZATION")
        logger.info("=" * 60)
        logger.info("Fixed parameters from Stage 1:")
        for name, value in self.fixed_params.items():
            logger.info(f"  {name:12s} = {value:10.6f}")
        logger.info(f"  λ_g (fixed)  = {lambda_g:10.6f}")

    def estimate_is_curve_with_rate_ols(self, output_gap: np.ndarray,
                                         real_rate: np.ndarray) -> dict:
        """
        Estimate IS curve via OLS WITH real interest rate.

        This is the KEY DIFFERENCE from Stage 1: adds r_t to the regression!

        Model: ỹ_t = a_y1·ỹ_{t-1} + a_y2·ỹ_{t-2} + a_r/2·(r_{t-1} + r_{t-2}) + a_0 + ε

        Args:
            output_gap: Output gap series (percentage points)
            real_rate: Real interest rate series

        Returns:
            Dictionary with a_y1, a_y2, a_r, a_0, sigma_is
        """
        # Prepare data (skip first 4 observations for lags)
        y_is = output_gap[5:]
        X_is = np.column_stack([
            output_gap[4:-1],                       # ỹ_{t-1}
            output_gap[3:-2],                       # ỹ_{t-2}
            (real_rate[4:-1] + real_rate[3:-2]) / 2,  # Average of r_{t-1}, r_{t-2}
            np.ones(len(y_is))                      # Constant
        ])

        # OLS
        beta_is = np.linalg.lstsq(X_is, y_is, rcond=None)[0]
        residuals = y_is - X_is @ beta_is
        sigma_is = np.std(residuals, ddof=len(beta_is))

        logger.info("IS curve OLS (with interest rate):")
        logger.info(f"  a_y1 = {beta_is[0]:.4f}")
        logger.info(f"  a_y2 = {beta_is[1]:.4f}")
        logger.info(f"  a_r  = {beta_is[2]:.4f}  {'✓ NEGATIVE' if beta_is[2] < 0 else '⚠️ POSITIVE!'}")
        logger.info(f"  a_0  = {beta_is[3]:.4f}")
        logger.info(f"  σ_IS = {sigma_is:.4f}")

        return {
            'a_y1': beta_is[0],
            'a_y2': beta_is[1],
            'a_r': beta_is[2],
            'a_0': beta_is[3],
            'sigma_is': sigma_is
        }

    def unpack_parameters_stage2(self, theta: np.ndarray) -> dict:
        """
        Unpack parameter vector into state-space matrices (Stage 2).

        Following unpack.parameters.stage2.R structure.

        Parameter vector theta (Stage 2):
        [a_y1, a_y2, a_r, a_0, a_g, b_pi, b_pi_lag, b_y,
         kappa_2020, kappa_2021, kappa_2022, sigma_is, sigma_pi, sigma_y_star]

        States (4): [y*_t, y*_{t-1}, y*_{t-2}, g_t]

        Returns:
            Dictionary with F, Q, A, H, R, cons matrices
        """
        # Extract parameters
        a_y1, a_y2, a_r, a_0, a_g = theta[0], theta[1], theta[2], theta[3], theta[4]
        b_pi, b_pi_lag, b_y = theta[5], theta[6], theta[7]
        kappa_2020, kappa_2021, kappa_2022 = theta[8], theta[9], theta[10]
        sigma_is, sigma_pi, sigma_y_star = theta[11], theta[12], theta[13]

        # Compute sigma_g from lambda_g
        sigma_g = self.lambda_g * sigma_y_star

        # Matrix A: coefficients for exogenous regressors (10 regressors x 2 observations)
        # Following exact structure from unpack.parameters.stage2.R lines 13-22
        A = np.zeros((10, 2))
        A[0:2, 0] = [a_y1, a_y2]              # GDP obs: a_y1*log_y_{t-1} + a_y2*log_y_{t-2}
        A[2:4, 0] = [a_r/2, a_r/2]            # GDP obs: a_r/2*(r_{t-1} + r_{t-2})
        A[9, 0] = a_0                          # GDP obs: constant
        A[0, 1] = b_y                          # Inflation obs: b_y*output_gap_{t-1}
        A[4:6, 1] = [b_pi, b_pi_lag]          # Inflation obs: b_pi*π_{t-1} + b_pi_lag*π_{t-2,4}
        A[6, 1] = 1 - b_pi - b_pi_lag         # Inflation obs: (1-b_pi-b_pi_lag)*π_{t-2,4}
        A[7:10, 1] = [kappa_2020, kappa_2021, kappa_2022]  # COVID effects

        # Matrix H: observation equation (4 states x 2 observations)
        # Following unpack.parameters.stage2.R lines 24-28
        H = np.zeros((4, 2))
        H[0, 0] = 1.0                          # GDP obs: 1*y*_t
        H[1:3, 0] = [-a_y1, -a_y2]            # GDP obs: -a_y1*y*_{t-1} - a_y2*y*_{t-2}
        H[3, 0] = a_g                          # GDP obs: a_g*g_t
        H[1, 1] = -b_y                         # Inflation obs: -b_y*y*_{t-1}

        # Matrix F: state transition (4x4)
        # Following unpack.parameters.stage2.R line 34
        F = np.array([
            [1, 0, 0, 1],  # y*_t = y*_{t-1} + g_{t-1}
            [1, 0, 0, 0],  # y*_{t-1} = y*_{t-1}
            [0, 1, 0, 0],  # y*_{t-2} = y*_{t-2}
            [0, 0, 0, 1]   # g_t = g_{t-1}
        ])

        # Matrix Q: state covariance (4x4)
        # Following unpack.parameters.stage2.R lines 30-32
        Q = np.zeros((4, 4))
        Q[0, 0] = sigma_y_star**2              # Variance of y*
        Q[3, 3] = sigma_g**2                   # Variance of g (computed from lambda_g!)

        # Matrix R: observation covariance (2x2)
        R = np.diag([sigma_is**2, sigma_pi**2])

        # Constant in state equation (none in Stage 2)
        cons = np.zeros((4, 1))

        return {
            'F': F, 'Q': Q, 'A': A.T, 'H': H.T, 'R': R, 'cons': cons
        }

    def kalman_log_likelihood(self, theta: np.ndarray, y_data: np.ndarray,
                               x_data: np.ndarray) -> float:
        """
        Compute log-likelihood via Kalman Filter (Stage 2).

        Args:
            theta: Parameter vector
            y_data: Observations (T, 2) - [GDP, inflation]
            x_data: Exogenous regressors (T, 10)

        Returns:
            Cumulative log-likelihood
        """
        T = y_data.shape[0]

        # Unpack parameters into matrices
        matrices = self.unpack_parameters_stage2(theta)
        F, Q, A, H, R, cons = matrices['F'], matrices['Q'], matrices['A'], matrices['H'], matrices['R'], matrices['cons']

        # Initialize state (diffuse prior)
        xi_tt = np.zeros((4, 1))
        P_tt = np.eye(4) * 1000

        ll_cum = 0.0

        for t in range(T):
            # Predict
            xi_ttm1 = F @ xi_tt + cons
            P_ttm1 = F @ P_tt @ F.T + Q

            # Prediction error
            y_pred = A @ x_data[t] + H @ xi_ttm1.flatten()
            prediction_error = y_data[t] - y_pred

            # Innovation covariance
            HPHR = H @ P_ttm1 @ H.T + R

            # Log-likelihood contribution
            try:
                sign, logdet = np.linalg.slogdet(HPHR)
                if sign <= 0:
                    return -np.inf
                ll_t = -0.5 * (2 * np.log(2*np.pi) + logdet +
                              prediction_error @ np.linalg.solve(HPHR, prediction_error))
                ll_cum += ll_t
            except np.linalg.LinAlgError:
                return -np.inf

            # Update
            K = P_ttm1 @ H.T @ np.linalg.solve(HPHR, np.eye(2))
            xi_tt = xi_ttm1 + K @ prediction_error.reshape(-1, 1)
            P_tt = P_ttm1 - K @ H @ P_ttm1

        return ll_cum

    def estimate(self, data: pd.DataFrame) -> dict:
        """Run Stage 2 estimation following HLW structure"""
        logger.info("\n" + "=" * 60)
        logger.info("STAGE 2: WITH INTEREST RATE (HLW Structure)")
        logger.info("=" * 60)

        # Extract data
        log_gdp = data['y_t'].values
        inflation = data['pi_t'].values
        inflation_lags = data['pi_t_lag_avg'].values
        real_rate = data['r_t'].values
        covid_dummies = data[['D_2020', 'D_2021', 'D_2022']].values

        # Remove NaN values
        valid_idx = ~(np.isnan(log_gdp) | np.isnan(inflation) | np.isnan(inflation_lags) | np.isnan(real_rate))
        log_gdp = log_gdp[valid_idx]
        inflation = inflation[valid_idx]
        inflation_lags = inflation_lags[valid_idx]
        real_rate = real_rate[valid_idx]
        covid_dummies = covid_dummies[valid_idx]
        dates = data['date'].values[valid_idx]

        logger.info(f"Sample size after removing NaN: {len(log_gdp)} observations")

        # Step 1: Initial output gap via OLS with trend (same as Stage 1)
        from .stage1_preliminary_fixed import Stage1EstimatorFixed
        stage1_temp = Stage1EstimatorFixed(Path('config/config.yaml'))
        output_gap = stage1_temp.estimate_initial_output_gap(log_gdp)

        # Step 2: IS curve OLS WITH INTEREST RATE (KEY DIFFERENCE!)
        is_results = self.estimate_is_curve_with_rate_ols(output_gap, real_rate)

        # Step 3: Prepare data for Kalman Filter (skip first 8 obs)
        T_start = 8
        y_data = np.column_stack([
            log_gdp[T_start:] * 100,  # GDP in basis points
            inflation[T_start:]        # Inflation
        ])

        x_data = np.column_stack([
            log_gdp[T_start-1:-1] * 100,     # log_y_{t-1}
            log_gdp[T_start-2:-2] * 100,     # log_y_{t-2}
            real_rate[T_start-1:-1],          # r_{t-1}
            real_rate[T_start-2:-2],          # r_{t-2}
            inflation[T_start-1:-1],          # π_{t-1}
            inflation_lags[T_start:],         # π_{t-2,4}
            inflation_lags[T_start:],         # Placeholder (for 1-b_pi-b_pi_lag term)
            covid_dummies[T_start:, 0],       # D_2020
            covid_dummies[T_start:, 1],       # D_2021
            covid_dummies[T_start:, 2],       # D_2022
        ])

        # Step 4: Initial parameter vector (using Stage 1 fixed + IS OLS)
        initial_theta = np.array([
            is_results['a_y1'],       # From IS OLS (will be close to Stage 1)
            is_results['a_y2'],
            is_results['a_r'],        # NEW: from IS OLS with rate
            is_results['a_0'],        # NEW: constant
            1.0,                      # a_g (chute)
            self.fixed_params['b_pi'],      # Fixed from Stage 1
            self.fixed_params['b_pi_lag'],  # Fixed from Stage 1
            self.fixed_params['b_y'],       # Fixed from Stage 1
            0.0, 0.0, 0.0,            # COVID kappa (will estimate)
            is_results['sigma_is'],
            1.0,                      # sigma_pi (chute)
            0.5                       # sigma_y_star (chute)
        ])

        logger.info(f"\nInitial parameters for MLE:")
        param_names = ['a_y1', 'a_y2', 'a_r', 'a_0', 'a_g',
                      'b_pi', 'b_pi_lag', 'b_y',
                      'kappa_2020', 'kappa_2021', 'kappa_2022',
                      'sigma_is', 'sigma_pi', 'sigma_y_star']
        for name, val in zip(param_names, initial_theta):
            logger.info(f"  {name:12s} = {val:10.6f}")

        # Step 5: MLE refinement
        logger.info("\nRefining via MLE with Kalman Filter...")

        def neg_log_lik(theta):
            return -self.kalman_log_likelihood(theta, y_data, x_data)

        # Bounds (Torres constraints!)
        bounds = [
            (0.0, 2.0),        # a_y1
            (-1.0, 1.0),       # a_y2
            (-0.5, -0.0025),   # a_r (NEGATIVE obrigatório!)
            (-5.0, 5.0),       # a_0
            (0.1, 2.0),        # a_g (mínimo 0.1 para evitar identificação fraca!)
            (0.0, 1.0),        # b_pi
            (0.0, 1.0),        # b_pi_lag
            (0.25, 0.5),       # b_y (Torres: >= 0.25!)
            (-10, 10),         # kappa_2020
            (-10, 10),         # kappa_2021
            (-10, 10),         # kappa_2022
            (0.01, 5.0),       # sigma_is
            (0.1, 10.0),       # sigma_pi
            (0.001, 1.0),      # sigma_y_star (reduzir teto de 2.0 → 1.0)
        ]

        result = minimize(neg_log_lik, initial_theta, method='L-BFGS-B',
                         bounds=bounds, options={'maxiter': 500, 'disp': True})

        theta_mle = result.x
        log_lik = -result.fun

        # Extract final parameters
        params = dict(zip(param_names, theta_mle))

        logger.info("\n" + "=" * 60)
        logger.info("STAGE 2 RESULTS")
        logger.info("=" * 60)
        logger.info(f"\nLog-likelihood: {log_lik:.4f}")
        logger.info(f"Optimization status: {result.message}")

        logger.info("\nMLE Parameter Estimates:")
        for name, val in params.items():
            logger.info(f"  {name:12s} = {val:10.6f}")

        # Run final Kalman filter to extract states
        matrices = self.unpack_parameters_stage2(theta_mle)
        F, Q, cons = matrices['F'], matrices['Q'], matrices['cons']

        # Extract filtered states
        xi_filt = np.zeros((len(y_data), 4))
        xi_tt = np.zeros((4, 1))
        P_tt = np.eye(4) * 1000

        for t in range(len(y_data)):
            xi_ttm1 = F @ xi_tt + cons
            P_ttm1 = F @ P_tt @ F.T + Q

            y_pred = matrices['A'] @ x_data[t] + matrices['H'] @ xi_ttm1.flatten()
            prediction_error = y_data[t] - y_pred
            HPHR = matrices['H'] @ P_ttm1 @ matrices['H'].T + matrices['R']

            K = P_ttm1 @ matrices['H'].T @ np.linalg.solve(HPHR, np.eye(2))
            xi_tt = xi_ttm1 + K @ prediction_error.reshape(-1, 1)
            P_tt = P_ttm1 - K @ matrices['H'] @ P_ttm1

            xi_filt[t] = xi_tt.flatten()

        # Extract key quantities
        y_star_t = xi_filt[:, 0] / 100  # Back to log scale
        g_t = xi_filt[:, 3]             # Trend growth (quarterly)
        r_star_prelim = g_t * 4         # Annualized r* (WITHOUT z yet!)

        logger.info(f"\nr* preliminary (g only, annualized):")
        logger.info(f"  Mean: {np.mean(r_star_prelim)*100:.2f}%")
        logger.info(f"  Std:  {np.std(r_star_prelim)*100:.2f}%")
        logger.info(f"  Last: {r_star_prelim[-1]*100:.2f}%")

        return {
            'params': params,
            'y_star': y_star_t,
            'g_t': g_t,
            'r_star_preliminary': r_star_prelim,
            'log_likelihood': log_lik,
            'optimization_result': result,
            'dates': dates[T_start:],
            'lambda_g': self.lambda_g,
            'output_gap_smoothed': None  # TODO: Add RTS smoother for median-unbiased
        }


def compute_lambda_g_median_unbiased(stage2_results: dict, model_data: pd.DataFrame) -> float:
    """
    Compute λ_g using median-unbiased estimator (Stock-Watson 1998).

    This function takes Stage 2 results and computes λ_g following HLW methodology:
    1. Extract output gap smoothed from Stage 2
    2. Run median-unbiased estimator on output gap AR(2) regression
    3. Return corrected λ_g

    Args:
        stage2_results: Results from Stage 2 estimation
        model_data: Model data DataFrame

    Returns:
        λ_g: Median-unbiased estimate of variance ratio σ_g / σ_y*

    Note:
        HLW uses OUTPUT GAP SMOOTHED (two-sided), not filtered (one-sided).
        For now, we'll use filtered as approximation until RTS smoother is implemented.
    """
    from .median_unbiased_estimator import median_unbiased_estimator_hlw

    logger.info("\n" + "=" * 60)
    logger.info("COMPUTING λ_g MEDIAN-UNBIASED")
    logger.info("=" * 60)

    # Extract output gap (filtered for now, should be smoothed)
    output_gap = stage2_results.get('output_gap_filtered')

    if output_gap is None:
        logger.warning("Output gap not available, using placeholder λ_g = 0.05")
        return 0.05

    # Remove first 2 observations to create AR(2) structure
    # y = output_gap[t]
    # x = [output_gap[t-1], output_gap[t-2], g_t, ...]
    y = output_gap[3:]
    x = np.column_stack([
        output_gap[2:-1],  # lag 1
        output_gap[1:-2],  # lag 2
    ])

    logger.info(f"Running median-unbiased estimator on {len(y)} observations")

    # Call HLW median-unbiased estimator
    lambda_g_mub = median_unbiased_estimator_hlw(y, x)

    logger.info(f"✅ λ_g median-unbiased = {lambda_g_mub:.6f}")
    logger.info(f"   Previous λ_g (fixed) = {stage2_results['lambda_g']:.6f}")
    logger.info(f"   Difference = {lambda_g_mub - stage2_results['lambda_g']:.6f}")

    return lambda_g_mub
