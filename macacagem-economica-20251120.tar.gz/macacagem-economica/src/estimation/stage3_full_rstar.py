"""
Stage 3 of the Holston-Laubach-Williams Three-Stage Estimation

This stage adds the z_t component to decompose r* = g_t + z_t.
It FIXES all structural parameters from Stages 1 and 2.

Following Stock & Watson (1998) and Holston, Laubach & Williams (2017).

State Vector (8 states):
    x_t = [y*_t, g_t, z_t, ỹ_t, ỹ_t-1, ỹ_t-2, (r-r*)_t-1, (r-r*)_t-2]

Observation Equations:
    y_t = y*_t + ỹ_t
    π_t = b_π·π_t-1 + (1-b_π)·π_t-2,4 + b_y·ỹ_t-1 + φ·D_COVID + ε_π,t

State Equations:
    y*_t = y*_t-1 + g_t-1 + ε_y*,t
    g_t = g_t-1 + ε_g,t
    z_t = z_t-1 + β·d_t + ε_z,t
    ỹ_t = a_y1·ỹ_t-1 + a_y2·ỹ_t-2 + (a_r/2)·[(r-r*)_t-1 + (r-r*)_t-2] + ε_ỹ,t
    (Identity states for lags)

Natural Rate:
    r*_t = g_t + z_t

Parameters FIXED from Stages 1 & 2:
    - a_y1, a_y2, b_π, b_y, φ (Stage 1)
    - a_r (Stage 2)

Parameters to Estimate:
    - Variances: σ_ỹ, σ_π, σ_y*
    - Variance ratios: λ_g, λ_z (via median-unbiased estimator)
    - COVID stringency effect: β

Output:
    - Complete r* decomposition: r*_t = g_t + z_t
    - All filtered states
    - Final parameter estimates
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from filterpy.kalman import KalmanFilter
from pathlib import Path
import yaml
import logging
from .median_unbiased_estimator import MedianUnbiasedEstimator

logger = logging.getLogger(__name__)


class Stage3Estimator:
    """Stage 3: Full r* decomposition, fixing Stages 1 & 2 parameters"""

    def __init__(self, config_path: Path, stage1_results: dict, stage2_results: dict):
        """Initialize Stage 3 estimator

        Args:
            config_path: Path to config.yaml file
            stage1_results: Dictionary with Stage 1 results
            stage2_results: Dictionary with Stage 2 results
        """
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)

        # Fixed parameters from Stages 1 and 2
        self.fixed_params = {
            # Stage 1
            'a_y1': stage1_results['params']['a_y1'],
            'a_y2': stage1_results['params']['a_y2'],
            'b_pi': stage1_results['params']['b_pi'],
            'b_y': stage1_results['params']['b_y'],
            'phi': stage1_results['params']['phi'],
            # Stage 2
            'a_r': stage2_results['params']['a_r'],
        }

        logger.info("Fixed parameters from Stages 1 & 2:")
        for name, value in self.fixed_params.items():
            logger.info(f"  {name:10s} = {value:10.6f}")

        # Initial parameter guesses for Stage 3
        stage3_config = self.config.get('model', {}).get('stage3', {})
        self.initial_params = {
            'sigma_y_tilde': stage3_config.get('sigma_y_tilde', 0.5),
            'sigma_pi': stage3_config.get('sigma_pi', 1.0),
            'sigma_y_star': stage3_config.get('sigma_y_star', 0.02),
            'lambda_g': stage3_config.get('lambda_g', 0.05),
            'lambda_z': stage3_config.get('lambda_z', 0.05),
            'beta': stage3_config.get('beta', 0.0),  # Stringency effect on z_t
        }

        # Parameter bounds
        self.param_bounds = {
            'sigma_y_tilde': (0.01, 5.0),
            'sigma_pi': (0.1, 10.0),
            'sigma_y_star': (0.001, 0.5),
            'lambda_g': (0.001, 1.0),
            'lambda_z': (0.001, 1.0),
            'beta': (-1.0, 1.0),
        }

    def build_kalman_filter(self, params: dict, T: int) -> KalmanFilter:
        """Build Kalman Filter for Stage 3 model (8 states)

        Args:
            params: Dictionary of parameter values
            T: Number of time periods

        Returns:
            Configured KalmanFilter object
        """
        # Extract parameters
        a_y1 = self.fixed_params['a_y1']
        a_y2 = self.fixed_params['a_y2']
        a_r = self.fixed_params['a_r']

        sigma_y_star = params['sigma_y_star']
        lambda_g = params['lambda_g']
        lambda_z = params['lambda_z']
        sigma_y_tilde = params['sigma_y_tilde']

        # Compute variances from ratios
        sigma_g = lambda_g * sigma_y_star
        sigma_z = (lambda_z * sigma_y_tilde) / abs(a_r)

        # Initialize filter (8 states, 2 observations)
        kf = KalmanFilter(dim_x=8, dim_z=2)

        # State vector: [y*_t, g_t, z_t, ỹ_t, ỹ_t-1, ỹ_t-2, (r-r*)_t-1, (r-r*)_t-2]
        # State transition matrix F
        kf.F = np.array([
            # y*_t = y*_t-1 + g_t-1
            [1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            # g_t = g_t-1
            [0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            # z_t = z_t-1 (+ β·d_t added via control input)
            [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            # ỹ_t = a_y1·ỹ_t-1 + a_y2·ỹ_t-2 + (a_r/2)·[(r-r*)_t-1 + (r-r*)_t-2]
            [0.0, 0.0, 0.0, a_y1, a_y2, 0.0, a_r/2, a_r/2],
            # ỹ_t-1 = ỹ_t-1
            [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],
            # ỹ_t-2 = ỹ_t-2
            [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            # (r-r*)_t-1 = (r-r*)_t-1
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0],
            # (r-r*)_t-2 = (r-r*)_t-2
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        ])

        # Control input for stringency effect on z_t
        # B is 8x1, only row 2 (z_t) is non-zero
        kf.B = np.array([[0.0], [0.0], [params['beta']], [0.0],
                        [0.0], [0.0], [0.0], [0.0]])

        # Observation matrix H
        # Observe: y_t = y*_t + ỹ_t  =>  [1, 0, 0, 1, 0, 0, 0, 0]
        #          π_t = (modeled separately in Phillips curve)
        kf.H = np.array([
            [1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0],  # GDP
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]   # Inflation (handled separately)
        ])

        # Process noise covariance Q
        kf.Q = np.zeros((8, 8))
        kf.Q[0, 0] = sigma_y_star**2  # ε_y*
        kf.Q[1, 1] = sigma_g**2       # ε_g
        kf.Q[2, 2] = sigma_z**2       # ε_z
        kf.Q[3, 3] = sigma_y_tilde**2 # ε_ỹ

        # Measurement noise covariance R
        kf.R = np.zeros((2, 2))
        kf.R[0, 0] = 1e-10  # GDP observed perfectly (noise in output gap)
        kf.R[1, 1] = params['sigma_pi']**2  # Inflation measurement noise

        # Initial state covariance (diffuse initialization)
        kf.P *= 1000.0

        return kf

    def run_kalman_filter(self, params: dict, y_t: np.ndarray, pi_t: np.ndarray,
                          pi_lags: np.ndarray, r_t: np.ndarray,
                          stringency: np.ndarray, covid_dummies: np.ndarray) -> tuple:
        """Run Kalman filter for Stage 3

        Args:
            params: Parameter dictionary (including fixed params)
            y_t: Log GDP observations (T,)
            pi_t: Current inflation (T,)
            pi_lags: Lagged inflation average π_t-2,4 (T,)
            r_t: Real interest rate (T,)
            stringency: Stringency index d_t (T,)
            covid_dummies: COVID dummy variables (T, 3)

        Returns:
            (filtered_states, predicted_states, log_likelihood)
        """
        T = len(y_t)

        # Build Kalman filter
        kf = self.build_kalman_filter(params, T)

        # Initialize state
        # [y*_0, g_0, z_0, ỹ_0, ỹ_-1, ỹ_-2, (r-r*)_-1, (r-r*)_-2]
        initial_g = 0.01  # 1% quarterly growth
        initial_z = 0.01  # 4% annual z component
        kf.x = np.array([[y_t[0]], [initial_g], [initial_z], [0.0],
                        [0.0], [0.0], [0.0], [0.0]])

        # Storage for results
        x_filt = np.zeros((T, 8))
        x_pred = np.zeros((T, 8))
        log_lik = 0.0

        # Extract fixed parameters
        b_pi = self.fixed_params['b_pi']
        b_y = self.fixed_params['b_y']
        phi = self.fixed_params['phi']
        sigma_pi = params['sigma_pi']

        # Extract COVID dummies
        D_2020 = covid_dummies[:, 0]
        D_2021 = covid_dummies[:, 1]
        D_2022 = covid_dummies[:, 2]

        # Kalman filter loop
        for t in range(T):
            # Predict step (with stringency control input)
            u_t = np.array([[stringency[t]]])
            kf.predict(u=u_t)
            x_pred[t] = kf.x.flatten()

            # Update step (GDP observation only)
            z_obs = np.array([[y_t[t]], [0.0]])  # Only observe GDP
            kf.update(z_obs, R=np.diag([1e-10, 1e10]))  # Only trust GDP observation
            x_filt[t] = kf.x.flatten()

            # Compute log-likelihood from innovation (GDP only)
            y_innovation = y_t[t] - (x_pred[t, 0] + x_pred[t, 3])
            sigma_y_obs = np.sqrt(kf.Q[0, 0] + kf.Q[3, 3])  # Combined variance
            if sigma_y_obs > 0:
                log_lik += -0.5 * (np.log(2 * np.pi) +
                                  2 * np.log(sigma_y_obs) +
                                  (y_innovation / sigma_y_obs)**2)

            # Update (r-r*) lag states for next iteration
            if t < T - 1:
                r_star_t = x_filt[t, 1] + x_filt[t, 2]  # g_t + z_t
                r_gap_t = r_t[t] - r_star_t
                # Shift lags: (r-r*)_t-1 ← (r-r*)_t, (r-r*)_t-2 ← (r-r*)_t-1
                kf.x[6, 0] = r_gap_t
                kf.x[7, 0] = kf.x[6, 0]

        # Add Phillips curve log-likelihood
        for t in range(2, T):
            # Phillips curve prediction
            covid_effect = phi * (D_2020[t] + D_2021[t] + D_2022[t])
            y_tilde_t_minus_1 = x_filt[t-1, 3]  # Output gap at t-1

            pi_pred = (b_pi * pi_t[t-1] +
                      (1 - b_pi) * pi_lags[t] +
                      b_y * y_tilde_t_minus_1 +
                      covid_effect)

            # Prediction error
            pi_innovation = pi_t[t] - pi_pred
            log_lik += -0.5 * (np.log(2 * np.pi) +
                              2 * np.log(sigma_pi) +
                              (pi_innovation / sigma_pi)**2)

        return x_filt, x_pred, log_lik

    def negative_log_likelihood(self, param_values: np.ndarray,
                                param_names: list,
                                y_t: np.ndarray,
                                pi_t: np.ndarray,
                                pi_lags: np.ndarray,
                                r_t: np.ndarray,
                                stringency: np.ndarray,
                                covid_dummies: np.ndarray) -> float:
        """Compute negative log-likelihood for optimization

        Args:
            param_values: Array of parameter values to optimize
            param_names: List of parameter names
            Data arrays

        Returns:
            Negative log-likelihood
        """
        # Build parameter dictionary
        params = {**self.fixed_params}
        params.update(dict(zip(param_names, param_values)))

        # Check bounds
        for name in param_names:
            value = params[name]
            lower, upper = self.param_bounds[name]
            if value < lower or value > upper:
                return 1e10

        try:
            _, _, log_lik = self.run_kalman_filter(
                params, y_t, pi_t, pi_lags, r_t, stringency, covid_dummies
            )
            return -log_lik
        except (np.linalg.LinAlgError, ValueError, RuntimeWarning):
            return 1e10

    def estimate(self, data: pd.DataFrame) -> dict:
        """Run Stage 3 estimation

        Args:
            data: DataFrame with columns: date, y_t, pi_t, pi_t_lag_avg, r_t, d_t,
                  D_2020, D_2021, D_2022

        Returns:
            Dictionary with complete r* decomposition and all states
        """
        logger.info("\n" + "=" * 60)
        logger.info("STAGE 3: FULL r* DECOMPOSITION (r* = g + z)")
        logger.info("=" * 60)

        # Extract data
        y_t = data['y_t'].values
        pi_t = data['pi_t'].values
        pi_lags = data['pi_t_lag_avg'].values
        r_t = data['r_t'].values
        stringency = data['d_t'].values
        covid_dummies = data[['D_2020', 'D_2021', 'D_2022']].values

        # Parameters to optimize (only variances in Stage 3)
        param_names = ['sigma_y_tilde', 'sigma_pi', 'sigma_y_star',
                      'lambda_g', 'lambda_z', 'beta']
        initial_values = [self.initial_params[name] for name in param_names]
        bounds = [self.param_bounds[name] for name in param_names]

        logger.info(f"\nOptimizing {len(param_names)} parameters (mostly variances)...")
        logger.info(f"Sample size: {len(y_t)} observations")

        # Optimization
        result = minimize(
            self.negative_log_likelihood,
            x0=initial_values,
            args=(param_names, y_t, pi_t, pi_lags, r_t, stringency, covid_dummies),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': 1000, 'disp': True}
        )

        # Extract MLE estimates
        mle_params = {**self.fixed_params}
        mle_params.update(dict(zip(param_names, result.x)))

        # Apply median-unbiased estimator to λ_g and λ_z
        logger.info("\nApplying median-unbiased estimator to variance ratios...")
        estimator = MedianUnbiasedEstimator(len(y_t), n_fast_params=10)

        lambda_g_mub = estimator.compute_lambda_with_constraint(
            mle_params['lambda_g'], 0.001, 1.0
        )
        lambda_z_mub = estimator.compute_lambda_with_constraint(
            mle_params['lambda_z'], 0.001, 1.0
        )

        # Update parameters with median-unbiased estimates
        final_params = mle_params.copy()
        final_params['lambda_g'] = lambda_g_mub
        final_params['lambda_z'] = lambda_z_mub

        # Run final filter with median-unbiased parameters
        x_filt, x_pred, log_lik = self.run_kalman_filter(
            final_params, y_t, pi_t, pi_lags, r_t, stringency, covid_dummies
        )

        # Extract states
        y_star = x_filt[:, 0]
        g_t = x_filt[:, 1]
        z_t = x_filt[:, 2]
        y_tilde = x_filt[:, 3]

        # Compute r*
        r_star = g_t + z_t

        # Results logging
        logger.info("\n" + "=" * 60)
        logger.info("STAGE 3 RESULTS - FINAL")
        logger.info("=" * 60)
        logger.info(f"\nLog-likelihood: {log_lik:.4f}")
        logger.info(f"AIC: {-2*log_lik + 2*len(param_names):.4f}")
        logger.info(f"BIC: {-2*log_lik + len(param_names)*np.log(len(y_t)):.4f}")

        logger.info("\nFinal Parameters (with median-unbiased λ):")
        for name in param_names:
            if name in ['lambda_g', 'lambda_z']:
                logger.info(f"  {name:15s} = {final_params[name]:10.6f} (median-unbiased)")
            else:
                logger.info(f"  {name:15s} = {final_params[name]:10.6f}")

        logger.info(f"\nr* statistics:")
        logger.info(f"  Mean:  {np.mean(r_star)*400:.2f}% annual")
        logger.info(f"  Std:   {np.std(r_star)*400:.2f}%")
        logger.info(f"  Min:   {np.min(r_star)*400:.2f}%")
        logger.info(f"  Max:   {np.max(r_star)*400:.2f}%")
        logger.info(f"  Last:  {r_star[-1]*400:.2f}% annual (Q{data.iloc[-1]['date'].quarter} {data.iloc[-1]['date'].year})")

        logger.info(f"\ng_t statistics:")
        logger.info(f"  Mean:  {np.mean(g_t)*400:.2f}% annual")
        logger.info(f"  Last:  {g_t[-1]*400:.2f}% annual")

        logger.info(f"\nz_t statistics:")
        logger.info(f"  Mean:  {np.mean(z_t)*400:.2f}% annual")
        logger.info(f"  Last:  {z_t[-1]*400:.2f}% annual")

        logger.info(f"\nOptimization status: {result.message}")
        logger.info(f"Iterations: {result.nit}")

        return {
            'params': final_params,
            'params_mle': mle_params,  # Keep MLE estimates for comparison
            'y_star': y_star,
            'g_t': g_t,
            'z_t': z_t,
            'r_star': r_star,
            'y_tilde': y_tilde,
            'log_likelihood': log_lik,
            'optimization_result': result,
            'dates': data['date'].values,
            'lambda_g_mle': mle_params['lambda_g'],
            'lambda_g_mub': lambda_g_mub,
            'lambda_z_mle': mle_params['lambda_z'],
            'lambda_z_mub': lambda_z_mub,
        }
