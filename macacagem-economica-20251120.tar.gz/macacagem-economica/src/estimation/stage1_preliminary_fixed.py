"""
Stage 1 of HLW Three-Stage Estimation - CORRECTED VERSION

Following the exact structure from HLW official replication code (rstar.stage1.R).

Key differences from previous version:
1. Uses OLS with linear trend + structural breaks for initial output gap
2. Estimates IS curve via OLS (without interest rate)
3. Estimates Phillips curve via OLS
4. Uses OLS estimates as initial values for MLE with Kalman Filter
5. Kalman Filter has proper state-space structure matching HLW

State-Space Model (Stage 1):
    States (3): xi_t = [y*_t, y*_t-1, y*_t-2]
    Observations (2): y_t = [GDP, inflation]

    State equation: xi_t = F*xi_{t-1} + cons + Q_shock
    Observation equation: y_t = A'*x_t + H'*xi_t + R_shock

    where x_t contains exogenous regressors (lags of GDP, inflation, COVID dummies)
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy import linalg
from pathlib import Path
import yaml
import logging

logger = logging.getLogger(__name__)


class Stage1EstimatorFixed:
    """Stage 1: Preliminary estimation without interest rate (FIXED VERSION)"""

    def __init__(self, config_path: Path):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)

    def estimate_initial_output_gap(self, log_gdp: np.ndarray) -> np.ndarray:
        """
        Estimate initial output gap using OLS with linear trend + structural breaks.

        This replicates lines 19-21 of rstar.stage1.R:
        x.og <- cbind(rep(1,T+4), 1:(T+4), breaks...)
        output.gap <- (y.og - x.og %*% solve(...)) * 100

        Args:
            log_gdp: Log of real GDP (T observations)

        Returns:
            Initial output gap estimate in percentage points
        """
        T = len(log_gdp)

        # Create regressor matrix: [constant, linear trend, structural breaks]
        X = np.column_stack([
            np.ones(T),           # Constant
            np.arange(1, T+1),    # Linear trend
            # Structural breaks (adapt to Brazilian data - using COVID period)
            np.maximum(0, np.arange(1, T+1) - 80),  # Break around 2020
        ])

        # OLS: y* = X*beta
        beta = np.linalg.lstsq(X, log_gdp, rcond=None)[0]
        y_star_trend = X @ beta

        # Output gap = actual - trend (in percentage points)
        output_gap = (log_gdp - y_star_trend) * 100

        logger.info(f"Initial output gap: mean={np.mean(output_gap):.2f}%, std={np.std(output_gap):.2f}%")

        return output_gap

    def estimate_is_curve_ols(self, output_gap: np.ndarray) -> dict:
        """
        Estimate IS curve via OLS (without interest rate).

        Replicates lines 23-28 of rstar.stage1.R:
        y.is <- output.gap[5:(T+4)]
        x.is <- cbind(output.gap[4:(T+3)], output.gap[3:(T+2)])
        b.is <- solve(t(x.is) %*% x.is, t(x.is) %*% y.is)

        Model: ỹ_t = a_y1*ỹ_{t-1} + a_y2*ỹ_{t-2} + residual

        Args:
            output_gap: Output gap series (percentage points)

        Returns:
            Dictionary with a_y1, a_y2, sigma_is (residual std)
        """
        # Prepare data (skip first 4 observations for lags)
        y_is = output_gap[4:]
        X_is = np.column_stack([
            output_gap[3:-1],  # ỹ_{t-1}
            output_gap[2:-2],  # ỹ_{t-2}
        ])

        # OLS
        beta_is = np.linalg.lstsq(X_is, y_is, rcond=None)[0]
        residuals = y_is - X_is @ beta_is
        sigma_is = np.std(residuals, ddof=2)

        logger.info(f"IS curve OLS: a_y1={beta_is[0]:.4f}, a_y2={beta_is[1]:.4f}, σ={sigma_is:.4f}")

        return {
            'a_y1': beta_is[0],
            'a_y2': beta_is[1],
            'sigma_is': sigma_is
        }

    def estimate_phillips_curve_ols(self, inflation: np.ndarray,
                                     inflation_lags: np.ndarray,
                                     output_gap: np.ndarray,
                                     covid_dummies: np.ndarray) -> dict:
        """
        Estimate Phillips curve via OLS.

        Replicates lines 30-40 of rstar.stage1.R:
        y.ph <- inflation[9:(T+8)]
        x.ph <- cbind(inflation[8:(T+7)], pi_lag_avg, output.gap[4:(T+3)], ...)

        Model: π_t = b_1*π_{t-1} + b_2*π_{t-2,4} + b_y*ỹ_{t-1} + κ*COVID + residual

        Args:
            inflation: Current inflation (T obs)
            inflation_lags: Average of π_{t-2}, π_{t-3}, π_{t-4}
            output_gap: Output gap
            covid_dummies: COVID period dummies (T, 3)

        Returns:
            Dictionary with Phillips curve coefficients
        """
        # Skip first 8 observations for lags
        y_ph = inflation[8:]
        X_ph = np.column_stack([
            inflation[7:-1],                # π_{t-1}
            inflation_lags[8:],             # π_{t-2,4}
            output_gap[7:-1],               # ỹ_{t-1}
            covid_dummies[8:, 0],           # COVID 2020
            covid_dummies[8:, 1],           # COVID 2021
            covid_dummies[8:, 2],           # COVID 2022
        ])

        # OLS
        beta_ph = np.linalg.lstsq(X_ph, y_ph, rcond=None)[0]
        residuals = y_ph - X_ph @ beta_ph
        sigma_ph = np.std(residuals, ddof=len(beta_ph))

        logger.info(f"Phillips OLS: b_π={beta_ph[0]:.4f}, b_π_lag={beta_ph[1]:.4f}, b_y={beta_ph[2]:.4f}")
        logger.info(f"  COVID effects: κ_2020={beta_ph[3]:.4f}, κ_2021={beta_ph[4]:.4f}, κ_2022={beta_ph[5]:.4f}")

        return {
            'b_pi': beta_ph[0],
            'b_pi_lag': beta_ph[1],
            'b_y': beta_ph[2],
            'kappa_2020': beta_ph[3],
            'kappa_2021': beta_ph[4],
            'kappa_2022': beta_ph[5],
            'sigma_ph': sigma_ph
        }

    def unpack_parameters_stage1(self, theta: np.ndarray, T: int) -> dict:
        """
        Unpack parameter vector into state-space matrices.

        Following unpack.parameters.stage1.R structure.

        Parameter vector theta (11 params):
        [a_y1, a_y2, b_pi, b_pi_lag, b_y, kappa_2020, kappa_2021,
         g, sigma_is, sigma_ph, sigma_y_star]

        Returns:
            Dictionary with F, Q, A, H, R, cons matrices
        """
        # Extract parameters
        a_y1, a_y2 = theta[0], theta[1]
        b_pi, b_pi_lag, b_y = theta[2], theta[3], theta[4]
        kappa_2020, kappa_2021 = theta[5], theta[6]
        g = theta[7]
        sigma_is, sigma_ph, sigma_y_star = theta[8], theta[9], theta[10]

        # Matrix A: coefficients for exogenous regressors (7 regressors x 2 observations)
        A = np.zeros((7, 2))
        A[0:2, 0] = [a_y1, a_y2]              # GDP obs: a_y1*log_y_{t-1} + a_y2*log_y_{t-2}
        A[0, 1] = b_y                          # Inflation obs: b_y*output_gap_{t-1}
        A[2:4, 1] = [b_pi, b_pi_lag]          # Inflation obs: b_pi*π_{t-1} + b_pi_lag*π_{t-2,4}
        A[4, 1] = 1 - b_pi - b_pi_lag         # ⚠️ HLW CONSTRAINT: terceiro lag com (1-b_pi-b_pi_lag)
        A[5:7, 1] = [kappa_2020, kappa_2021]  # COVID effects on inflation (only 2020, 2021)

        # Matrix H: observation equation (3 states x 2 observations)
        H = np.zeros((3, 2))
        H[0, 0] = 1.0                          # GDP obs: 1*y*_t
        H[1:3, 0] = [-a_y1, -a_y2]            # GDP obs: -a_y1*y*_{t-1} - a_y2*y*_{t-2}
        H[1, 1] = -b_y                         # Inflation obs: -b_y*y*_{t-1}

        # Matrix F: state transition (3x3)
        F = np.array([
            [1, 0, 0],  # y*_t = y*_{t-1} + g
            [1, 0, 0],  # y*_{t-1} = y*_{t-1}
            [0, 1, 0]   # y*_{t-2} = y*_{t-2}
        ])

        # Matrix Q: state covariance (only y*_t has innovation)
        Q = np.diag([sigma_y_star**2, 0, 0])

        # Matrix R: observation covariance
        R = np.diag([sigma_is**2, sigma_ph**2])

        # Constant in state equation
        cons = np.array([[g], [0], [0]])

        return {
            'F': F, 'Q': Q, 'A': A, 'H': H, 'R': R, 'cons': cons
        }

    def kalman_log_likelihood(self, theta: np.ndarray, y_data: np.ndarray,
                               x_data: np.ndarray) -> float:
        """
        Compute log-likelihood via Kalman Filter.

        Following kalman.log.likelihood.R structure.

        Args:
            theta: Parameter vector
            y_data: Observations (T, 2) - [GDP, inflation]
            x_data: Exogenous regressors (T, 7)

        Returns:
            Cumulative log-likelihood
        """
        T = y_data.shape[0]

        # Unpack parameters into matrices
        matrices = self.unpack_parameters_stage1(theta, T)
        F, Q, A, H, R, cons = matrices['F'], matrices['Q'], matrices['A'], matrices['H'], matrices['R'], matrices['cons']

        # Initialize state (diffuse prior)
        xi_tt = np.zeros((3, 1))
        P_tt = np.eye(3) * 1000

        ll_cum = 0.0

        for t in range(T):
            # Predict
            xi_ttm1 = F @ xi_tt + cons
            P_ttm1 = F @ P_tt @ F.T + Q

            # Prediction error
            y_pred = A.T @ x_data[t] + H.T @ xi_ttm1.flatten()
            prediction_error = y_data[t] - y_pred

            # Innovation covariance
            HPHR = H.T @ P_ttm1 @ H + R

            # Log-likelihood contribution
            try:
                sign, logdet = np.linalg.slogdet(HPHR)
                if sign <= 0:
                    return -np.inf
                ll_t = -0.5 * (2 * np.log(2*np.pi) + logdet +
                              prediction_error @ np.linalg.solve(HPHR, prediction_error))
                ll_cum += ll_t
            except np.linalg.LinAlgError:
                return -np.inf

            # Update
            K = P_ttm1 @ H @ np.linalg.solve(HPHR, np.eye(2))
            xi_tt = xi_ttm1 + K @ prediction_error.reshape(-1, 1)
            P_tt = P_ttm1 - K @ H.T @ P_ttm1

        return ll_cum

    def estimate(self, data: pd.DataFrame) -> dict:
        """Run Stage 1 estimation following HLW structure"""
        logger.info("=" * 60)
        logger.info("STAGE 1: PRELIMINARY ESTIMATION (HLW Structure)")
        logger.info("=" * 60)

        # Extract data
        log_gdp = data['y_t'].values
        inflation = data['pi_t'].values
        inflation_lags = data['pi_t_lag_avg'].values  # π_{t-2,4}
        inflation_lags2 = data['pi_t_lag_avg2'].values  # π_{t-5,8}
        covid_dummies = data[['D_2020', 'D_2021', 'D_2022']].values

        # Remove NaN values
        valid_idx = ~(np.isnan(log_gdp) | np.isnan(inflation) | np.isnan(inflation_lags) | np.isnan(inflation_lags2))
        log_gdp = log_gdp[valid_idx]
        inflation = inflation[valid_idx]
        inflation_lags = inflation_lags[valid_idx]
        inflation_lags2 = inflation_lags2[valid_idx]
        covid_dummies = covid_dummies[valid_idx]
        dates = data['date'].values[valid_idx]

        logger.info(f"Sample size after removing NaN: {len(log_gdp)} observations")

        # Step 1: Initial output gap via OLS with trend
        output_gap = self.estimate_initial_output_gap(log_gdp)

        # Step 2: IS curve OLS
        is_results = self.estimate_is_curve_ols(output_gap)

        # Step 3: Phillips curve OLS
        ph_results = self.estimate_phillips_curve_ols(inflation, inflation_lags,
                                                       output_gap, covid_dummies)

        # Step 4: Prepare data for Kalman Filter (skip first 8 obs for lags)
        T_start = 8
        y_data = np.column_stack([
            log_gdp[T_start:] * 100,  # GDP in basis points
            inflation[T_start:]        # Inflation
        ])

        x_data = np.column_stack([
            log_gdp[T_start-1:-1] * 100,     # log_y_{t-1}
            log_gdp[T_start-2:-2] * 100,     # log_y_{t-2}
            inflation[T_start-1:-1],          # π_{t-1}
            inflation_lags[T_start:],         # π_{t-2,4}
            inflation_lags2[T_start:],        # π_{t-5,8} (terceiro lag com constraint)
            covid_dummies[T_start:, 0],       # D_2020
            covid_dummies[T_start:, 1],       # D_2021
        ])

        # Step 5: Initial parameter vector from OLS
        # Note: kappa_2022 removed (terceiro lag gets automatic constraint)
        initial_theta = np.array([
            is_results['a_y1'],
            is_results['a_y2'],
            ph_results['b_pi'],
            ph_results['b_pi_lag'],
            ph_results['b_y'],
            ph_results['kappa_2020'],
            ph_results['kappa_2021'],
            0.01,  # g (quarterly trend growth ~4% annual)
            is_results['sigma_is'],
            ph_results['sigma_ph'],
            0.5    # sigma_y_star (initial guess)
        ])

        logger.info(f"\nInitial parameters from OLS:")
        param_names = ['a_y1', 'a_y2', 'b_pi', 'b_pi_lag', 'b_y',
                      'kappa_2020', 'kappa_2021',
                      'g', 'sigma_is', 'sigma_ph', 'sigma_y_star']
        for name, val in zip(param_names, initial_theta):
            logger.info(f"  {name:12s} = {val:10.6f}")

        # Step 6: MLE refinement via Kalman Filter
        logger.info("\nRefining via MLE with Kalman Filter...")

        def neg_log_lik(theta):
            return -self.kalman_log_likelihood(theta, y_data, x_data)

        # Bounds
        bounds = [
            (0.0, 2.0),      # a_y1
            (-1.0, 1.0),     # a_y2
            (0.0, 1.0),      # b_pi
            (0.0, 1.0),      # b_pi_lag (constraint: b_pi + b_pi_lag < 1)
            (0.025, 0.5),    # b_y (HLW constraint >= 0.025)
            (-10, 10),       # kappa_2020
            (-10, 10),       # kappa_2021
            (-0.02, 0.05),   # g (quarterly growth)
            (0.01, 5.0),     # sigma_is
            (0.1, 10.0),     # sigma_ph
            (0.001, 2.0),    # sigma_y_star
        ]

        result = minimize(neg_log_lik, initial_theta, method='L-BFGS-B',
                         bounds=bounds, options={'maxiter': 500, 'disp': True})

        theta_mle = result.x
        log_lik = -result.fun

        logger.info("\n" + "=" * 60)
        logger.info("STAGE 1 RESULTS")
        logger.info("=" * 60)
        logger.info(f"\nLog-likelihood: {log_lik:.4f}")
        logger.info(f"Optimization status: {result.message}")

        logger.info("\nMLE Parameter Estimates:")
        for name, val in zip(param_names, theta_mle):
            logger.info(f"  {name:12s} = {val:10.6f}")

        # Extract final parameters
        params = dict(zip(param_names, theta_mle))

        return {
            'params': params,
            'log_likelihood': log_lik,
            'optimization_result': result,
            'dates': dates[T_start:],
            'y_data': y_data,
            'x_data': x_data
        }
