"""
Validation utilities for HLW-COVID Brasil project.

This module provides functions to validate data quality and consistency.
"""

import logging
from typing import Dict, List, Optional, Tuple

import pandas as pd
import numpy as np


logger = logging.getLogger(__name__)


def validate_quarterly_data(
    df: pd.DataFrame,
    date_column: str = "date",
    tolerance_days: int = 5,
) -> Tuple[bool, str]:
    """
    Check if data is in quarterly frequency.

    Args:
        df: DataFrame with date column.
        date_column: Name of the date column.
        tolerance_days: Tolerance in days for quarter boundaries.

    Returns:
        Tuple of (is_valid, message).
    """
    if date_column not in df.columns:
        return False, f"Column '{date_column}' not found"

    if len(df) < 2:
        return False, "Not enough observations to validate frequency"

    # Convert to datetime if not already
    dates = pd.to_datetime(df[date_column])

    # Calculate differences in days
    date_diffs = dates.diff().dt.days.dropna()

    # Quarterly should be approximately 90 days (allow some variation)
    expected_days = 90
    tolerance = 15  # Allow ±15 days variation

    # Check if most differences are close to quarterly
    quarterly_mask = (date_diffs >= expected_days - tolerance) & (
        date_diffs <= expected_days + tolerance
    )

    quarterly_pct = quarterly_mask.sum() / len(quarterly_mask)

    if quarterly_pct >= 0.8:  # At least 80% should be quarterly
        logger.info(
            f"Data validated as quarterly ({quarterly_pct:.1%} of intervals)"
        )
        return True, f"Quarterly data validated ({quarterly_pct:.1%} match)"
    else:
        msg = (
            f"Data does not appear to be quarterly "
            f"(only {quarterly_pct:.1%} of intervals match)"
        )
        logger.warning(msg)
        return False, msg


def check_missing_values(
    df: pd.DataFrame,
    max_missing_pct: float = 0.05,
    exclude_columns: Optional[List[str]] = None,
) -> Tuple[bool, Dict[str, float]]:
    """
    Check for missing values in DataFrame.

    Args:
        df: DataFrame to check.
        max_missing_pct: Maximum allowed percentage of missing values (0-1).
        exclude_columns: Columns to exclude from check.

    Returns:
        Tuple of (is_valid, missing_info_dict).
        missing_info_dict maps column names to percentage missing.
    """
    if exclude_columns is None:
        exclude_columns = []

    # Select columns to check
    columns_to_check = [col for col in df.columns if col not in exclude_columns]

    missing_info = {}
    has_excessive_missing = False

    for col in columns_to_check:
        n_missing = df[col].isnull().sum()
        pct_missing = n_missing / len(df)
        missing_info[col] = pct_missing

        if pct_missing > max_missing_pct:
            has_excessive_missing = True
            logger.warning(
                f"Column '{col}' has {pct_missing:.1%} missing values "
                f"(threshold: {max_missing_pct:.1%})"
            )

    if not has_excessive_missing:
        logger.info("Missing values check passed")
        return True, missing_info
    else:
        return False, missing_info


def validate_date_range(
    df: pd.DataFrame,
    expected_start: str,
    expected_end: str,
    date_column: str = "date",
    strict: bool = False,
) -> Tuple[bool, str]:
    """
    Validate that data covers expected date range.

    Args:
        df: DataFrame with date column.
        expected_start: Expected start date (e.g., "2000-Q1" or "2000-01-01").
        expected_end: Expected end date.
        date_column: Name of the date column.
        strict: If True, dates must match exactly. If False, allows some flexibility.

    Returns:
        Tuple of (is_valid, message).
    """
    if date_column not in df.columns:
        return False, f"Column '{date_column}' not found"

    dates = pd.to_datetime(df[date_column])
    actual_start = dates.min()
    actual_end = dates.max()

    expected_start_dt = pd.to_datetime(expected_start)
    expected_end_dt = pd.to_datetime(expected_end)

    if strict:
        # Exact match required
        if actual_start == expected_start_dt and actual_end == expected_end_dt:
            msg = (
                f"Date range validated: {actual_start.date()} to {actual_end.date()}"
            )
            logger.info(msg)
            return True, msg
        else:
            msg = (
                f"Date range mismatch. Expected: {expected_start_dt.date()} to "
                f"{expected_end_dt.date()}, Got: {actual_start.date()} to "
                f"{actual_end.date()}"
            )
            logger.warning(msg)
            return False, msg
    else:
        # Allow some flexibility (within 6 months)
        tolerance = pd.Timedelta(days=180)

        start_ok = abs(actual_start - expected_start_dt) <= tolerance
        end_ok = abs(actual_end - expected_end_dt) <= tolerance

        if start_ok and end_ok:
            msg = (
                f"Date range validated (flexible): {actual_start.date()} to "
                f"{actual_end.date()} (expected: {expected_start_dt.date()} to "
                f"{expected_end_dt.date()})"
            )
            logger.info(msg)
            return True, msg
        else:
            msg = (
                f"Date range outside tolerance. Expected: {expected_start_dt.date()} "
                f"to {expected_end_dt.date()}, Got: {actual_start.date()} to "
                f"{actual_end.date()}"
            )
            logger.warning(msg)
            return False, msg


def check_covid_period(
    df: pd.DataFrame,
    date_column: str = "date",
    stringency_column: str = "d_t",
    covid_start: str = "2020-Q2",
    covid_end: str = "2022-Q4",
    min_stringency: float = 10.0,
) -> Tuple[bool, Dict]:
    """
    Validate COVID period data (stringency index).

    Checks that:
    1. Stringency data exists for COVID period
    2. Stringency values are in valid range [0, 100]
    3. Stringency shows elevated levels during COVID period

    Args:
        df: DataFrame with date and stringency columns.
        date_column: Name of the date column.
        stringency_column: Name of the stringency index column.
        covid_start: Start of COVID period.
        covid_end: End of COVID period.
        min_stringency: Minimum average stringency expected during COVID.

    Returns:
        Tuple of (is_valid, info_dict).
    """
    info = {}

    # Check if columns exist
    if date_column not in df.columns:
        return False, {"error": f"Column '{date_column}' not found"}

    if stringency_column not in df.columns:
        logger.warning(f"Column '{stringency_column}' not found, skipping COVID check")
        return True, {"warning": "Stringency column not available"}

    # Convert dates
    dates = pd.to_datetime(df[date_column])
    covid_start_dt = pd.to_datetime(covid_start)
    covid_end_dt = pd.to_datetime(covid_end)

    # Filter COVID period
    covid_mask = (dates >= covid_start_dt) & (dates <= covid_end_dt)
    covid_data = df[covid_mask][stringency_column]

    if len(covid_data) == 0:
        msg = f"No data found for COVID period ({covid_start} to {covid_end})"
        logger.warning(msg)
        return False, {"error": msg}

    info["covid_observations"] = len(covid_data)

    # Check value range [0, 100]
    min_val = covid_data.min()
    max_val = covid_data.max()
    mean_val = covid_data.mean()

    info["min_stringency"] = min_val
    info["max_stringency"] = max_val
    info["mean_stringency"] = mean_val

    if min_val < 0 or max_val > 100:
        msg = (
            f"Stringency values out of range [0, 100]: "
            f"min={min_val:.1f}, max={max_val:.1f}"
        )
        logger.error(msg)
        return False, {**info, "error": msg}

    # Check if stringency shows elevated levels
    if mean_val < min_stringency:
        msg = (
            f"Mean stringency during COVID ({mean_val:.1f}) is below "
            f"expected minimum ({min_stringency})"
        )
        logger.warning(msg)
        info["warning"] = msg

    # Check for missing values in COVID period
    missing_covid = covid_data.isnull().sum()
    info["missing_values"] = int(missing_covid)

    if missing_covid > 0:
        pct_missing = missing_covid / len(covid_data)
        msg = (
            f"{missing_covid} missing values in COVID period "
            f"({pct_missing:.1%})"
        )
        logger.warning(msg)
        info["warning"] = msg

    logger.info(
        f"COVID period validated: {len(covid_data)} observations, "
        f"mean stringency={mean_val:.1f}"
    )

    return True, info


def validate_model_data(
    df: pd.DataFrame,
    required_columns: Optional[List[str]] = None,
    config: Optional[Dict] = None,
) -> Tuple[bool, List[str]]:
    """
    Comprehensive validation of model-ready data.

    Args:
        df: Model data DataFrame.
        required_columns: List of required column names.
        config: Configuration dictionary with validation parameters.

    Returns:
        Tuple of (is_valid, list_of_issues).
    """
    issues = []

    if required_columns is None:
        required_columns = ["date", "y_t", "pi_t", "r_t"]

    # Check required columns
    missing_cols = [col for col in required_columns if col not in df.columns]
    if missing_cols:
        issues.append(f"Missing required columns: {missing_cols}")

    # Check minimum observations
    min_obs = config.get("validation", {}).get("min_observations", 40) if config else 40
    if len(df) < min_obs:
        issues.append(
            f"Insufficient observations: {len(df)} (minimum: {min_obs})"
        )

    # Check quarterly frequency
    if "date" in df.columns:
        is_quarterly, msg = validate_quarterly_data(df)
        if not is_quarterly:
            issues.append(f"Frequency issue: {msg}")

    # Check missing values
    max_missing = (
        config.get("validation", {}).get("max_missing_pct", 0.05) if config else 0.05
    )
    is_valid, missing_info = check_missing_values(df, max_missing_pct=max_missing)
    if not is_valid:
        for col, pct in missing_info.items():
            if pct > max_missing:
                issues.append(
                    f"Column '{col}' has {pct:.1%} missing (max: {max_missing:.1%})"
                )

    # Check for infinite values
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if np.isinf(df[col]).any():
            issues.append(f"Column '{col}' contains infinite values")

    # Summary
    if not issues:
        logger.info("Model data validation passed")
        return True, []
    else:
        logger.warning(f"Model data validation failed with {len(issues)} issues")
        for issue in issues:
            logger.warning(f"  - {issue}")
        return False, issues
