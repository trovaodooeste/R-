"""Test Stage 1 Fixed implementation"""
import sys
from pathlib import Path
import logging

sys.path.insert(0, str(Path(__file__).parent / "src"))

from data.loader import DataLoader
from data.preprocessing import DataPreprocessor
from estimation.stage1_preliminary_fixed import Stage1EstimatorFixed

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    print("Testing Stage 1 Fixed Implementation")
    print("=" * 60)
    
    config_path = Path("config/config.yaml")
    
    # Load data
    print("\nLoading data...")
    loader = DataLoader(config_path)
    raw_data = loader.load_all()
    
    # Preprocess
    print("Preprocessing...")
    preprocessor = DataPreprocessor(config_path)
    model_data = preprocessor.create_model_data(raw_data)
    
    print(f"Data shape: {model_data.shape}")
    print(f"Columns: {list(model_data.columns)}")
    
    # Run Stage 1
    print("\nRunning Stage 1 estimation...")
    stage1 = Stage1EstimatorFixed(config_path)
    results = stage1.estimate(model_data)
    
    print("\n" + "=" * 60)
    print("STAGE 1 COMPLETE")
    print("=" * 60)
    print(f"Log-likelihood: {results['log_likelihood']:.4f}")
    print("\nEstimated parameters:")
    for k, v in results['params'].items():
        print(f"  {k:15s} = {v:10.6f}")

if __name__ == "__main__":
    main()
