# Implementação Completa do Modelo HLW-COVID Brasil

## Resumo Executivo

Implementação completa do modelo Holston-Laubach-Williams (HLW) adaptado para o Brasil com ajustes COVID-19, incluindo:

✅ **Modelo de Espaço de Estados** completo com 6 estados e 2 observações
✅ **Filtro de Kalman** implementado do zero (sem dependência do FilterPy)
✅ **Estimação MLE** via scipy.optimize
✅ **Extração de r*** e estados latentes com bandas de confiança
✅ **Pipeline completo** de dados até visualização

## Arquivos Implementados

### 1. Modelo e Estimação

**`src/models/hlw_model.py`** (600+ linhas)
- Classe `HLWModel`: Define modelo de espaço de estados
- Classe `KalmanFilter`: Implementa predição e atualização
- Matrizes do sistema: F (transição), H (observação), Q (ruído estado), R (ruído observação)
- Tratamento de COVID via Stringency Index e dummies

**`src/estimation/mle.py`** (350+ linhas)
- Classe `HLWEstimator`: Otimização MLE
- Função `negative_log_likelihood`: Avalia modelo
- Função `compute_standard_errors`: Hessiano numérico
- Função `extract_r_star`: Extrai taxa natural e estados

### 2. Scripts de Execução

**`run_estimation.py`** (180+ linhas)
- Pipeline completo automatizado
- Carregamento → Pré-processamento → Estimação → Extração → Salvamento
- Logging detalhado em `outputs/hlw_estimation.log`
- Salva 3 formatos: CSV, pickle, parâmetros separados

**`inspect_data.py`** (30 linhas)
- Utilitário para inspecionar estrutura do Excel

### 3. Análise de Resultados

**`notebooks/02_analise_resultados.ipynb`**
- 13 seções de análise completa
- 6 gráficos principais + dashboard integrado
- Análise do período COVID
- Comparação com literatura
- Exportação para LaTeX

## Especificação Matemática Implementada

### Vetor de Estados (6×1)

```
x_t = [y*_t, g_t, r*_t, ỹ_t, ỹ_t-1, (r-r*)_t-1]ᵀ
```

### Equações de Estado

```
y*_t = y*_{t-1} + g_{t-1} + ε_{y*,t}                    (PIB potencial)
g_t = g_{t-1} + ε_{g,t}                                 (Crescimento tendencial)
r*_t = r*_{t-1} + β·d_t + ε_{r*,t}                     (Taxa natural + COVID)
ỹ_t = a_r·ỹ_{t-1} - b_y·(r_{t-1} - r*_{t-1}) + ε_{ỹ,t} (Curva IS)
```

### Equações de Observação

```
y_t = y*_t + ỹ_t                                        (PIB observado)
π_t = π_{t-2,4} + κ_2020·D_2020 + κ_2021·D_2021 + κ_2022·D_2022 + ε_{π,t}
```

### Parâmetros Estimados (11 total)

1. **Razões de variância:**
   - `lambda_g`: Var(g) / Var(ỹ)
   - `lambda_z`: Var(r*) / Var(ỹ)

2. **Coeficientes estruturais:**
   - `a_r`: Persistência do hiato do produto
   - `b_y`: Sensibilidade do produto ao hiato da taxa real

3. **Desvios-padrão:**
   - `sigma_y_tilde`: Choque do hiato do produto
   - `sigma_y_star`: Choque do PIB potencial
   - `sigma_pi`: Choque da inflação

4. **Efeitos COVID:**
   - `kappa_2020`: Efeito estrutural na inflação em 2020
   - `kappa_2021`: Efeito estrutural na inflação em 2021
   - `kappa_2022`: Efeito estrutural na inflação em 2022
   - `beta`: Efeito do Stringency Index em r*

## Algoritmo do Filtro de Kalman

### Predição (Time Update)

```python
x̂_{t|t-1} = F @ x̂_{t-1|t-1} + B @ u_t
P_{t|t-1} = F @ P_{t-1|t-1} @ F.T + Q
```

### Atualização (Measurement Update)

```python
ν_t = z_t - H @ x̂_{t|t-1} - d_t        # Inovação
S_t = H @ P_{t|t-1} @ H.T + R           # Covariância da inovação
K_t = P_{t|t-1} @ H.T @ inv(S_t)        # Ganho de Kalman
x̂_{t|t} = x̂_{t|t-1} + K_t @ ν_t         # Estado atualizado
P_{t|t} = (I - K_t @ H) @ P_{t|t-1}     # Covariância atualizada (Joseph form)
```

### Log-Verossimilhança

```python
log L = -0.5 * Σ_t [m·log(2π) + log|S_t| + ν_t.T @ inv(S_t) @ ν_t]
```

## Fluxo de Execução

### 1. Preparação dos Dados

```python
from src.data.loader import DataLoader
from src.data.preprocessing import DataPreprocessor

loader = DataLoader("config/config.yaml")
raw_data = loader.load_all()

preprocessor = DataPreprocessor("config/config.yaml")
model_data = preprocessor.create_model_data(raw_data)
```

**Saída:** DataFrame com colunas `[date, y_t, pi_t, r_t, pi_t_lag_avg, d_t, D_2020, D_2021, D_2022]`

### 2. Estimação MLE

```python
from src.estimation.mle import HLWEstimator

estimator = HLWEstimator(
    observations=model_data[['y_t', 'pi_t']].values,
    real_rates=model_data['r_t'].values,
    pi_lags=model_data['pi_t_lag_avg'].values,
    covid_data=model_data[['d_t', 'D_2020', 'D_2021', 'D_2022']].values,
)

results = estimator.estimate(maxiter=500)
```

**Saída:** Dicionário com parâmetros estimados, log-verossimilhança, status de convergência

### 3. Extração de r*

```python
from src.estimation.mle import extract_r_star

r_star, r_star_se, states = extract_r_star(
    params=results['params'],
    observations=observations,
    real_rates=real_rates,
    pi_lags=pi_lags,
    covid_data=covid_data,
)
```

**Saída:**
- `r_star`: Série temporal da taxa natural (T,)
- `r_star_se`: Erros-padrão (T,)
- `states`: Dict com y*, g, ỹ

### 4. Visualização

Execute o notebook `02_analise_resultados.ipynb` para:
- Gráficos de r* com bandas de confiança
- Hiato da taxa real (r - r*)
- PIB observado vs potencial
- Hiato do produto
- Crescimento tendencial
- Dashboard completo com 6 painéis

## Outputs Gerados

### Arquivos de Resultados

```
outputs/results/
├── hlw_estimates.csv              # Série completa: datas, r*, estados, gaps
├── parameter_estimates.csv         # Parâmetros estimados + erros padrão + t-stats
├── estimation_results.pkl          # Objeto Python completo (pickle)
└── parameters_table.tex            # Tabela LaTeX para paper
```

### Figuras

```
outputs/figures/
├── r_star_series.png               # r* com IC 95%
├── real_rate_gap.png               # r - r* (orientação da política)
├── gdp_actual_vs_potential.png     # y vs y*
├── output_gap.png                  # Hiato do produto
├── trend_growth.png                # Crescimento tendencial
└── dashboard_completo.png          # 6 painéis integrados
```

### Logs

```
outputs/hlw_estimation.log          # Log completo da estimação
```

## Uso Rápido

### Opção 1: Script completo

```bash
python run_estimation.py
```

Isso executa tudo e salva resultados em `outputs/`.

### Opção 2: Passo a passo (Python)

```python
from pathlib import Path
from src.data.loader import DataLoader
from src.data.preprocessing import DataPreprocessor
from src.estimation.mle import HLWEstimator, extract_r_star

# 1. Carregar dados
loader = DataLoader(Path("config/config.yaml"))
raw_data = loader.load_all()

# 2. Pré-processar
preprocessor = DataPreprocessor(Path("config/config.yaml"))
model_data = preprocessor.create_model_data(raw_data)

# 3. Preparar arrays
model_data = model_data.dropna()
observations = model_data[['y_t', 'pi_t']].values
real_rates = model_data['r_t'].values
pi_lags = model_data['pi_t_lag_avg'].values
covid_data = model_data[['d_t', 'D_2020', 'D_2021', 'D_2022']].values

# 4. Estimar
estimator = HLWEstimator(observations, real_rates, pi_lags, covid_data)
results = estimator.estimate(maxiter=500)

# 5. Extrair r*
r_star, r_star_se, states = extract_r_star(
    results['params'], observations, real_rates, pi_lags, covid_data
)

print(f"r* atual: {r_star[-1]:.4f} ± {1.96*r_star_se[-1]:.4f}")
```

### Opção 3: Jupyter Notebook

```bash
# Exploração de dados
jupyter notebook notebooks/01_exploracao_dados.ipynb

# Análise de resultados (após estimação)
jupyter notebook notebooks/02_analise_resultados.ipynb
```

## Configuração Avançada

### Ajustar bounds dos parâmetros

Edite `config/config.yaml`:

```yaml
model:
  bounds:
    lambda_g: [0.001, 0.5]    # Aumentar limite superior se necessário
    lambda_z: [0.001, 0.5]
    a_r: [0.0, 0.99]          # Persistência < 1 para estacionariedade
    b_y: [0.001, 1.0]
```

### Valores iniciais

No script `run_estimation.py`, linha ~80:

```python
initial_params = {
    'lambda_g': 0.0625,   # Ajustar conforme literatura
    'lambda_z': 0.0373,
    # ... etc
}
```

### Método de otimização

```python
results = estimator.estimate(
    method='L-BFGS-B',  # Ou: 'SLSQP', 'trust-constr'
    maxiter=1000,       # Aumentar se não convergir
)
```

## Detalhes de Implementação

### Tratamento de COVID

1. **Stringency Index (`d_t`):**
   - Entra na equação de r*: `r*_t = r*_{t-1} + β·d_t + ε_{r*,t}`
   - Permite que restrições COVID afetem taxa natural diretamente

2. **Dummies anuais:**
   - `D_2020`: Q2-Q4/2020 (início da pandemia)
   - `D_2021`: Q1-Q4/2021 (recuperação gradual)
   - `D_2022`: Q1-Q4/2022 (normalização)
   - Entram na equação de inflação via `κ_t`

### Estabilidade Numérica

- **Simetrização de covariâncias:** `P = (P + P.T) / 2`
- **Joseph form** para atualização de P (mais estável)
- **Pseudoinversa** como fallback se S for singular
- **Penalização** de likelihood = 1e10 se avaliação falhar

### Performance

- **Vetorização:** Operações matriciais via NumPy
- **Callback logging:** Log a cada 10 iterações
- **Warm start:** Use parâmetros estimados como inicial em re-estimações

## Limitações Conhecidas

1. **Inicialização do filtro:** Estados iniciais via heurística simples
2. **Expectations:** E[π_{t+1}] aproximado por MA(4) dos dados
3. **Dados faltantes:** Removidos (não imputados)
4. **FilterPy:** Não usado (implementação própria mais transparente)

## Próximos Passos Sugeridos

1. **Análise de Sensibilidade:**
   - Variar λ_g, λ_z em grid
   - Avaliar robustez de r* a especificação

2. **Smoother:**
   - Implementar RTS smoother para estimativas suavizadas
   - Melhorar precisão de estados históricos

3. **Testes de Diagnóstico:**
   - Autocorrelação dos resíduos
   - Normalidade dos resíduos
   - Testes de especificação

4. **Comparações:**
   - Modelo sem ajustes COVID
   - Outras especificações de r*
   - Literatura internacional

5. **Robustez:**
   - Bootstrap para ICs dos parâmetros
   - Monte Carlo para incerteza de r*

## Referências Técnicas

**Modelo HLW original:**
- Holston, K., Laubach, T., & Williams, J. C. (2017). "Measuring the natural rate of interest: International trends and determinants." *Journal of International Economics*, 108, 59-75.

**Filtro de Kalman:**
- Durbin, J., & Koopman, S. J. (2012). *Time Series Analysis by State Space Methods* (2nd ed.). Oxford University Press.

**MLE para modelos de espaço de estados:**
- Hamilton, J. D. (1994). *Time Series Analysis*. Princeton University Press.

**Stringency Index:**
- Hale, T., et al. (2021). "A global panel database of pandemic policies (Oxford COVID-19 Government Response Tracker)." *Nature Human Behaviour*, 5(4), 529-538.

## Suporte

Para questões sobre a implementação:
1. Consulte a documentação inline (docstrings)
2. Veja CLAUDE.md para guia de arquitetura
3. Execute com `logging.level = DEBUG` para diagnóstico detalhado

---

**Versão:** 1.0
**Data:** Novembro 2024
**Status:** Implementação completa e funcional
