# Limpeza de Arquivos - HLW Brasil

**Data**: 2025-11-20

## ✅ ARQUIVOS A MANTER (Implementação HLW Canônica)

### **Core - Three-Stage Method**
```
src/estimation/
  ├── __init__.py                           ✅ (atualizar imports)
  ├── stage1_preliminary_fixed.py           ✅ Stage 1 HLW
  ├── stage2_with_interest_rate_fixed.py    ✅ Stage 2 HLW
  ├── stage3_full_rstar.py                  ✅ Stage 3 HLW (já existe)
  └── median_unbiased_estimator.py          ✅ Median-unbiased (Stock-Watson)

src/models/
  ├── __init__.py                           ✅
  └── hlw_model_brazilian.py                ✅ (8 estados, usado no Stage 3)

src/data/
  ├── __init__.py                           ✅
  ├── loader.py                             ✅
  └── preprocessing.py                      ✅

Root scripts:
  ├── test_stage1_fixed.py                  ✅ Testes Stage 1
  ├── test_stage2_fixed.py                  ✅ Testes Stage 2
  └── run_three_stage_estimation.py         ✅ Pipeline completo
```

---

## ❌ ARQUIVOS OBSOLETOS (Remover)

### **Estimação Legacy (MLE Full)**
```
src/estimation/
  ├── mle.py                                ❌ MLE full (deprecated)
  ├── mle_brazilian.py                      ❌ MLE full brasileiro (deprecated)
  ├── stage1_preliminary.py                 ❌ Versão antiga Stage 1
  └── stage2_with_interest_rate.py          ❌ Versão antiga Stage 2

src/models/
  └── hlw_model.py                          ❌ Modelo original USA (não usado)

Root scripts:
  ├── run_estimation.py                     ❌ Legacy MLE
  ├── run_estimation_brazilian.py           ❌ Legacy MLE brasileiro
  ├── test_brazilian_model.py               ❌ Teste MLE (obsoleto)
  ├── quick_estimation.py                   ❌ Teste rápido (obsoleto)
  ├── example_usage.py                      ❌ Exemplo antigo
  ├── gerar_graficos_old.py                 ❌ Versão antiga gráficos
```

### **Scripts de Debug/Utilitários (Manter ou Remover?)**
```
  ├── debug_stage1_mle.py                   ? Debug útil (pode manter)
  ├── inspect_data.py                       ? Inspeção dados (pode manter)
  ├── download_expectativas.py              ? Download Focus BCB (pode manter)
  ├── prepare_data.py                       ? Prep dados (pode manter)
  ├── gerar_graficos.py                     ? Visualização (pode manter)
  ├── visualize_results.py                  ? Visualização (pode manter)
  └── setup.py                              ✅ Setup pip (manter)
```

---

## 🗑️ AÇÃO: REMOVER ARQUIVOS OBSOLETOS

### Comando:
```bash
cd /home/rovao/macacagem-economica

# Remover estimação legacy
rm src/estimation/mle.py
rm src/estimation/mle_brazilian.py
rm src/estimation/stage1_preliminary.py
rm src/estimation/stage2_with_interest_rate.py

# Remover modelo USA
rm src/models/hlw_model.py

# Remover scripts obsoletos
rm run_estimation.py
rm run_estimation_brazilian.py
rm test_brazilian_model.py
rm quick_estimation.py
rm example_usage.py
rm gerar_graficos_old.py
```

### Atualizar `__init__.py`:
```python
# src/estimation/__init__.py
"""Three-Stage HLW Estimation (Canonical Implementation)"""

from .stage1_preliminary_fixed import Stage1EstimatorFixed
from .stage2_with_interest_rate_fixed import Stage2EstimatorFixed
from .stage3_full_rstar import Stage3Estimator
from .median_unbiased_estimator import median_unbiased_estimator_hlw

__all__ = [
    "Stage1EstimatorFixed",
    "Stage2EstimatorFixed",
    "Stage3Estimator",
    "median_unbiased_estimator_hlw"
]
```

---

## 📁 ESTRUTURA FINAL (Limpa)

```
macacagem-economica/
├── src/
│   ├── data/
│   │   ├── __init__.py
│   │   ├── loader.py
│   │   └── preprocessing.py
│   ├── estimation/
│   │   ├── __init__.py
│   │   ├── stage1_preliminary_fixed.py       (Stage 1 - sem taxa juros)
│   │   ├── stage2_with_interest_rate_fixed.py (Stage 2 - com taxa juros)
│   │   ├── stage3_full_rstar.py              (Stage 3 - r* = g + z)
│   │   └── median_unbiased_estimator.py      (Stock-Watson 1998)
│   └── models/
│       ├── __init__.py
│       └── hlw_model_brazilian.py            (8 estados - usado Stage 3)
├── config/
│   └── config.yaml
├── data/
│   └── raw/dados_completos_2000_2025.xlsx
├── test_stage1_fixed.py
├── test_stage2_fixed.py
├── run_three_stage_estimation.py
├── debug_stage1_mle.py                       (opcional)
├── inspect_data.py                           (opcional)
├── gerar_graficos.py                         (opcional)
└── visualize_results.py                      (opcional)
```

**Total**: ~15 arquivos principais (vs ~25 antes)

---

## 🎯 BENEFÍCIOS

1. **Clareza**: Apenas arquivos relacionados ao método 3-stage HLW
2. **Manutenção**: Menos confusão sobre qual arquivo usar
3. **Documentação**: Estrutura alinhada com CLAUDE.md
4. **Performance**: Imports mais rápidos
