# Comparação: Nossa Implementação vs. Roberto Torres (2023)

**Data**: 2025-11-18

---

## 📊 RESUMO EXECUTIVO

Analisados os arquivos do trabalho de Roberto Torres (TCC 2023). **Diferenças críticas identificadas**:

1. **Método de estimação**: Torres usa **3 estágios separados** (Stock-Watson), nós usamos **MLE em passo único**
2. **Especificação**: Torres usa **modelo original HLW (6 estados)**, nós usamos **variante brasileira (8 estados)**
3. **Período**: Torres: 1998-Q3 a 2023-Q1 | Nós: 2000-Q3 a 2025-Q1
4. **COVID**: Torres não incorpora COVID explicitamente | Nós temos dummies + stringency

---

## 🔍 DIFERENÇAS TÉCNICAS DETALHADAS

### 1. Método de Estimação

#### Roberto Torres (Stock-Watson 3 estágios):
```
Estágio 1: Estima λ_g (razão de variância g/y*)
    - Usa median unbiased estimator
    - Fixa outros parâmetros

Estágio 2: Estima parâmetros IS e Phillips
    - λ_g fixo do estágio 1
    - Estima a_1, a_2, a_3, b_1, b_2, σ_IS, σ_π

Estágio 3: Estima λ_z e finaliza r*
    - λ_g e params estruturais fixos
    - Estima λ_z (razão de variância z)
    - Extrai r* = g + z
```

#### Nossa Implementação (MLE simultâneo):
```
Passo único: Estima TODOS os 14 parâmetros simultaneamente
    - Maximiza log-likelihood conjunta
    - Não assume sequencialidade
    - Mais eficiente mas computacionalmente intensivo
```

**Implicações**:
- Stock-Watson é mais rápido mas pode ser subótimo
- MLE simultâneo é teoricamente superior mas pode ter problemas de identificação
- Explica por que nossos parâmetros estão nos limites (MLE tentando compensar)

---

### 2. Especificação do Modelo

#### Roberto Torres (HLW Original - 6 estados):
```r
Estados: [y*, g, z, y*_{t-1}, g_{t-1}, z_{t-1}]

IS Curve:
ỹ_t = a_1·ỹ_{t-1} + a_2·ỹ_{t-2} + a_3/2·[(r-r*)_{t-1} + (r-r*)_{t-2}] + ε_t

Phillips Curve:
π_t = b_1·π_{t-1} + (1-b_1)·π*_{t-2,4} + b_2·ỹ_{t-1} + ε_t

r* = g_t + z_t
```

Parâmetros: **8** (a_1, a_2, a_3, b_1, b_2, σ_IS, σ_π, σ_ỹ*) + 2 lambdas

#### Nossa Implementação (Brasileira - 8 estados):
```python
Estados: [y*, g, z, h, h_{t-1}, h_{t-2}, (r-r*)_{t-1}, (r-r*)_{t-2}]

IS Curve:
h_t = a_y1·h_{t-1} + a_y2·h_{t-2} + (a_r/2)·[(r-r*)_{t-1} + (r-r*)_{t-2}] + ε_h

Phillips Curve:
π_t = b_π·π_{t-1} + (1-b_π)·π_{t-2,4} + b_y·h_{t-1}
      + κ_2020·D_2020 + κ_2021·D_2021 + κ_2022·D_2022 + ε_π

r* = g_t + z_t
```

Parâmetros: **14** (a_y1, a_y2, a_r, b_y, b_π, σ_h, σ_y*, σ_π, λ_g, λ_z, β, κ_2020, κ_2021, κ_2022)

**Diferenças principais**:
1. Torres: Lags de estados no vetor de estado | Nós: Lags explícitos de h e (r-r*)
2. Torres: Sem persistência inflacionária explícita | Nós: b_π para persistência
3. Torres: Sem COVID | Nós: 3 dummies + stringency

---

### 3. Constraints e Bounds

#### Roberto Torres:
```r
# Código do arquivo run.lw.model.rob.BRA.R

a3.constraint <- -0.0025  # a_3 ≤ -0.0025 (IS slope negativa)
b2.constraint <- 0.25     # b_2 ≥ 0.25 (Phillips slope positiva)

# Sem bounds explícitos para variâncias
# Usa bounds implícitos do nloptr
```

#### Nossa Implementação:
```yaml
# config.yaml
bounds:
  lambda_g: [0.001, 0.25]
  lambda_z: [0.01, 0.10]
  a_y1: [-2.0, 2.0]
  a_y2: [-2.0, 2.0]
  a_r: [0.001, 0.50]      # Sempre positivo
  b_y: [0.001, 0.50]
  b_pi: [0.0, 1.0]
  sigma_h: [0.01, 0.10]      # PROBLEMA: muito restrito
  sigma_y_star: [0.001, 0.01] # PROBLEMA: muito restrito
  sigma_pi: [0.50, 2.00]
```

**Problema identificado**: Nossos bounds de variância são muito apertados!
- Torres não restringe σ_IS, σ_π tanto
- Explica por que 5/10 params estão nos limites

---

### 4. Inicialização do Filtro de Kalman

#### Roberto Torres (Estágio 3):
```r
# HP filter com λ = 36,000
log.output.hp.trend <- hpfilter(log.output, freq=36000)$trend

# Estados iniciais
xi.00 <- c(100*g.pot[4:2],      # y*, y*_{t-1}, y*_{t-2}
           100*g.pot.diff[3:2],  # g, g_{t-1}
           2.2, 2.2)             # z, z_{t-1} (fixo em 2.2%)
```

#### Nossa Implementação:
```python
# Inicialização mais simples
x0 = np.array([
    np.log(model_data['y_t'].iloc[0]) * 100,  # y*
    0.5,  # g (crescimento inicial)
    4.0,  # z (componente r* inicial)
    0.0,  # h
    0.0, 0.0,  # h lags
    0.0, 0.0   # (r-r*) lags
])
```

**Diferença**: Torres usa HP filter para inicializar, nós usamos valores fixos.

---

### 5. Dados e Período

#### Roberto Torres:
```r
# Arquivo: Data.tccv2.csv
# Período: 1998-Q3 a 2023-Q1

gdp.nnivel        # PIB dessaz. ×100
inflation.4tri    # IPCA acum. 4 trim
focus.suavizada   # Exp. Focus 12m suavizada
selic.media       # Selic meta média trimestral

# Amostra de estimação: 1999-Q3 a 2023-Q1 (após lags)
```

#### Nossa Implementação:
```python
# Arquivo: dados_completos_2000_2025.xlsx
# Período: 2000-Q3 a 2025-Q1

y_t          # log PIB real
pi_t         # IPCA anualizado trimestral
r_t          # Taxa real ex-ante (Selic - E[π])
d_t          # Stringency index

# Amostra: 2000-Q3 a 2025-Q1 (99 obs)
```

**Diferenças**:
1. Torres começa em 1998 | Nós em 2000
2. Torres usa Focus para expectativas | Nós usamos MA(4) do IPCA
3. Torres não tem stringency | Nós temos

---

### 6. Resultados Esperados

#### Roberto Torres (esperado do código):
- r* filtrado e suavizado (smoothed)
- Output gap
- g (crescimento potencial)
- z (componente adicional)
- Erros-padrão via Monte Carlo (5000 iterações)

**Arquivo de saída**: `one.sided.est.csv`, `two.sided.est.csv`

#### Nossa Implementação:
- r* filtrado apenas (sem smoother)
- Output gap (PROBLEMÁTICO - 81%)
- g = 5,79%
- z = 4,00%
- Sem erros-padrão (Hessiana singular)

**Arquivo de saída**: `filtered_states_brazilian.csv`

---

## 🎯 O QUE FALTA NO NOSSO MODELO

### PRIORIDADE ALTA

#### 1. Implementar RTS Smoother (Two-sided estimates)
Torres usa estimativas suavizadas (backward pass). Nós só temos filtered.

```python
# TODO: Adicionar em src/models/hlw_model_brazilian.py
def rts_smoother(x_filt, P_filt, F, Q):
    """
    Rauch-Tung-Striebel smoother
    Retorna: x_smooth, P_smooth
    """
    pass
```

#### 2. Revisar Bounds das Variâncias
```yaml
# Proposta: Ampliar limites
sigma_h: [0.01, 1.0]        # Era [0.01, 0.10]
sigma_y_star: [0.001, 0.1]  # Era [0.001, 0.01]
sigma_pi: [0.10, 5.00]      # Era [0.50, 2.00]
```

#### 3. Testar Estimação em 3 Estágios (Stock-Watson)
Implementar método sequencial como Torres:
- Estágio 1: λ_g via median unbiased estimator
- Estágio 2: Params estruturais (a, b, σ)
- Estágio 3: λ_z e extração de r*

#### 4. Comparar com Resultados de Torres
Se ele tem outputs salvos, comparar:
- r* média e trajetória
- Parâmetros estimados
- Output gap (verificar se dele também é implausível)

### PRIORIDADE MÉDIA

#### 5. Implementar Monte Carlo para Erros-Padrão
```r
# Torres usa:
niter <- 5000
run.se <- TRUE

# Nós precisamos implementar bootstrap ou MC similar
```

#### 6. Usar HP Filter para Inicialização
```python
from scipy.signal import filtfilt

def hp_filter(y, lambda_hp=36000):
    # Implementar Hodrick-Prescott
    pass
```

#### 7. Testar Spec Original (6 estados) sem COVID
Rodar nosso código com modelo simplificado para comparar.

---

## 📋 CHECKLIST DE COMPARAÇÃO

### Dados
- [ ] Obter `Data.tccv2.csv` de Torres
- [ ] Comparar PIB, inflação, Selic entre as fontes
- [ ] Verificar se diferenças de período explicam resultados

### Código
- [ ] Copiar scripts R de Torres para repo (`modelo_roberto_torres/`)
- [ ] Documentar diferenças de especificação
- [ ] Implementar variante 3-stage em Python (opcional)

### Resultados
- [ ] Obter outputs de Torres (`one.sided.est.csv`)
- [ ] Comparar r* (média, trajetória, volatilidade)
- [ ] Comparar output gap (verificar se dele é plausível)
- [ ] Comparar parâmetros estimados

---

## 💡 INSIGHTS E RECOMENDAÇÕES

### Por que nosso output gap está implausível?

**Hipóteses**:
1. **Bounds muito apertados**: σ_h, σ_y* restritos demais
2. **MLE simultâneo**: Mais difícil de convergir que 3-stage
3. **Especificação diferente**: 8 estados vs 6 estados
4. **COVID mal especificado**: Dummies podem estar confundindo o modelo

### Por que a_r ≈ 0 no nosso modelo?

**Hipóteses**:
1. Torres **força a_3 < -0.0025** (negativo obrigatório)
2. Nós **permitimos a_r > 0** mas ele vai pra zero
3. **Possível**: Dados brasileiros não têm sensibilidade clara IS→taxa real?

### Qual modelo é "correto"?

**Não há resposta única**:
- Torres segue HLW (2017) fielmente → **Mais comparável com literatura**
- Nossa spec é mais rica (COVID, persistência) → **Mais realista para Brasil pós-2020**
- Torres usa 3-stage (mais rápido, subótimo) → **Mais robusto**
- Nós usamos MLE (ótimo, lento) → **Mais eficiente mas instável**

**Recomendação**: Implementar **ambas** as especificações e comparar.

---

## 🚀 PRÓXIMOS PASSOS CONCRETOS

### 1. Copiar arquivos de Torres para o repo
```bash
cp -r "C:/Users/Trovao/Desktop/Modelo Roberto Torres" ./modelo_roberto_torres/
```

### 2. Criar spec "HLW Original" em Python
```python
# Novo arquivo: src/models/hlw_model_original.py
class HLWModelOriginal:
    """6 estados, sem COVID, método Stock-Watson"""
    pass
```

### 3. Ampliar bounds e re-estimar
```yaml
# Em config.yaml
bounds:
  sigma_h: [0.01, 1.0]
  sigma_y_star: [0.001, 0.1]
  a_r: [-0.5, 0.5]  # Permitir negativo!
```

### 4. Implementar RTS Smoother
```python
# src/models/smoother.py
def rts_smooth(kf_output):
    # Backward pass
    pass
```

### 5. Comparar resultados lado a lado
Criar tabela:
| Métrica | Torres | Nossa Impl | Diferença |
|---------|--------|------------|-----------|
| r* média | ? | 9,79% | ? |
| Output gap | ? | 81% | ? |
| a_3/a_r | ? | 0,0015 | ? |

---

## 📁 ESTRUTURA PROPOSTA PARA REPO

```
macacagem-economica/
├── src/
│   ├── models/
│   │   ├── hlw_model_brazilian.py     ✅ Atual (8 estados)
│   │   ├── hlw_model_original.py      ❌ TODO (6 estados)
│   │   └── hlw_model.py               ⚠️ Legacy
│   ├── estimation/
│   │   ├── mle_brazilian.py           ✅ MLE simultâneo
│   │   ├── stock_watson_3stage.py     ❌ TODO
│   │   └── smoother.py                ❌ TODO (RTS)
│   └── ...
├── modelo_roberto_torres/             ❌ TODO
│   ├── Scripts/                       (Copiar de Desktop)
│   ├── Dados/
│   └── README.md                      (Documentar)
├── COMPARACAO_ROBERTO_TORRES.md       ✅ Este arquivo
└── ...
```

---

## ❓ PERGUNTAS PARA ANÁLISE

1. **Torres obteve output gap plausível?** (Verificar `one.sided.est.csv`)
2. **Qual r* média ele encontrou?** (Comparar com nossos 9,79%)
3. **λ_g e λ_z dele são similares aos nossos?**
4. **Ele reportou problemas de convergência?**
5. **Código dele roda facilmente ou requer ajustes?**

---

## 📊 CONCLUSÃO PRELIMINAR

**Achados principais**:
1. Roberto Torres usa especificação **mais conservadora e testada** (HLW original 6 estados)
2. Método dele é **mais robusto** (3-stage Stock-Watson)
3. Nossa implementação é **mais ambiciosa** (8 estados, COVID, MLE simultâneo)
4. Nossos problemas (output gap, params nos limites) podem ser por:
   - Bounds muito restritos
   - MLE simultâneo mais difícil
   - Especificação mais complexa

**Ação recomendada**:
1. **Curto prazo**: Ampliar bounds, re-estimar, implementar smoother
2. **Médio prazo**: Implementar spec original de Torres em Python
3. **Longo prazo**: Comparar 3-stage vs MLE, 6 vs 8 estados

---

**Próxima conversa**: Analisar outputs de Torres (se disponíveis) e decidir qual caminho seguir.
