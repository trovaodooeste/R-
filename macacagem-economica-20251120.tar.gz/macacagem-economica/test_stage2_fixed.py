"""Test Stage 2 Fixed implementation"""
import sys
from pathlib import Path
import logging
import numpy as np

sys.path.insert(0, str(Path(__file__).parent / "src"))

from data.loader import DataLoader
from data.preprocessing import DataPreprocessor
from estimation.stage1_preliminary_fixed import Stage1EstimatorFixed
from estimation.stage2_with_interest_rate_fixed import Stage2EstimatorFixed, compute_lambda_g_median_unbiased

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    print("Testing Stage 1 -> Stage 2 Pipeline")
    print("=" * 60)
    
    config_path = Path("config/config.yaml")
    
    # Load data
    print("\nLoading data...")
    loader = DataLoader(config_path)
    raw_data = loader.load_all()
    
    # Preprocess
    print("Preprocessing...")
    preprocessor = DataPreprocessor(config_path)
    model_data = preprocessor.create_model_data(raw_data)
    
    # Run Stage 1
    print("\n" + "=" * 60)
    print("RUNNING STAGE 1")
    print("=" * 60)
    stage1 = Stage1EstimatorFixed(config_path)
    stage1_results = stage1.estimate(model_data)
    
    print("\nStage 1 OLS parameters (will use these):")
    print(f"  a_y1  = {stage1_results['params']['a_y1']:.4f}")
    print(f"  a_y2  = {stage1_results['params']['a_y2']:.4f}")
    print(f"  b_pi  = {stage1_results['params']['b_pi']:.4f}")
    print(f"  b_y   = {stage1_results['params']['b_y']:.4f}")
    
    # Run Stage 2 with lambda_g = 0.05 (initial guess)
    print("\n" + "=" * 60)
    print("RUNNING STAGE 2 (Initial Pass)")
    print("=" * 60)

    lambda_g_initial = 0.05  # Initial guess
    print(f"Using λ_g = {lambda_g_initial} (initial guess)\n")

    stage2 = Stage2EstimatorFixed(config_path, stage1_results, lambda_g_initial)
    stage2_results = stage2.estimate(model_data)

    # Compute median-unbiased λ_g from Stage 2 results
    print("\n" + "=" * 60)
    print("COMPUTING MEDIAN-UNBIASED λ_g")
    print("=" * 60)

    lambda_g_mub = compute_lambda_g_median_unbiased(stage2_results, model_data)

    print(f"\n✅ λ_g median-unbiased = {lambda_g_mub:.6f}")
    print(f"   Difference from initial = {lambda_g_mub - lambda_g_initial:.6f}")

    # Optional: Re-run Stage 2 with corrected λ_g (HLW does this)
    if abs(lambda_g_mub - lambda_g_initial) > 0.01:
        print("\n" + "=" * 60)
        print("RE-RUNNING STAGE 2 with corrected λ_g")
        print("=" * 60)

        stage2_final = Stage2EstimatorFixed(config_path, stage1_results, lambda_g_mub)
        stage2_results = stage2_final.estimate(model_data)
    
    print("\n" + "=" * 60)
    print("STAGE 2 COMPLETE")
    print("=" * 60)
    print(f"Log-likelihood: {stage2_results['log_likelihood']:.4f}")
    
    print("\nKey parameters:")
    print(f"  a_r (interest rate effect): {stage2_results['params']['a_r']:.4f}")
    print(f"  b_y (output gap → inflation): {stage2_results['params']['b_y']:.4f}")
    
    print("\nr* preliminary (without z component):")
    r_star = stage2_results['r_star_preliminary']
    print(f"  Mean:  {r_star.mean()*100:.2f}% annual")
    print(f"  Std:   {r_star.std()*100:.2f}%")
    print(f"  Last:  {r_star[-1]*100:.2f}% annual")

if __name__ == "__main__":
    main()
