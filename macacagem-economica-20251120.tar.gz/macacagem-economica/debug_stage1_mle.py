"""Debug Stage 1 MLE convergence issues"""
import sys
from pathlib import Path
import logging
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent / "src"))

from data.loader import DataLoader
from data.preprocessing import DataPreprocessor
from estimation.stage1_preliminary_fixed import Stage1EstimatorFixed

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def evaluate_log_likelihood(stage1, theta, y_data, x_data, label=""):
    """Evaluate log-likelihood for given parameters"""
    ll = stage1.kalman_log_likelihood(theta, y_data, x_data)

    # Extract key params
    param_names = ['a_y1', 'a_y2', 'b_pi', 'b_pi_lag', 'b_y',
                   'kappa_2020', 'kappa_2021', 'g', 'sigma_is',
                   'sigma_ph', 'sigma_y_star']

    print(f"\n{label}")
    print("=" * 60)
    print(f"Log-likelihood: {ll:.4f}")
    print("\nParameters:")
    for name, val in zip(param_names, theta):
        print(f"  {name:12s} = {val:10.6f}")

    # Check constraint
    b_sum = theta[2] + theta[3]  # b_pi + b_pi_lag
    print(f"\nConstraint check: b_pi + b_pi_lag = {b_sum:.4f} (should be < 1.0)")

    return ll

def main():
    print("Debugging Stage 1 MLE Convergence")
    print("=" * 60)

    config_path = Path("config/config.yaml")

    # Load data
    print("\nLoading data...")
    loader = DataLoader(config_path)
    raw_data = loader.load_all()

    preprocessor = DataPreprocessor(config_path)
    model_data = preprocessor.create_model_data(raw_data)

    # Initialize Stage 1
    stage1 = Stage1EstimatorFixed(config_path)

    # Extract data
    log_gdp = model_data['y_t'].values
    inflation = model_data['pi_t'].values
    inflation_lags = model_data['pi_t_lag_avg'].values
    inflation_lags2 = model_data['pi_t_lag_avg2'].values
    covid_dummies = model_data[['D_2020', 'D_2021', 'D_2022']].values

    # Remove NaN
    valid_idx = ~(np.isnan(log_gdp) | np.isnan(inflation) | np.isnan(inflation_lags) | np.isnan(inflation_lags2))
    log_gdp = log_gdp[valid_idx]
    inflation = inflation[valid_idx]
    inflation_lags = inflation_lags[valid_idx]
    inflation_lags2 = inflation_lags2[valid_idx]
    covid_dummies = covid_dummies[valid_idx]

    print(f"Sample size: {len(log_gdp)} observations")

    # Get OLS estimates
    output_gap = stage1.estimate_initial_output_gap(log_gdp)
    is_ols = stage1.estimate_is_curve_ols(output_gap)
    ph_ols = stage1.estimate_phillips_curve_ols(inflation, inflation_lags, output_gap, covid_dummies)

    # Prepare Kalman data
    T_start = 8
    y_data = np.column_stack([
        log_gdp[T_start:] * 100,
        inflation[T_start:]
    ])

    x_data = np.column_stack([
        log_gdp[T_start-1:-1] * 100,
        log_gdp[T_start-2:-2] * 100,
        inflation[T_start-1:-1],
        inflation_lags[T_start:],
        inflation_lags2[T_start:],
        covid_dummies[T_start:, 0],
        covid_dummies[T_start:, 1],
    ])

    # Test 1: OLS parameters
    theta_ols = np.array([
        is_ols['a_y1'],
        is_ols['a_y2'],
        ph_ols['b_pi'],
        ph_ols['b_pi_lag'],
        ph_ols['b_y'],
        ph_ols['kappa_2020'],
        ph_ols['kappa_2021'],
        0.01,  # g
        is_ols['sigma_is'],
        ph_ols['sigma_ph'],
        0.5    # sigma_y_star
    ])

    ll_ols = evaluate_log_likelihood(stage1, theta_ols, y_data, x_data,
                                      label="TEST 1: OLS Parameters")

    # Test 2: OLS parameters with smaller variances
    theta_small_var = theta_ols.copy()
    theta_small_var[8] = 0.5   # sigma_is
    theta_small_var[9] = 0.5   # sigma_ph
    theta_small_var[10] = 0.1  # sigma_y_star

    ll_small = evaluate_log_likelihood(stage1, theta_small_var, y_data, x_data,
                                        label="TEST 2: OLS with Smaller Variances")

    # Test 3: Increase b_y to minimum constraint
    theta_high_by = theta_ols.copy()
    theta_high_by[4] = 0.025  # b_y at lower bound

    ll_high = evaluate_log_likelihood(stage1, theta_high_by, y_data, x_data,
                                       label="TEST 3: b_y at Lower Bound (0.025)")

    # Test 4: What MLE converged to
    theta_mle = np.array([
        0.983786,  # a_y1
        0.020957,  # a_y2
        0.722588,  # b_pi
        0.297483,  # b_pi_lag
        0.025000,  # b_y
        -7.284185, # kappa_2020
        -9.920911, # kappa_2021
        0.050000,  # g
        3.219561,  # sigma_is
        10.000000, # sigma_ph
        2.000000   # sigma_y_star
    ])

    ll_mle = evaluate_log_likelihood(stage1, theta_mle, y_data, x_data,
                                      label="TEST 4: MLE Converged Solution")

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Log-likelihood comparison:")
    print(f"  OLS parameters:         {ll_ols:.4f}")
    print(f"  Small variances:        {ll_small:.4f}")
    print(f"  b_y at bound:           {ll_high:.4f}")
    print(f"  MLE converged:          {ll_mle:.4f}")

    print(f"\nDelta LL (MLE - OLS):     {ll_mle - ll_ols:.4f}")

    if ll_mle < ll_ols:
        print("\n⚠️  WARNING: MLE has WORSE likelihood than OLS!")
        print("This suggests the optimization got stuck in a local minimum.")
    else:
        print(f"\n✅ MLE improved LL by {ll_mle - ll_ols:.4f}")
        print("But parameters are at bounds, suggesting:")
        print("  1. Model is poorly identified without interest rate")
        print("  2. Kalman Filter may have numerical issues")
        print("  3. Bounds may be too restrictive")

if __name__ == "__main__":
    main()
