"""Quick script to inspect the data file structure."""
import sys
try:
    import pandas as pd
    import openpyxl

    # Read Excel file
    xl = pd.ExcelFile('data/raw/dados_completos.xlsx')
    print("=" * 60)
    print("ESTRUTURA DO ARQUIVO DE DADOS")
    print("=" * 60)
    print(f"\nPlanilhas disponíveis: {xl.sheet_names}\n")

    # Show structure of each sheet
    for sheet in xl.sheet_names:
        print(f"\n{'='*60}")
        print(f"PLANILHA: {sheet}")
        print(f"{'='*60}")
        df = pd.read_excel(xl, sheet_name=sheet)
        print(f"Dimensões: {df.shape}")
        print(f"Colunas: {list(df.columns)}")
        print(f"\nPrimeiras linhas:")
        print(df.head())
        print(f"\nÚltimas linhas:")
        print(df.tail())

except ImportError as e:
    print(f"Erro: {e}")
    print("\nInstale as dependências primeiro:")
    print("pip install -r requirements.txt")
    sys.exit(1)
