"""Gerar gráficos dos resultados HLW-COVID Brasil"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 6)

Path("outputs/figures").mkdir(parents=True, exist_ok=True)

print("Carregando resultados...")
# Usando dados NOVOS da estimação brasileira com bounds ampliados
results = pd.read_csv('outputs/results/filtered_states_brazilian.csv')
results['date'] = pd.to_datetime(results['date'])

# Calculando variáveis derivadas
results['r_star'] = results['r_star'] * 100  # Converter para %
results['r_gap'] = results['r_t'] - results['r_star']
results['y_gap'] = (results['y_t'] - results['y_star']) * 100  # Em %
results['g'] = results['g_t'] * 100  # Converter para %
results['r_star_se'] = 0.0  # Placeholder (não temos erros-padrão)

covid_start = pd.to_datetime('2020-04-01')
covid_end = pd.to_datetime('2022-12-31')

# GRÁFICO 1: r*
print("Gerando gráfico r*...")
fig, ax = plt.subplots(figsize=(14, 7))
ax.plot(results['date'], results['r_star'], 'b-', linewidth=2, label='r*')
ax.fill_between(results['date'],
                 results['r_star'] - 1.96*results['r_star_se'],
                 results['r_star'] + 1.96*results['r_star_se'],
                 alpha=0.3, color='blue', label='IC 95%')
ax.axhline(y=0, color='gray', linestyle='--', linewidth=1, alpha=0.5)
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red', label='COVID')
ax.set_xlabel('Trimestre')
ax.set_ylabel('r* (%)')
ax.set_title('Taxa Natural de Juros (r*) - Brasil', fontsize=14, fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/figures/r_star_series.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ r_star_series.png")

# GRÁFICO 2: Hiato Taxa Real
print("Gerando hiato taxa real...")
fig, ax = plt.subplots(figsize=(14, 7))
ax.plot(results['date'], results['r_gap'], 'g-', linewidth=2)
ax.axhline(y=0, color='black', linestyle='-', linewidth=1.5)
ax.fill_between(results['date'], 0, results['r_gap'],
                 where=(results['r_gap'] >= 0), alpha=0.3, color='red')
ax.fill_between(results['date'], 0, results['r_gap'],
                 where=(results['r_gap'] < 0), alpha=0.3, color='green')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
ax.set_xlabel('Trimestre')
ax.set_ylabel('Hiato (%)')
ax.set_title('Hiato da Taxa Real (r - r*)', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/figures/real_rate_gap.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ real_rate_gap.png")

# GRÁFICO 3: PIB
print("Gerando PIB...")
fig, ax = plt.subplots(figsize=(14, 7))
ax.plot(results['date'], results['y_t'], 'b-', linewidth=2, label='PIB Observado')
ax.plot(results['date'], results['y_star'], 'r--', linewidth=2, label='PIB Potencial')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
ax.set_xlabel('Trimestre')
ax.set_ylabel('Log PIB')
ax.set_title('PIB Real vs PIB Potencial', fontsize=14, fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/figures/gdp_actual_vs_potential.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ gdp_actual_vs_potential.png")

# GRÁFICO 4: Hiato Produto
print("Gerando hiato produto...")
fig, ax = plt.subplots(figsize=(14, 7))
ax.plot(results['date'], results['y_gap'], 'purple', linewidth=2)
ax.axhline(y=0, color='black', linestyle='-', linewidth=1.5)
ax.fill_between(results['date'], 0, results['y_gap'],
                 where=(results['y_gap'] >= 0), alpha=0.3, color='green')
ax.fill_between(results['date'], 0, results['y_gap'],
                 where=(results['y_gap'] < 0), alpha=0.3, color='red')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='gray')
ax.set_xlabel('Trimestre')
ax.set_ylabel('Hiato (%)')
ax.set_title('Hiato do Produto (ỹ)', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/figures/output_gap.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ output_gap.png")

# GRÁFICO 5: Crescimento
print("Gerando crescimento tendencial...")
fig, ax = plt.subplots(figsize=(14, 7))
g_annual = results['g'] * 4
ax.plot(results['date'], g_annual, 'orange', linewidth=2)
ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_xlabel('Trimestre')
ax.set_ylabel('g (% anual)')
ax.set_title('Crescimento Tendencial (g)', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/figures/trend_growth.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ trend_growth.png")

# DASHBOARD
print("Gerando dashboard...")
fig, axes = plt.subplots(3, 2, figsize=(16, 12))

ax = axes[0, 0]
ax.plot(results['date'], results['r_star'], 'b-', linewidth=2)
ax.fill_between(results['date'],
                 results['r_star'] - 1.96*results['r_star_se'],
                 results['r_star'] + 1.96*results['r_star_se'],
                 alpha=0.3, color='blue')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_title('r*', fontweight='bold')
ax.grid(True, alpha=0.3)

ax = axes[0, 1]
ax.plot(results['date'], results['r_gap'], 'g-', linewidth=2)
ax.axhline(y=0, color='black', linestyle='-')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_title('Hiato Taxa Real', fontweight='bold')
ax.grid(True, alpha=0.3)

ax = axes[1, 0]
ax.plot(results['date'], results['y_t'], 'b-', linewidth=1.5, label='Obs')
ax.plot(results['date'], results['y_star'], 'r--', linewidth=1.5, label='Pot')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_title('PIB', fontweight='bold')
ax.legend()
ax.grid(True, alpha=0.3)

ax = axes[1, 1]
ax.plot(results['date'], results['y_gap'], 'purple', linewidth=2)
ax.axhline(y=0, color='black', linestyle='-')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_title('Hiato Produto', fontweight='bold')
ax.grid(True, alpha=0.3)

ax = axes[2, 0]
ax.plot(results['date'], results['g'] * 4, 'orange', linewidth=2)
ax.axhline(y=0, color='gray', linestyle='--')
ax.axvspan(covid_start, covid_end, alpha=0.1, color='red')
ax.set_title('Crescimento', fontweight='bold')
ax.set_xlabel('Trimestre')
ax.grid(True, alpha=0.3)

ax = axes[2, 1]
ax.axis('off')
ultimo = results.iloc[-1]
# FIX: Usar .2f ao invés de .2% (já multiplicamos por 100 antes)
texto = f"""
ESTATÍSTICAS FINAIS
({ultimo['date'].strftime('%Y-%m-%d')})

r*:              {ultimo['r_star']:.2f}%
IC 95%:          [{ultimo['r_star']-1.96*ultimo['r_star_se']:.2f}%,
                  {ultimo['r_star']+1.96*ultimo['r_star_se']:.2f}%]

Hiato Taxa:      {ultimo['r_gap']:.2f}%
Hiato Produto:   {ultimo['y_gap']:.2f}%
Crescimento:     {ultimo['g']*4:.2f}%

Obs:             {len(results)}
"""
ax.text(0.1, 0.5, texto, fontsize=10, family='monospace',
        verticalalignment='center', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.suptitle('HLW-COVID BRASIL - Dashboard', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('outputs/figures/dashboard_completo.png', dpi=300, bbox_inches='tight')
plt.close()
print("✓ dashboard_completo.png")

print("\n✅ Todos os gráficos foram gerados em outputs/figures/")
