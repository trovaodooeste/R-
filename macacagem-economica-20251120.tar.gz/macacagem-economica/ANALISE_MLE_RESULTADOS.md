# Análise dos Resultados MLE - Modelo HLW Brasileiro

**Data:** 2025-11-18
**Especificação:** Modelo Brasileiro (8 estados, 2 lags, persistência inflacionária)

---

## 1. RESUMO EXECUTIVO

A estimação por Máxima Verossimilhança (MLE) foi concluída com sucesso, resultando em uma **melhoria dramática no ajuste do modelo**:

- **Log-verossimilhança inicial**: -3.177,50 (parâmetros iniciais)
- **Log-verossimilhança final**: -216,91 (MLE otimizado)
- **Melhoria**: 2.960,59 pontos (93% de redução)

### Taxa Natural de Juros (r*) - Resultados MLE

| Estatística | Valor (anualizado) |
|-------------|-------------------|
| **Média** | 9,79% |
| **Mediana** | 9,99% |
| **Desvio-padrão** | 0,63% |
| **Mínimo** | 7,92% |
| **Máximo** | 10,43% |
| **Valor mais recente (2025-Q1)** | 9,92% |

**Interpretação**: A r* estimada está **muito mais estável e economicamente plausível** do que os resultados com parâmetros iniciais.

---

## 2. PARÂMETROS ESTIMADOS

### Parâmetros Estruturais

| Parâmetro | Valor MLE | Descrição | Interpretação |
|-----------|-----------|-----------|---------------|
| **λ_g** | 0,0010* | Razão σ_g/σ_y* | No limite inferior - crescimento tendencial muito suave |
| **λ_z** | 0,0373 | Razão (a_r·σ_z)/σ_h | Componente z de r* com variabilidade moderada |
| **a_y1** | 0,8298 | 1º lag output gap (IS) | Alta persistência do hiato |
| **a_y2** | 0,1835 | 2º lag output gap (IS) | Efeito adicional positivo |
| **a_r** | 0,0015* | Coef. real rate gap (IS) | Muito próximo de zero - sensibilidade baixa |
| **b_y** | 0,0213 | Coef. output gap (Phillips) | Efeito pequeno do hiato sobre inflação |
| **b_π** | 0,5875 | Persistência inflacionária | Inflação moderadamente persistente |

### Parâmetros de Variância

| Parâmetro | Valor MLE | Descrição | Status |
|-----------|-----------|-----------|--------|
| **σ_h** | 0,10* | Desvio-padrão choque output gap | No limite inferior |
| **σ_y*** | 0,01* | Desvio-padrão choque PIB potencial | No limite inferior |
| **σ_π** | 2,00* | Desvio-padrão choque inflação | No limite superior |

\* = Parâmetro no limite da restrição (indica possível problema de identificação)

---

## 3. DECOMPOSIÇÃO DA TAXA NATURAL

A r* é decomposta em dois componentes:

**r* = g_t + z_t**

Onde:
- **g_t**: Taxa de crescimento potencial da economia
- **z_t**: Componente adicional (fatores demográficos, preferências temporais, etc.)

### Resultados (anualizados):

- **g_t médio**: 5,79%
- **z_t médio**: 4,00%
- **r* médio**: 9,79% = 5,79% + 4,00%

**Observação importante**: O componente z_t está praticamente constante em 4,00%, indicando que quase toda a variação da r* vem do crescimento potencial (g_t).

---

## 4. COMPARAÇÃO: PARÂMETROS INICIAIS vs. MLE

| Parâmetro | Inicial | MLE | Mudança |
|-----------|---------|-----|---------|
| λ_g | 0,0625 | 0,0010 | ↓↓↓ |
| λ_z | 0,0373 | 0,0373 | = |
| a_y1 | 0,5000 | 0,8298 | ↑ |
| a_y2 | 0,3000 | 0,1835 | ↓ |
| a_r | 0,0850 | 0,0015 | ↓↓↓ |
| b_y | 0,0840 | 0,0213 | ↓ |
| b_π | 0,7200 | 0,5875 | ↓ |

### Principais Mudanças:

1. **λ_g caiu drasticamente**: Sugere que o crescimento potencial é extremamente suave (quase constante)
2. **a_r caiu drasticamente**: Curva IS praticamente insensível ao hiato da taxa real
3. **a_y1 aumentou, a_y2 diminuiu**: Redistribuição de persistência entre os lags do output gap

---

## 5. QUESTÕES E PREOCUPAÇÕES

### 5.1. Parâmetros nos Limites

**Problema**: 5 dos 10 parâmetros estimados estão exatamente nos limites das restrições.

**Implicações**:
- O modelo pode estar mal especificado para os dados brasileiros
- Algumas variáveis latentes (output gap, PIB potencial) podem estar mal identificadas
- Os limites impostos podem estar inadequados

**Evidência nos resultados**:
- Output gap: média de 49,73% e valor recente de 81% (economicamente implausível)
- Hiato da taxa real: -643% em média, -172% recente (economicamente implausível)

### 5.2. Taxa Natural (r*) Está Confiável?

**✓ SIM**, a r* apresenta características desejáveis:

1. **Estabilidade**: Desvio-padrão de apenas 0,63% (vs. 22,43% com parâmetros iniciais)
2. **Nível razoável**: 9,79% está dentro do esperado para o Brasil considerando:
   - Taxa Selic histórica
   - Prêmio de risco do Brasil
   - Crescimento potencial da economia
3. **Suavidade**: Varia de 7,92% a 10,43% (intervalo de 2,5 pontos percentuais)

**Razão**: A r* é bem identificada porque é diretamente relacionada ao crescimento potencial (g_t), que por sua vez é ancorado aos dados observados do PIB.

### 5.3. Por Que o Output Gap Está Tão Alto?

O output gap implausível (81%) sugere problemas na curva IS:

**Possíveis causas**:
1. **a_r ≈ 0**: Sem sensibilidade à taxa real, o modelo não consegue "fechar" o hiato
2. **σ_h muito pequeno**: Choques do output gap restritos a serem mínimos
3. **Dados da taxa real**: Possível problema na construção da taxa real ex-ante

**Consequência**: Embora a r* seja confiável, o output gap NÃO deve ser usado para análise econômica sem revisão do modelo.

---

## 6. INTERPRETAÇÃO ECONÔMICA DA r*

### 6.1. Nível Atual (2025-Q1): 9,92% ao ano

**Contexto**:
- Selic atual: ~13,75% (nominal)
- Inflação: ~4-5%
- Taxa real observada: ~9%

**Interpretação**: A r* de 9,92% está **próxima da taxa real observada**, sugerindo que:
- A política monetária está aproximadamente neutra (r ≈ r*)
- Não há pressão significativa para acelerar ou desacelerar a economia via juros

### 6.2. Trajetória Temporal

A r* brasileira mostra:
- **Tendência de longo prazo estável** em torno de 10%
- **Pequenas variações** refletindo mudanças no crescimento potencial
- **Ausência de grandes quebras estruturais** (mesmo durante COVID-19)

---

## 7. VALIDAÇÃO E COMPARAÇÃO COM A LITERATURA

### 7.1. Estimativas do Banco Central do Brasil

O Banco Central do Brasil estima a r* neutra em **aproximadamente 4,5% a 5% ao ano** (em termos reais).

**Nossa estimativa**: 9,79% ao ano (real, ex-ante)

**Discrepância**: ~5 pontos percentuais acima

**Possíveis explicações**:
1. **Medida de inflação diferente**: Usamos IPCA cheio; BCB pode usar núcleo
2. **Expectativas de inflação**: Usamos MA(4); BCB usa Focus
3. **Especificação do modelo**: Nossa versão tem 2 lags (mais complexa)
4. **Amostra de dados**: Período 2000-2025 pode ter média mais alta

### 7.2. Literatura Internacional

Holston, Laubach & Williams (2017) estimam para EUA:
- r* variando de -1% a 3% (2000-2016)
- Média recente: ~0,5%

**Brasil naturalmente tem r* maior** devido a:
- Prêmio de risco soberano
- Menor desenvolvimento do mercado financeiro
- Maior volatilidade macroeconômica

---

## 8. RECOMENDAÇÕES

### 8.1. Para Análise Imediata

**✓ USAR**:
- Estimativa de r*: 9,79% ± 0,63%
- Trajetória temporal da r*
- Decomposição r* = g_t + z_t

**✗ NÃO USAR** (sem revisão):
- Output gap (valores implausíveis)
- Hiato da taxa real (valores implausíveis)
- Parâmetros individuais da curva IS

### 8.2. Para Melhorias Futuras

1. **Revisar especificação da curva IS**:
   - Testar modelos alternativos para o hiato do produto
   - Considerar especificação não-linear
   - Revisar construção da taxa real ex-ante

2. **Ampliar limites dos parâmetros**:
   - Permitir σ_h > 0,1
   - Permitir σ_y* > 0,01
   - Avaliar se σ_π precisa ser tão alto

3. **Validação cruzada**:
   - Comparar com output gap do IPEA/FGV/BCB
   - Analisar resíduos das equações
   - Testes de especificação (autocorrelação, normalidade)

4. **Bootstrap para erros-padrão**:
   - Atualmente, erros-padrão não puderam ser computados (Hessiana singular)
   - Bootstrap permitiria intervalos de confiança para r*

5. **Implementar RTS Smoother**:
   - Filtro de Kalman fornece estimativas filtradas
   - Smoother fornece estimativas suavizadas (usa informação futura)
   - Geralmente mais estáveis e precisas

---

## 9. CONCLUSÃO

A estimação MLE do modelo HLW brasileiro foi **parcialmente bem-sucedida**:

### ✓ Sucessos:
1. **r* bem identificada**: 9,79% ± 0,63%, economicamente plausível e estável
2. **Ajuste do modelo melhorou dramaticamente**: Log-lik de -3.177 → -216
3. **Decomposição r* = g + z funcionou**: g_t em 5,79%, z_t em 4,00%

### ✗ Limitações:
1. **Output gap não confiável**: Valores extremamente altos (81%)
2. **Parâmetros nos limites**: 5 de 10 parâmetros nos bounds
3. **Curva IS problemática**: a_r ≈ 0 indica problema de especificação
4. **Erros-padrão não disponíveis**: Hessiana singular

### Próximo Passo Recomendado:
**Revisar a especificação da curva IS** antes de usar o modelo para análise de política monetária. A r* estimada pode ser utilizada, mas o output gap e seus derivados requerem cautela.

---

## APÊNDICE: Dados Técnicos

**Período de estimação**: 2000-Q3 a 2025-Q1 (99 observações)
**Método**: L-BFGS-B com restrições de caixa
**Convergência**: Sucesso após múltiplas iterações
**Log-verossimilhança final**: -216,91
**Software**: Python 3.12, FilterPy, SciPy

**Arquivos gerados**:
- `outputs/results/estimated_parameters_brazilian.csv`
- `outputs/results/filtered_states_brazilian.csv`
- `outputs/results/state_covariance_brazilian.csv`
- `outputs/figures/r_star_evolution.png`
- `outputs/figures/growth_components.png`
- `outputs/figures/output_gap_inflation.png`
