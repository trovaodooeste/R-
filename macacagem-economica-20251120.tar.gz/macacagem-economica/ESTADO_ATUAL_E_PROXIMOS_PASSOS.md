# Estado Atual do Projeto HLW Brasil

**Data**: 2025-11-18
**Objetivo**: Comparar implementação atual com trabalho de Roberto Torres (2023)

---

## ✅ O QUE JÁ TEMOS

### 1. Implementação Completa
- **Modelo HLW Brasileiro**: 8 estados, especificação brasileira
- **Pipeline de dados**: Loader + Preprocessor + Validation
- **Estimação MLE**: Concluída com sucesso
- **Resultados**: r* = 9,79% ± 0,63%

### 2. Arquivos Principais

```
src/
├── data/
│   ├── loader.py              ✅ Carrega Excel/CSV
│   └── preprocessing.py       ✅ Transformações
├── models/
│   ├── hlw_model_brazilian.py ✅ Modelo 8 estados
│   └── hlw_model.py          ❌ Legacy (6 estados)
├── estimation/
│   ├── mle_brazilian.py      ✅ MLE scipy + FilterPy
│   └── mle.py                ❌ Legacy
└── utils/
    └── validation.py         ✅ Validações

Scripts:
- run_estimation_brazilian.py  ✅ Pipeline MLE
- visualize_results.py         ✅ Gráficos
- example_usage.py             ✅ Demo dados

Dados:
- data/raw/dados_completos_2000_2025.xlsx  ✅
- data/external/oxford_stringency_index.csv ✅
- outputs/results/*.csv                     ✅

Documentação:
- ANALISE_MLE_RESULTADOS.md     ✅ Análise detalhada
- IMPLEMENTACAO_BRASILEIRA.md   ✅ Spec matemática
- CLAUDE.md                     ✅ Instruções (ATUALIZADO)
```

---

## ⚠️ PROBLEMAS CONHECIDOS

### 1. Output Gap Implausível
- **Valor atual**: 81%
- **Problema**: Economicamente impossível (deveria estar entre -10% e +10%)
- **Causa**: Parâmetro a_r ≈ 0 (curva IS sem sensibilidade à taxa real)

### 2. Parâmetros nos Limites
- **5 de 10 parâmetros** exatamente nos bounds
- **Sugere**: Problema de identificação ou bounds inadequados

### 3. Erros-Padrão Indisponíveis
- **Hessiana singular**: Não é possível calcular erros-padrão analíticos
- **Solução**: Bootstrap (não implementado)

---

## ❓ ARQUIVOS DO ROBERTO TORRES (2023)

**STATUS**: **NÃO ENCONTRADOS** no repositório atual

### Onde procurar:
1. Arquivos .R ou .do (Stata)?
2. Notebooks .ipynb específicos?
3. Scripts Python com nome diferente?
4. Diretório separado?

### O que seria útil comparar:
- **Especificação do modelo**: Mesmas equações?
- **Parâmetros estimados**: Valores próximos?
- **r* resultante**: Convergência dos resultados?
- **Dados utilizados**: Mesma amostra?
- **Método de estimação**: MLE? Bayesiano?

---

## 🔧 PRÓXIMOS PASSOS

### PRIORIDADE ALTA

#### 1. Localizar Trabalho do Roberto Torres
- [ ] Verificar se arquivos foram adicionados ao repo
- [ ] Se sim, identificar formato (.R, .py, .ipynb, .do)
- [ ] Ler especificação matemática usada
- [ ] Comparar com nossa implementação

#### 2. Revisar Curva IS
- [ ] Testar especificação alternativa
- [ ] Investigar por que a_r → 0
- [ ] Considerar restrições adicionais
- [ ] Validar construção de r_t (taxa real ex-ante)

#### 3. Ampliar Bounds dos Parâmetros
```yaml
# Atual (config.yaml)
sigma_h: [0.01, 0.10]      # AUMENTAR limite superior
sigma_y_star: [0.001, 0.01] # AUMENTAR limite superior
sigma_pi: [0.50, 2.00]     # OK ou reduzir superior?
```

### PRIORIDADE MÉDIA

#### 4. Implementar RTS Smoother
- [ ] Backward pass do filtro de Kalman
- [ ] Estimativas suavizadas (melhor precisão)
- [ ] Comparar filtered vs. smoothed states

#### 5. Bootstrap para Intervalos de Confiança
- [ ] Implementar bootstrap não-paramétrico
- [ ] Gerar IC para r*
- [ ] Gerar IC para outros estados (g, z, h)

#### 6. Validação Cruzada
- [ ] Comparar output gap com IPEA/FGV
- [ ] Comparar r* com BCB
- [ ] Análise de resíduos (autocorrelação, normalidade)

### PRIORIDADE BAIXA

#### 7. Análise de Sensibilidade
- [ ] Variar período de amostra
- [ ] Remover/adicionar COVID
- [ ] Testar outras medidas de inflação (núcleo vs. cheio)

#### 8. Previsões Fora da Amostra
- [ ] Implementar forecasting
- [ ] Validar com dados recentes

---

## 📊 CHECKLIST DE COMPARAÇÃO COM ROBERTO TORRES

Quando os arquivos forem localizados, verificar:

### Dados
- [ ] Mesma amostra (2000-2025)?
- [ ] Mesmas fontes (BCB, IBGE, Oxford)?
- [ ] Mesmas transformações (log, anualizações)?

### Modelo
- [ ] Número de estados (6 ou 8)?
- [ ] Equação IS: quantos lags?
- [ ] Phillips Curve: com persistência?
- [ ] COVID: como foi modelado?

### Estimação
- [ ] Método usado (MLE, Bayesiano, 2-step)?
- [ ] Software (R, Python, Stata, MATLAB)?
- [ ] Convergência obtida?

### Resultados
- [ ] r* média e trajetória
- [ ] Parâmetros estruturais (a_y, a_r, b_y, b_π)
- [ ] Output gap plausível?
- [ ] Intervalos de confiança reportados?

---

## 🎯 AÇÕES IMEDIATAS

1. **CONFIRMAR**: Onde estão os arquivos do Roberto Torres?
2. **COMPARAR**: Especificação matemática dele vs. nossa
3. **DECIDIR**: Manter nossa implementação ou adaptar?
4. **CORRIGIR**: Problema do output gap (curva IS)

---

## 📞 PERGUNTAS PARA O USUÁRIO

1. Em que formato estão os arquivos do Roberto Torres (.R, .py, .ipynb)?
2. Eles foram copiados para este diretório ou estão em outro local?
3. Você tem o paper/relatório dele para comparar a especificação?
4. Qual é o valor de r* que ele encontrou?

---

## 💡 SUGESTÕES DE ANÁLISE

### Se os arquivos do Roberto Torres usam R:
```bash
# Procurar arquivos R
find . -name "*.R" -o -name "*.Rmd"
```

### Se usam Stata:
```bash
# Procurar arquivos Stata
find . -name "*.do" -o -name "*.ado"
```

### Se usam MATLAB:
```bash
# Procurar arquivos MATLAB
find . -name "*.m"
```

---

**Próxima ação recomendada**: Informar localização dos arquivos do Roberto Torres para comparação detalhada.
