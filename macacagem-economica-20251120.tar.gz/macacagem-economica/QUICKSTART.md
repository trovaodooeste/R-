# Guia Rápido - HLW-COVID Brasil

## Início Rápido em 5 Passos

### 1. Instalar Dependências

**Opção A (Completa):**
```bash
pip install -r requirements.txt
```

> ⚠️ **Problema com GCC/compilação no Windows?** Veja `INSTALL_WINDOWS.md` para soluções detalhadas.

### 2. Preparar Dados

Se você tem um arquivo `dados_completos.xlsx`, rode:

```bash
python prepare_data.py
```

Isso vai separar os dados nas estruturas esperadas pelo sistema.

**OU** coloque manualmente os arquivos em:
- `data/raw/pib_trimestral.xlsx` (colunas: `data`, `pib_real`)
- `data/raw/ipca.xlsx` (colunas: `data`, `ipca_nucleo`, `ipca_cheio`)
- `data/raw/selic.xlsx` (colunas: `data`, `selic_nominal`)
- `data/external/oxford_stringency_index.csv` (colunas: `date`, `stringency_index`)

### 3. Verificar Dados

```bash
python example_usage.py
```

Isso testa o carregamento e pré-processamento dos dados.

### 4. Estimar Modelo

```bash
python run_estimation.py
```

Vai demorar alguns minutos. Monitore o progresso no log.

### 5. Analisar Resultados

```bash
jupyter notebook notebooks/02_analise_resultados.ipynb
```

## O Que Cada Script Faz

### `prepare_data.py`
- **Entrada:** `data/raw/dados_completos.xlsx`
- **Saída:** Arquivos separados para PIB, IPCA, Selic, Stringency
- **Tempo:** < 1 minuto
- **Use quando:** Tiver dados em arquivo consolidado

### `example_usage.py`
- **Entrada:** Arquivos em `data/raw/` e `data/external/`
- **Saída:** `data/processed/model_data.csv` + logs
- **Tempo:** < 1 minuto
- **Use quando:** Quiser testar se dados estão corretos

### `run_estimation.py`
- **Entrada:** Arquivos em `data/raw/` e `data/external/`
- **Saída:**
  - `outputs/results/hlw_estimates.csv` (série de r*)
  - `outputs/results/parameter_estimates.csv` (parâmetros)
  - `outputs/results/estimation_results.pkl` (objeto completo)
  - `outputs/hlw_estimation.log` (log detalhado)
- **Tempo:** 5-20 minutos (depende de `maxiter`)
- **Use quando:** Quiser estimar o modelo

### `notebooks/01_exploracao_dados.ipynb`
- **Entrada:** Arquivos em `data/raw/` e `data/external/`
- **Saída:** Gráficos exploratórios
- **Tempo:** < 2 minutos
- **Use quando:** Primeira análise dos dados

### `notebooks/02_analise_resultados.ipynb`
- **Entrada:** `outputs/results/*`
- **Saída:** Figuras em `outputs/figures/`
- **Tempo:** < 3 minutos
- **Use quando:** Após rodar `run_estimation.py`

## Configuração Básica

### Ajustar período da amostra

Edite `config/config.yaml`:

```yaml
sample:
  start_date: "2000-Q1"
  end_date: "2024-Q4"
```

### Mudar número de iterações

Em `run_estimation.py`, linha ~87:

```python
results = estimator.estimate(
    maxiter=500,  # Aumentar para 1000+ se não convergir
)
```

### Valores iniciais dos parâmetros

Em `run_estimation.py`, linhas ~75-85:

```python
initial_params = {
    'lambda_g': 0.0625,  # Ajustar conforme literatura
    'lambda_z': 0.0373,
    # ...
}
```

## Troubleshooting

### "FileNotFoundError: Config file not found"

Certifique-se de rodar os scripts da raiz do projeto:

```bash
cd C:\Users\EDUARDO\Desktop\macaco
python run_estimation.py
```

### "ModuleNotFoundError: No module named 'pandas'"

Instale as dependências:

```bash
pip install -r requirements.txt
```

### "Optimization did not converge"

Tente:
1. Aumentar `maxiter` (ex: 1000 ou 2000)
2. Mudar método: `method='SLSQP'` ou `method='trust-constr'`
3. Verificar dados (NaNs, outliers)
4. Ajustar bounds dos parâmetros em `config/config.yaml`

### "Singular innovation covariance"

Isso pode acontecer se:
- Dados têm multicolinearidade perfeita
- Parâmetros levam a sistema não-identificado
- Condições iniciais ruins

Solução:
- Aumentar ruído nas observações (`sigma_pi` inicial > 0.5)
- Verificar se todos os dados estão variando

### Dados em formato diferente

Edite `config/config.yaml` para especificar nomes corretos:

```yaml
data_sources:
  pib:
    sheet_name: "SuaPlanilha"  # Mudar de "Dados"
    date_column: "Data"         # Mudar de "data"
    value_column: "PIB_Real"    # Mudar de "pib_real"
```

## Outputs Esperados

### Após `run_estimation.py`

```
outputs/
├── results/
│   ├── hlw_estimates.csv         # Série completa
│   ├── parameter_estimates.csv   # Parâmetros
│   └── estimation_results.pkl    # Objeto Python
└── hlw_estimation.log            # Log detalhado
```

### Após notebook de análise

```
outputs/figures/
├── r_star_series.png
├── real_rate_gap.png
├── gdp_actual_vs_potential.png
├── output_gap.png
├── trend_growth.png
└── dashboard_completo.png
```

## Valores Típicos Esperados

### Parâmetros

```
lambda_g: 0.01 a 0.15   (razão de variância do crescimento)
lambda_z: 0.01 a 0.10   (razão de variância de r*)
a_r:      0.5 a 0.95    (persistência do hiato)
b_y:      0.01 a 0.30   (sensibilidade ao hiato da taxa)
```

### r* para Brasil

```
Pré-crise (2000-2015):  ~4% a 6% a.a.
Pós-crise (2015-2019):  ~2% a 4% a.a.
COVID (2020-2022):      Variável (pode ser negativo)
Recente (2023-2024):    ~3% a 5% a.a.
```

## Performance

### Tempos esperados (máquina típica)

- Carregamento de dados: < 5 segundos
- Pré-processamento: < 2 segundos
- Estimação (500 iter): 5-10 minutos
- Estimação (1000 iter): 10-20 minutos
- Extração de r*: < 1 segundo
- Cálculo de erros padrão: 2-5 minutos
- Notebook de análise: 1-2 minutos

### Otimizar performance

1. **Reduzir iterações:** `maxiter=200` para testes rápidos
2. **Desabilitar erros padrão:** Comentar linha do `compute_standard_errors()`
3. **Usar método mais rápido:** `method='BFGS'` (sem bounds)
4. **Menos logging:** `logging.level = WARNING` em config

## Próximos Passos

Após rodar o básico:

1. **Entender resultados:**
   - Veja `IMPLEMENTACAO_COMPLETA.md` para detalhes técnicos
   - Compare com literatura (Holston et al., 2017)

2. **Validação:**
   - Checar resíduos do filtro de Kalman
   - Testes de diagnóstico (autocorrelação, normalidade)

3. **Robustez:**
   - Re-estimar com subamostras diferentes
   - Testar especificações alternativas (sem COVID, etc.)

4. **Análise de sensibilidade:**
   - Variar λ_g e λ_z em grid
   - Avaliar impacto em r*

5. **Comparações:**
   - Outros modelos de r* (UC-local level, etc.)
   - Estimativas do BCB ou literatura brasileira

## Recursos Adicionais

- **Documentação completa:** `IMPLEMENTACAO_COMPLETA.md`
- **Arquitetura do código:** `CLAUDE.md`
- **Modelo matemático:** `README.md`
- **Paper original:** Holston, Laubach & Williams (2017)

## Ajuda

Se encontrar problemas:
1. Verifique logs em `outputs/hlw_estimation.log`
2. Rode com `logging.level = DEBUG` para mais detalhes
3. Consulte `IMPLEMENTACAO_COMPLETA.md` seção "Limitações"

---

**Boa estimação!** 🚀
