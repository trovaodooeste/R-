"""
Setup script for HLW-COVID Brasil project.

Run this script to verify your environment and setup.
"""

import sys
import subprocess
from pathlib import Path


def check_python_version():
    """Check if Python version is 3.9 or higher."""
    print("\n1. Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 9:
        print(f"   ✓ Python {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"   ❌ Python {version.major}.{version.minor}.{version.micro}")
        print("   Required: Python 3.9 or higher")
        return False


def check_directories():
    """Check if all required directories exist."""
    print("\n2. Checking project directories...")
    required_dirs = [
        "data/raw",
        "data/processed",
        "data/external",
        "src/data",
        "src/models",
        "src/estimation",
        "src/utils",
        "notebooks",
        "config",
        "tests",
        "outputs/figures",
        "outputs/results",
    ]

    all_exist = True
    for dir_path in required_dirs:
        path = Path(dir_path)
        if path.exists():
            print(f"   ✓ {dir_path}")
        else:
            print(f"   ❌ {dir_path} - MISSING")
            all_exist = False

    return all_exist


def check_config():
    """Check if config file exists."""
    print("\n3. Checking configuration...")
    config_path = Path("config/config.yaml")
    if config_path.exists():
        print(f"   ✓ config.yaml found")
        return True
    else:
        print(f"   ❌ config.yaml NOT FOUND")
        return False


def check_requirements():
    """Check if requirements.txt exists."""
    print("\n4. Checking requirements.txt...")
    req_path = Path("requirements.txt")
    if req_path.exists():
        print(f"   ✓ requirements.txt found")
        return True
    else:
        print(f"   ❌ requirements.txt NOT FOUND")
        return False


def install_dependencies():
    """Offer to install dependencies."""
    print("\n5. Installing dependencies...")
    response = input("   Install dependencies from requirements.txt? (y/n): ")

    if response.lower() == 'y':
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"]
            )
            print("   ✓ Dependencies installed successfully")
            return True
        except subprocess.CalledProcessError as e:
            print(f"   ❌ Error installing dependencies: {e}")
            return False
    else:
        print("   ⊘ Skipped")
        return True


def check_data_files():
    """Check if data files exist."""
    print("\n6. Checking data files...")
    data_files = {
        "PIB": "data/raw/pib_trimestral.xlsm",
        "IPCA": "data/raw/ipca.xlsm",
        "Selic": "data/raw/selic.xlsm",
        "Stringency": "data/external/oxford_stringency_index.csv",
    }

    files_found = 0
    for name, file_path in data_files.items():
        path = Path(file_path)
        if path.exists():
            print(f"   ✓ {name}: {file_path}")
            files_found += 1
        else:
            print(f"   ❌ {name}: {file_path} - NOT FOUND")

    if files_found == 0:
        print("\n   ⚠️  No data files found!")
        print("   You need to add your data files to:")
        for name, file_path in data_files.items():
            print(f"     - {file_path}")

    return files_found > 0


def main():
    """Run all checks."""
    print("=" * 60)
    print("HLW-COVID BRASIL - SETUP VERIFICATION")
    print("=" * 60)

    checks = [
        check_python_version(),
        check_directories(),
        check_config(),
        check_requirements(),
    ]

    if all(checks):
        install_dependencies()
        check_data_files()

        print("\n" + "=" * 60)
        print("SETUP SUMMARY")
        print("=" * 60)
        print("✓ Environment is ready!")
        print("\nNext steps:")
        print("1. Add your data files to data/raw/ and data/external/")
        print("2. Run: python example_usage.py")
        print("3. Or open: notebooks/01_exploracao_dados.ipynb")
        print("=" * 60)
    else:
        print("\n" + "=" * 60)
        print("❌ Setup incomplete - please fix the issues above")
        print("=" * 60)


if __name__ == "__main__":
    main()
